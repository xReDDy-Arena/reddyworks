FarmLinkMessageEvent = {}
local FarmLinkMessageEvent_mt = Class(FarmLinkMessageEvent, Event)
InitEventClass(FarmLinkMessageEvent, "FarmLinkMessageEvent")

function FarmLinkMessageEvent.emptyNew()
    return Event.new(FarmLinkMessageEvent_mt)
end

function FarmLinkMessageEvent.new(targetUserId, senderUserId, senderName, messageText)
    local self = FarmLinkMessageEvent.emptyNew()
    self.targetUserId = tostring(targetUserId or "")
    self.senderUserId = tostring(senderUserId or "")
    self.senderName = tostring(senderName or "Jucator")
    self.messageText = tostring(messageText or "")
    return self
end

function FarmLinkMessageEvent:readStream(streamId, connection)
    self.targetUserId = streamReadString(streamId)
    self.senderUserId = streamReadString(streamId)
    self.senderName = streamReadString(streamId)
    self.messageText = streamReadString(streamId)
    self:run(connection)
end

function FarmLinkMessageEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.targetUserId or "")
    streamWriteString(streamId, self.senderUserId or "")
    streamWriteString(streamId, self.senderName or "Jucator")
    streamWriteString(streamId, self.messageText or "")
end

function FarmLinkMessageEvent:run(connection)
    -- Client -> server: serverul retransmite evenimentul tuturor clientilor.
    -- Fiecare client accepta mesajul numai daca targetUserId ii apartine.
    if connection ~= nil and connection:getIsServer() == false then
        if g_server ~= nil then
            g_server:broadcastEvent(
                FarmLinkMessageEvent.new(self.targetUserId, self.senderUserId, self.senderName, self.messageText),
                false,
                nil,
                nil
            )
        end
        return
    end

    if SmartPhone ~= nil and SmartPhone.receiveFarmLinkNetworkMessage ~= nil then
        SmartPhone:receiveFarmLinkNetworkMessage(
            self.targetUserId,
            self.senderUserId,
            self.senderName,
            self.messageText
        )
    end
end
