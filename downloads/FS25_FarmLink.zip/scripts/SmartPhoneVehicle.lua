SmartPhoneVehicle = {}


--------------------------------------------------
-- SPECIALIZARE VEHICUL
--------------------------------------------------

function SmartPhoneVehicle.prerequisitesPresent(specializations)
    return true
end


function SmartPhoneVehicle.registerEventListeners(vehicleType)

    SpecializationUtil.registerEventListener(
        vehicleType,
        "onLoad",
        SmartPhoneVehicle
    )

    SpecializationUtil.registerEventListener(
        vehicleType,
        "onRegisterActionEvents",
        SmartPhoneVehicle
    )
end


--------------------------------------------------
-- LOAD VEHICUL
--------------------------------------------------

function SmartPhoneVehicle:onLoad(savegame)

    self.smartPhoneActionEvents = {}

end


--------------------------------------------------
-- F2 IN VEHICUL
--------------------------------------------------

function SmartPhoneVehicle:onRegisterActionEvents(
    isActiveForInput,
    isActiveForInputIgnoreSelection
)

    if not self.isClient then
        return
    end

    if self.smartPhoneActionEvents == nil then
        self.smartPhoneActionEvents = {}
    end

    self:clearActionEventsTable(
        self.smartPhoneActionEvents
    )

    if isActiveForInputIgnoreSelection
    and InputAction ~= nil
    and InputAction.SMARTPHONE_TOGGLE ~= nil
    and SmartPhone ~= nil then

        local success, actionEventId =
            self:addActionEvent(
                self.smartPhoneActionEvents,
                InputAction.SMARTPHONE_TOGGLE,
                self,
                SmartPhoneVehicle.actionEventTogglePhone,
                false,
                true,
                false,
                true,
                nil
            )

        if actionEventId ~= nil then
            g_inputBinding:setActionEventTextVisibility(
                actionEventId,
                false
            )

            g_inputBinding:setActionEventActive(
                actionEventId,
                true
            )
        end

        print(
            "FS25 SmartPhone - F2 VEHICUL = "
            .. tostring(success)
            .. " ID="
            .. tostring(actionEventId)
        )
    end
end


--------------------------------------------------
-- CALLBACK F2 VEHICUL
--------------------------------------------------

function SmartPhoneVehicle:actionEventTogglePhone(
    actionName,
    inputValue,
    callbackState,
    isAnalog
)

    if SmartPhone == nil then
        return
    end

    SmartPhone.vehicleContextActive = true

    SmartPhone:onTogglePhone(
        actionName,
        inputValue,
        callbackState,
        isAnalog
    )
end


--------------------------------------------------
-- BLOCARE CAMERA MOUSE CAT TIMP FARMLINK ESTE DESCHIS
-- Pastreaza comenzile non-mouse (G29/gamepad) active.
--------------------------------------------------

if VehicleCamera ~= nil
and VehicleCamera.actionEventLookLeftRight ~= nil
and VehicleCamera.actionEventLookUpDown ~= nil
and SmartPhoneVehicle.farmLinkCameraHookInstalled ~= true then

    SmartPhoneVehicle.farmLinkCameraHookInstalled = true

    SmartPhoneVehicle.originalCameraLookLeftRight =
        VehicleCamera.actionEventLookLeftRight

    SmartPhoneVehicle.originalCameraLookUpDown =
        VehicleCamera.actionEventLookUpDown

    VehicleCamera.actionEventLookLeftRight = function(
        camera,
        actionName,
        inputValue,
        callbackState,
        isAnalog,
        isMouse
    )
        if isMouse == true
        and SmartPhone ~= nil
        and SmartPhone.isOpen == true
        and SmartPhone.vehicleContextActive == true then
            return
        end

        return SmartPhoneVehicle.originalCameraLookLeftRight(
            camera,
            actionName,
            inputValue,
            callbackState,
            isAnalog,
            isMouse
        )
    end

    VehicleCamera.actionEventLookUpDown = function(
        camera,
        actionName,
        inputValue,
        callbackState,
        isAnalog,
        isMouse
    )
        if isMouse == true
        and SmartPhone ~= nil
        and SmartPhone.isOpen == true
        and SmartPhone.vehicleContextActive == true then
            return
        end

        return SmartPhoneVehicle.originalCameraLookUpDown(
            camera,
            actionName,
            inputValue,
            callbackState,
            isAnalog,
            isMouse
        )
    end

    print("FS25 FarmLink - CAMERA MOUSE VEHICUL HOOK ACTIV")
end
