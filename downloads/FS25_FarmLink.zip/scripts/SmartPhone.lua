SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end


SmartPhone.isOpen = false
SmartPhone.currentPage = "home"

SmartPhone.actionEventId = nil
SmartPhone.inputsRegistered = false
SmartPhone.vehicleContextActive = false
SmartPhone.specializationInstalled = false
SmartPhone.tractorCatalog = {}
SmartPhone.tractorCatalogLoaded = false
SmartPhone.tractorCatalogFilter = "all"
SmartPhone.tractorSizeFilter = "all"
SmartPhone.tractorCatalogPage = 1
SmartPhone.selectedTractor = nil
SmartPhone.tractorConfigurationSelections = {}
SmartPhone.tractorMotorOptions = {}
SmartPhone.tractorMotorOptionIndex = 1
SmartPhone.tractorWheelOptions = {}
SmartPhone.tractorWheelOptionIndex = 1
SmartPhone.tractorColorOptions = {}
SmartPhone.tractorColorOptionIndex = 1
SmartPhone.genericCatalog = {}
SmartPhone.genericCatalogType = nil
SmartPhone.genericCatalogPage = 1
SmartPhone.selectedGenericItem = nil
SmartPhone.isLocked = true
SmartPhone.notifications = {}
SmartPhone.batteryLevel = 82
SmartPhone.signalLevel = 4
SmartPhone.lastNotificationId = 0
SmartPhone.tractorImageOverlays = {}
SmartPhone.tractorImagePaths = {}
SmartPhone.modName = g_currentModName
SmartPhone.modDirectory = g_currentModDirectory
SmartPhone.frameOverlay = nil
SmartPhone.appIconOverlays = SmartPhone.appIconOverlays or {}

SmartPhone.phoneX = 0.825
SmartPhone.phoneY = 0.030
SmartPhone.phoneW = 0.157
SmartPhone.phoneH = 0.485

SmartPhone.hudSettings = {
    minimap = true,
    help = true,
    gameInfo = true,
    vehicle = true
}


--------------------------------------------------
-- LOAD
--------------------------------------------------

function SmartPhone:loadMap(name)

    print("======================================")
    print("FS25 SmartPhone - MOD PORNIT")
    print("FS25 SmartPhone - versiune 1.0.105.0")
    print("======================================")

end


--------------------------------------------------
-- REGISTER INPUT PE JOS
--------------------------------------------------

function SmartPhone:registerPlayerInput()

    if g_inputBinding == nil
    or PlayerInputComponent == nil
    or InputAction == nil
    or InputAction.SMARTPHONE_TOGGLE == nil then
        return
    end

    g_inputBinding:beginActionEventsModification(
        PlayerInputComponent.INPUT_CONTEXT_NAME
    )

    local success, eventId =
        g_inputBinding:registerActionEvent(
            InputAction.SMARTPHONE_TOGGLE,
            self,
            SmartPhone.onTogglePhoneFromPlayer,
            false,
            true,
            false,
            true
        )

    self.actionEventId = eventId

    if eventId ~= nil then
        g_inputBinding:setActionEventTextVisibility(eventId, false)
    end

    g_inputBinding:endActionEventsModification()

    self.inputsRegistered = success == true

    print(
        "FS25 SmartPhone - F2 INREGISTRAT PE JOS = "
        .. tostring(success)
        .. " ID="
        .. tostring(eventId)
    )
end


function SmartPhone:onTogglePhoneFromPlayer(
    actionName,
    inputValue,
    callbackState,
    isAnalog
)

    self.vehicleContextActive = false

    self:onTogglePhone(
        actionName,
        inputValue,
        callbackState,
        isAnalog
    )
end


--------------------------------------------------
-- SUNTEM IN UTILAJ?
--------------------------------------------------

function SmartPhone:isInVehicle()

    return self.vehicleContextActive == true

end


--------------------------------------------------
-- F2
--------------------------------------------------

function SmartPhone:onTogglePhone(
    actionName,
    inputValue,
    callbackState,
    isAnalog
)
    if self.currentPage == "messages" and self.messageInputActive == true then
        return
    end


    self.isOpen = not self.isOpen

    if self.isOpen then

        self.currentPage = "home"
        self.isLocked = true

        if self.notifications == nil or #self.notifications == 0 then
            self:addNotification("FarmLink", "Telefon conectat la ferma.")
        end

        if g_inputBinding ~= nil then
            g_inputBinding:setShowMouseCursor(true)
        end

        if self:isInVehicle() then
            print("FS25 SmartPhone - DESCHIS IN UTILAJ")
        else
            print("FS25 SmartPhone - DESCHIS PE JOS")
        end

    else

        if g_inputBinding ~= nil then
            g_inputBinding:setShowMouseCursor(false)
        end

        if g_localPlayer ~= nil
        and g_localPlayer.inputComponent ~= nil then

            g_localPlayer.inputComponent.locked = false

        end

        print("FS25 SmartPhone - INCHIS")

    end

end


--------------------------------------------------
-- UPDATE
--------------------------------------------------

function SmartPhone:applyGameInfoVisibility()

    if g_currentMission == nil
    or g_currentMission.hud == nil
    or self.hudSettings == nil then
        return
    end

    local shouldShow = self.hudSettings.gameInfo ~= false
    local hud = g_currentMission.hud

    local candidates = {
        hud.gameInfoDisplay,
        hud.gameInfoDisplayMobile
    }

    for _, display in ipairs(candidates) do
        if display ~= nil and display.setVisible ~= nil then
            pcall(display.setVisible, display, shouldShow, false)
        end
    end
end


function SmartPhone:update(dt)

    if g_currentMission == nil then
        return
    end

    ------------------------------------------------
    -- INPUT PE JOS
    -- F2 DIN VEHICUL ESTE ADAUGAT DE
    -- SmartPhoneVehicle:onRegisterActionEvents()
    ------------------------------------------------

    if not self.inputsRegistered then
        self:registerPlayerInput()
    end


    ------------------------------------------------
    -- TELEFON INCHIS
    ------------------------------------------------

    if not self.isOpen then

        if g_localPlayer ~= nil
        and g_localPlayer.inputComponent ~= nil then

            g_localPlayer.inputComponent.locked = false

        end

        return

    end


    ------------------------------------------------
    -- TELEFON DESCHIS
    ------------------------------------------------

    if self.vehicleContextActive then

        ------------------------------------------------
        -- IN UTILAJ:
        -- NU BLOCAM INPUTUL PLAYERULUI/VEHICULULUI.
        -- VOLANUL G29 SI PEDALELE RAMAN ACTIVE.
        ------------------------------------------------

        if g_localPlayer ~= nil
        and g_localPlayer.inputComponent ~= nil then

            g_localPlayer.inputComponent.locked = false

        end

    else

        ------------------------------------------------
        -- PE JOS:
        -- BLOCAM CAMERA CAT FOLOSIM TELEFONUL.
        ------------------------------------------------

        if g_localPlayer ~= nil
        and g_localPlayer.inputComponent ~= nil then

            g_localPlayer.inputComponent.locked = true

        end

    end

end


--------------------------------------------------
-- HUD
--------------------------------------------------

function SmartPhone:getHud()

    if g_currentMission == nil then
        return nil
    end

    return g_currentMission.hud

end


--------------------------------------------------
-- MINIMAP
--------------------------------------------------

function SmartPhone:setMinimapVisible(value)

    local hud = self:getHud()

    if hud ~= nil
    and hud.ingameMap ~= nil
    and hud.ingameMap.setIsVisible ~= nil then

        hud.ingameMap:setIsVisible(value)

        print(
            "FS25 SmartPhone - MINIMAP = "
            .. tostring(value)
        )

        return true

    end

    print("FS25 SmartPhone - MINIMAP NU A FOST GASIT")

    return false

end


--------------------------------------------------
-- AJUTOR
--------------------------------------------------

function SmartPhone:setHelpVisible(value)

    local hud = self:getHud()

    if hud == nil then
        return false
    end

    if hud.setInputHelpVisible ~= nil then

        hud:setInputHelpVisible(value)

        print(
            "FS25 SmartPhone - AJUTOR = "
            .. tostring(value)
        )

        return true

    end


    if hud.inputHelp ~= nil
    and hud.inputHelp.setVisible ~= nil then

        hud.inputHelp:setVisible(
            value,
            false
        )

        print(
            "FS25 SmartPhone - AJUTOR = "
            .. tostring(value)
        )

        return true

    end

    print("FS25 SmartPhone - AJUTOR NU A FOST GASIT")

    return false

end


--------------------------------------------------
-- GAME INFO
-- TEST PENTRU BANI / ORA / VREME
--------------------------------------------------

function SmartPhone:setGameInfoVisible(value)

    self.hudSettings.gameInfo = value

    print(
        "FS25 SmartPhone - BANI/ORA/VREME = "
        .. tostring(value)
    )

    return true

end


--------------------------------------------------
-- HUD VEHICUL
--------------------------------------------------

function SmartPhone:setVehicleHudVisible(value)

    self.hudSettings.vehicle = value

    print(
        "FS25 SmartPhone - HUD VEHICUL = "
        .. tostring(value)
    )

    return true

end


--------------------------------------------------
-- TOGGLE SETTING
--------------------------------------------------

function SmartPhone:toggleHudSetting(settingName)

    self.hudSettings[settingName] =
        not self.hudSettings[settingName]

    local value =
        self.hudSettings[settingName]


    if settingName == "minimap" then

        self:setMinimapVisible(value)


    elseif settingName == "help" then

        self:setHelpVisible(value)


    elseif settingName == "gameInfo" then

        self:setGameInfoVisible(value)


    elseif settingName == "vehicle" then

        self:setVehicleHudVisible(value)

    end

end


--------------------------------------------------
-- FARMLINK BUY - TRACTOR SELECTAT
--------------------------------------------------

function SmartPhone:addNotification(title, message)

    self.notifications = self.notifications or {}
    self.lastNotificationId = (self.lastNotificationId or 0) + 1

    local timeText = "--:--"
    if getDate ~= nil then
        timeText = getDate("%H:%M")
    elseif os ~= nil and os.date ~= nil then
        timeText = os.date("%H:%M")
    end

    table.insert(self.notifications, 1, {
        id = self.lastNotificationId,
        title = tostring(title or "FarmLink"),
        message = tostring(message or ""),
        time = timeText
    })

    while #self.notifications > 8 do
        table.remove(self.notifications)
    end
end


function SmartPhone:drawNotifications()

    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH

    setTextColor(1,1,1,1)
    setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Notificari")
    setTextBold(false)

    local backW,backH=0.048,0.025
    local backX,backY=x+w-backW-0.016,y+h-0.080
    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(1,1,1,1)
    setTextBold(true)
    renderText(backX+backW/2,backY+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    local list=self.notifications or {}
    if #list==0 then
        setTextColor(0.55,0.70,0.58,1)
        renderText(x+0.020,y+h-0.135,0.008,"Nu ai notificari.")
        return
    end

    local startY=y+h-0.150
    local cardH=0.060
    for i=1,math.min(5,#list) do
        local n=list[i]
        local cy=startY-(i-1)*(cardH+0.0092)
        drawFilledRect(x+0.014,cy,w-0.028,cardH,0.025,0.105,0.040,1)
        setTextColor(0.55,0.92,0.60,1)
        setTextBold(true)
        renderText(x+0.023,cy+0.037,0.0078,n.title)
        setTextBold(false)
        setTextColor(1,1,1,1)
        local msg=n.message
        if string.len(msg)>28 then msg=string.sub(msg,1,26)..".." end
        renderText(x+0.023,cy+0.019,0.0074,msg)
        setTextAlignment(RenderText.ALIGN_RIGHT)
        setTextColor(0.55,0.66,0.57,1)
        renderText(x+w-0.023,cy+0.038,0.0068,n.time)
        setTextAlignment(RenderText.ALIGN_LEFT)
    end
end


--------------------------------------------------
-- MOUSE INSIDE
--------------------------------------------------

function SmartPhone:isMouseInside(
    posX,
    posY,
    x,
    y,
    w,
    h
)

    return
        posX >= x
        and posX <= x + w
        and posY >= y
        and posY <= y + h

end


--------------------------------------------------
-- MOUSE EVENT
--------------------------------------------------

function SmartPhone:mouseEvent(
    posX,
    posY,
    isDown,
    isUp,
    button
)

    -- FarmLink Home: CONTACTE sus + ECRAN BLOCARE jos
    if self.isOpen == true and self.currentPage == "home" and button == 1 and isDown then
        local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH

        if self:isMouseInside(posX,posY,x+0.014,y+h-0.155,w-0.028,0.030) then
            self.currentPage = "contacts"
            self.contactsPage = 1
            print("FS25 FarmLink - CONTACTE deschis")
            return
        end

        if self:isMouseInside(posX,posY,x+0.014,y+0.035,w-0.028,0.029) then
            self.isLocked = true
            self.currentPage = "home"
            print("FS25 FarmLink - ECRAN BLOCARE activat")
            return
        end
    end


    if not self.isOpen then
        return
    end

    if not isDown then
        return
    end

    if button ~= 1 then
        return
    end


    local x = self.phoneX
    local y = self.phoneY

    ------------------------------------------------
    -- LOCK SCREEN
    ------------------------------------------------

    if self.isLocked == true then
        local unlockX = x + 0.035
        local unlockY = y + 0.070
        local unlockW = self.phoneW - 0.070
        local unlockH = 0.038

        if self:isMouseInside(posX,posY,unlockX,unlockY,unlockW,unlockH) then
            self.isLocked = false
            self.currentPage = "home"
        end
        return
    end

    ------------------------------------------------
    -- NOTIFICARI - BUTON SUS DREAPTA PE HOME
    ------------------------------------------------

    if self.currentPage == "home"
    and self:isMouseInside(posX,posY,x+self.phoneW-0.038,y+self.phoneH-0.095,0.024,0.028) then
        self.currentPage = "notifications"
        return
    end
if self.currentPage == "bank" then
        local bw,bh=0.048,0.025
        local bx,by=x+self.phoneW-bw-0.016,y+self.phoneH-0.080

        if self:isMouseInside(posX,posY,bx,by,bw,bh) then
            self.currentPage="home"
            return
        end

        local perPage=4
        local pages=math.max(1,math.ceil(#(self.bankHistory or {})/perPage))
        self.bankHistoryPage=math.max(1,math.min(pages,self.bankHistoryPage or 1))
        local ny=y+0.030

        if self:isMouseInside(posX,posY,x+0.018,ny,0.040,0.026) then
            self.bankHistoryPage=math.max(1,self.bankHistoryPage-1)
            return
        end

        if self:isMouseInside(posX,posY,x+self.phoneW-0.058,ny,0.040,0.026) then
            self.bankHistoryPage=math.min(pages,self.bankHistoryPage+1)
            return
        end

        return
    end

    -- BACK CLICK FIX v1.0.96
    -- Zona este putin mai mare decat butonul desenat pentru click sigur.
    if self.currentPage == "weather"
    or self.currentPage == "shop"
    or self.currentPage == "shopDetails"
    or self.currentPage == "map"
    or self.currentPage == "prices"
    or self.currentPage == "service"
    or self.currentPage == "serviceVehicle"
    or self.currentPage == "bank"
    or self.currentPage == "notifications" then
        local backX = x + self.phoneW - 0.072
        local backY = y + self.phoneH - 0.092
        local backW = 0.066
        local backH = 0.045

        if self:isMouseInside(posX,posY,backX,backY,backW,backH) then
            if self.currentPage == "serviceVehicle" then
                self.currentPage = "service"
            else
                self.currentPage = "home"
            end
            return
        end
    end

    -- MAGAZIN FARMLINK v1.0.106.0
    if self.currentPage == "messages" then
        if self:handleFarmLinkMessagesMouse(posX,posY) then return end
    elseif self.currentPage == "contacts" then
        if self:handleFarmLinkContactsMouse(posX,posY) then return end
    elseif self.currentPage == "shop" then
        local fy=y+self.phoneH-0.126
        local fs={{"all",0.014,0.029},{"game",0.045,0.025},{"dlc",0.072,0.025},{"mod",0.099,0.043}}
        for _,f in ipairs(fs) do
            if self:isMouseInside(posX,posY,x+f[2],fy,f[3],0.022) then
                self.shopFilter=f[1]; self.shopPage=1; return
            end
        end

        local list=self:getFarmLinkShopItems()
        local perPage=5
        local pages=math.max(1,math.ceil(#list/perPage))
        self.shopPage=math.max(1,math.min(pages,self.shopPage or 1))
        local first=(self.shopPage-1)*perPage+1

        for row=0,perPage-1 do
            local data=list[first+row]
            if data~=nil then
                local cy=y+self.phoneH-0.169-(row*0.056)
                if self:isMouseInside(posX,posY,x+0.014,cy-0.034,self.phoneW-0.028,0.048) then
                    self.selectedShopItem=data
                    self.currentPage="shopDetails"
                    return
                end
            end
        end

        if self:isMouseInside(posX,posY,x+0.022,y+0.034,0.034,0.022) then
            self.shopPage=math.max(1,self.shopPage-1); return
        end
        if self:isMouseInside(posX,posY,x+self.phoneW-0.056,y+0.034,0.034,0.022) then
            self.shopPage=math.min(pages,self.shopPage+1); return
        end
    end

    if self.currentPage == "shopDetails" then
        if self:isMouseInside(posX,posY,x+0.030,y+0.082,self.phoneW-0.060,0.042) then
            self:buyFarmLinkHandTool()
            return
        end
    end

    -- HOME CLICK FIX v1.0.95
    if self.currentPage == "home" and self:isMouseInside(posX,posY,x+0.103,y+0.245,0.050,0.085) then
        self.currentPage="bank"; self.bankHistoryPage=1; return
    end
    if self.currentPage == "home" and self:isMouseInside(posX,posY,x+0.008,y+0.075,0.050,0.085) then
        self.currentPage="service"; self.serviceVehiclePage=1; return
    end

    if self.currentPage == "notifications" then
        local backW,backH=0.048,0.025
        local backX,backY=x+self.phoneW-backW-0.016,y+self.phoneH-0.080
        if self:isMouseInside(posX,posY,backX,backY,backW,backH) then
            self.currentPage="home"
        end
        return
    end

    if self.currentPage == "farm" then
        local backW,backH=0.048,0.025
        local backX,backY=x+self.phoneW-backW-0.016,y+self.phoneH-0.080
        if self:isMouseInside(posX,posY,backX,backY,backW,backH) then
            self.currentPage = "home"
        end
        return
    end
------------------------------------------------
    -- HOME
    ------------------------------------------------

        -- PRETURI - PAGINARE
    if self.currentPage == "prices" then
        local list=self:getFarmLinkPriceRows()
        local pages=math.max(1,math.ceil(#list/5))
        self.pricesPage=math.max(1,math.min(pages,self.pricesPage or 1))
        local ny=y+0.030
        if self:isMouseInside(posX,posY,x+0.018,ny,0.040,0.026) then
            self.pricesPage=math.max(1,self.pricesPage-1); return
        end
        if self:isMouseInside(posX,posY,x+self.phoneW-0.058,ny,0.040,0.026) then
            self.pricesPage=math.min(pages,self.pricesPage+1); return
        end
    end

if self.currentPage == "home" then

        -- Coordonatele sunt aliniate cu textura FarmLink.
        local col1 = x + 0.011
        local col2 = x + 0.059
        local col3 = x + 0.107

        local row1 = y + 0.235
        local row2 = y + 0.155
        local row3 = y + 0.075

        local appW = 0.041
        local appH = 0.062

        -- SHOWROOM
        if self:isMouseInside(posX, posY, col1, row1, appW, appH) then
            self.currentPage = "showroom"
            print("FS25 FarmLink - SHOWROOM deschis")
            return
        end

        -- HARTA
        if self:isMouseInside(posX, posY, col2, row1, appW, appH) then
            self.currentPage = "map"
            print("FS25 FarmLink - HARTA deschisa")
            return
        end

        -- BANCA
        if self:isMouseInside(posX, posY, col3, row1, appW, appH) then
            print("FS25 FarmLink - BANCA apasata")
            return
        end

        -- MAGAZIN
        if self:isMouseInside(posX, posY, col1, row2, appW, appH) then
            self.currentPage = "shop"
            self.shopPage = 1
            self.shopCatalogLoaded = false
            print("FS25 FarmLink - MAGAZIN deschis")
            return
        end

        -- FERMA
        if self:isMouseInside(posX, posY, col2, row2, appW, appH) then
            self.currentPage = "farm"
            print("FS25 FarmLink - FERMA deschisa")
            return
        end

        -- VREME
        if self:isMouseInside(posX, posY, col3, row2, appW, appH) then
            self.currentPage = "weather"
            print("FS25 FarmLink - VREME deschisa")
            return
        end

        -- SERVICE
        if self:isMouseInside(posX, posY, col1, row3, appW, appH) then
            print("FS25 FarmLink - SERVICE apasat")
            return
        end

        -- PRETURI
        if self:isMouseInside(posX, posY, col2, row3, appW, appH) then
            self.currentPage = "prices"
            self.pricesPage = 1
            print("FS25 FarmLink - PRETURI deschise")
            return
        end

        -- SETARI
        if self:isMouseInside(posX, posY, col3, row3, appW, appH) then
            self.currentPage = "settings"
            print("FS25 FarmLink - SETARI deschise")
            return
        end

    end


    ------------------------------------------------
    -- DETALII TRACTOR
    ------------------------------------------------

    if self.currentPage == "tractorDetails" then

        -- CONFIGUREAZA
        local configX = x + 0.014
        local configY = y + self.phoneH - 0.147
        local configW = 0.072
        local configH = 0.025

        if self:isMouseInside(posX, posY, configX, configY, configW, configH) then
            self:loadSelectedTractorMotorOptions()
            self:loadSelectedTractorWheelOptions()
            self:loadSelectedTractorColorOptions()
            self.currentPage = "tractorConfigure"
            print("FS25 FarmLink - CONFIGURATOR TRACTOR deschis")
            return
        end

        -- BUY - aceleasi coordonate ca butonul desenat jos.
        local actionY = y + 0.034
        local actionH = 0.027
        local actionX = x + 0.014
        local priceW = 0.045
        local buttonW = 0.025
        local actionGap = 0.0027
        local actionButtonW = 0.038
        local buyX = actionX + priceW + actionGap
        local rentX = buyX + actionButtonW + actionGap

        if self:isMouseInside(
            posX, posY,
            buyX,
            actionY,
            actionButtonW,
            actionH
        ) then
            self:buySelectedTractor()
            return
        end

        if self:isMouseInside(
            posX, posY,
            rentX,
            actionY,
            actionButtonW,
            actionH
        ) then
            self:rentSelectedTractor()
            return
        end

        if self:isMouseInside(
            posX, posY,
            x + self.phoneW - 0.048 - 0.018,
            y + self.phoneH - 0.080,
            0.048,
            0.025
        ) then
            self.currentPage = "showroomTractors"
            print("FS25 FarmLink - inapoi la TRACTOARE")
            return
        end
    end

    ------------------------------------------------
    -- CONFIGURATOR TRACTOR
    ------------------------------------------------

    if self.currentPage == "tractorConfigure" then
        local motorY = y + 0.265
        local arrowW = 0.025
        local arrowH = 0.048
        local leftX = x + 0.018
        local rightX = x + self.phoneW - 0.018 - arrowW

        if self:isMouseInside(posX, posY, leftX, motorY, arrowW, arrowH) then
            self:cycleSelectedMotorOption(-1)
            return
        end

        if self:isMouseInside(posX, posY, rightX, motorY, arrowW, arrowH) then
            self:cycleSelectedMotorOption(1)
            return
        end

        local wheelsY = y + 0.205

        if self:isMouseInside(posX, posY, leftX, wheelsY, arrowW, arrowH) then
            self:cycleSelectedWheelOption(-1)
            return
        end

        if self:isMouseInside(posX, posY, rightX, wheelsY, arrowW, arrowH) then
            self:cycleSelectedWheelOption(1)
            return
        end

        local colorY = y + 0.145

        if self:isMouseInside(posX, posY, leftX, colorY, arrowW, arrowH) then
            self:cycleSelectedColorOption(-1)
            return
        end

        if self:isMouseInside(posX, posY, rightX, colorY, arrowW, arrowH) then
            self:cycleSelectedColorOption(1)
            return
        end

        local backW = 0.046
        local backH = 0.024
        local backX = x + self.phoneW - backW - 0.016
        local backY = y + self.phoneH - 0.080

        if self:isMouseInside(posX, posY, backX, backY, backW, backH) then
            self.currentPage = "tractorDetails"
            print("FS25 FarmLink - inapoi la DETALII TRACTOR")
            return
        end

        return
    end


    ------------------------------------------------
    -- SHOWROOM - CATEGORII GENERICE
    ------------------------------------------------

    if self.currentPage == "genericCatalog" then
        local bw,bh=0.048,0.025
        local bx,by=x+self.phoneW-bw-0.016,y+self.phoneH-0.080
        if self:isMouseInside(posX,posY,bx,by,bw,bh) then self.currentPage="showroom"; return end

        local items=self.genericCatalog or {}
        local perPage=4
        local pages=math.max(1,math.ceil(#items/perPage))
        local ny,aw,ah=y+0.040,0.034,0.022
        local lx,rx=x+0.022,x+self.phoneW-0.022-aw
        if self:isMouseInside(posX,posY,lx,ny,aw,ah) then self.genericCatalogPage=math.max(1,(self.genericCatalogPage or 1)-1); return end
        if self:isMouseInside(posX,posY,rx,ny,aw,ah) then self.genericCatalogPage=math.min(pages,(self.genericCatalogPage or 1)+1); return end

        local first=((self.genericCatalogPage or 1)-1)*perPage+1
        local cx,cw,ch=x+0.014,self.phoneW-0.028,0.052
        local sy,gap=y+self.phoneH-0.190,0.0092
        for row=1,perPage do
            local d=items[first+row-1]
            if d then
                local cy=sy-(row-1)*(ch+gap)
                if self:isMouseInside(posX,posY,cx,cy,cw,ch) then self.selectedGenericItem=d; self.currentPage="genericDetails"; return end
            end
        end
        return
    end

    if self.currentPage == "genericDetails" then
        local bw,bh=0.048,0.025
        local bx,by=x+self.phoneW-bw-0.016,y+self.phoneH-0.080
        if self:isMouseInside(posX,posY,bx,by,bw,bh) then self.currentPage="genericCatalog"; return end
        local ay,bw2,gap=y+0.045,0.052,0.0092
        local buyX=x+0.020; local rentX=buyX+bw2+gap
        if self:isMouseInside(posX,posY,buyX,ay,bw2,0.030) then self:buyOrRentGenericItem(false); return end
        if self:isMouseInside(posX,posY,rentX,ay,bw2,0.030) then self:buyOrRentGenericItem(true); return end
        return
    end

    ------------------------------------------------
    -- SHOWROOM - TRACTOARE
    ------------------------------------------------

    if self.currentPage == "showroomTractors" then

        if self.tractorCatalogLoaded ~= true then
            self:loadTractorCatalog()
        end

        local w = self.phoneW
        local h = self.phoneH

        -- INAPOI
        local backW = 0.046
        local backH = 0.024
        local backX = x + w - backW - 0.016
        local backY = y + h - 0.080

        if self:isMouseInside(posX, posY, backX, backY, backW, backH) then
            self.currentPage = "showroom"
            print("FS25 FarmLink - inapoi la SHOWROOM")
            return
        end

        -- FILTRE
        local filterY = y + h - 0.115
        local gap = 0.0041
        local filterW = (w - 0.036 - gap * 3) / 4
        local filterH = 0.025
        local filterKeys = {"all", "game", "dlc", "mods"}

        for i, filterKey in ipairs(filterKeys) do
            local fx = x + 0.018 + (i - 1) * (filterW + gap)
            if self:isMouseInside(posX, posY, fx, filterY, filterW, filterH) then
                self.tractorCatalogFilter = filterKey
                self.tractorCatalogPage = 1
                print("FS25 FarmLink - FILTRU TRACTOARE = " .. tostring(filterKey))
                return
            end
        end

        -- FILTRU MARIME
        local sizeY = y + h - 0.148
        local sizeGap = 0.0041
        local sizeW = (w - 0.036 - sizeGap * 3) / 4
        local sizeH = 0.025
        local sizeKeys = {"all", "small", "medium", "large"}

        for i, sizeKey in ipairs(sizeKeys) do
            local sx = x + 0.018 + (i - 1) * (sizeW + sizeGap)

            if self:isMouseInside(posX, posY, sx, sizeY, sizeW, sizeH) then
                self.tractorSizeFilter = sizeKey
                self.tractorCatalogPage = 1
                print("FS25 FarmLink - MARIME TRACTOR = " .. tostring(sizeKey))
                return
            end
        end

        local tractors = self:getFilteredTractors()
        local perPage = 5
        local totalPages = math.max(1, math.ceil(#tractors / perPage))
        self.tractorCatalogPage = self.tractorCatalogPage or 1
        self.tractorCatalogPage = math.max(1, math.min(self.tractorCatalogPage, totalPages))

        -- PAGINARE
        local navY = y + 0.026
        local navW = 0.040
        local navH = 0.026
        local clickPadX = 0.010
        local clickPadY = 0.010
        local prevX = x + 0.018
        local nextX = x + w - 0.018 - navW

        if self:isMouseInside(
            posX, posY,
            prevX - clickPadX, navY - clickPadY,
            navW + clickPadX * 2, navH + clickPadY * 2
        ) then
            if self.tractorCatalogPage > 1 then
                self.tractorCatalogPage = self.tractorCatalogPage - 1
                print("FS25 FarmLink - PAGINA TRACTOARE = " .. tostring(self.tractorCatalogPage))
            end
            return
        end

        if self:isMouseInside(
            posX, posY,
            nextX - clickPadX, navY - clickPadY,
            navW + clickPadX * 2, navH + clickPadY * 2
        ) then
            if self.tractorCatalogPage < totalPages then
                self.tractorCatalogPage = self.tractorCatalogPage + 1
                print("FS25 FarmLink - PAGINA TRACTOARE = " .. tostring(self.tractorCatalogPage))
            end
            return
        end

        -- CARDURI TRACTOARE
        local firstIndex = (self.tractorCatalogPage - 1) * perPage + 1
        local rowY = y + 0.265
        local rowH = 0.039

        for visibleIndex = 0, 4 do
            local data = tractors[firstIndex + visibleIndex]

            if data ~= nil and self:isMouseInside(
                posX, posY,
                x + 0.018, rowY,
                w - 0.036, rowH
            ) then
                self.selectedTractor = data
                self.currentPage = "tractorDetails"
                print("FS25 FarmLink - DETALII TRACTOR: " .. tostring(data.name))
                return
            end

            rowY = rowY - 0.046
        end

        return
    end

    ------------------------------------------------
    -- SHOWROOM
    ------------------------------------------------

    if self.currentPage == "showroom" then

        local buttonX = x + 0.018
        local buttonW = self.phoneW - 0.036
        local buttonH = 0.040

        local tractorY = y + 0.290
        local combineY = y + 0.238
        local truckY = y + 0.186
        local carY = y + 0.134
        local toolsY = y + 0.082

        if self:isMouseInside(posX, posY, buttonX, tractorY, buttonW, buttonH) then
            self.currentPage = "showroomTractors"
            self.tractorCatalogLoaded = false
            self.tractorCatalogPage = 1
            print("FS25 FarmLink Showroom - TRACTOARE deschis")
            return
        end

        if self:isMouseInside(posX, posY, buttonX, combineY, buttonW, buttonH) then
            self:loadGenericCatalog("combines")
            self.currentPage = "genericCatalog"
            return
        end

        if self:isMouseInside(posX, posY, buttonX, truckY, buttonW, buttonH) then
            self:loadGenericCatalog("trucks")
            self.currentPage = "genericCatalog"
            return
        end

        if self:isMouseInside(posX, posY, buttonX, carY, buttonW, buttonH) then
            self:loadGenericCatalog("cars")
            self.currentPage = "genericCatalog"
            return
        end

        if self:isMouseInside(posX, posY, buttonX, toolsY, buttonW, buttonH) then
            self:loadGenericCatalog("tools")
            self.currentPage = "genericCatalog"
            return
        end

        if self:isMouseInside(
            posX, posY,
            x + self.phoneW - 0.070,
            y + self.phoneH - 0.080,
            0.052,
            0.026
        ) then
            self.currentPage = "home"
            print("FS25 FarmLink - inapoi la HOME")
            return
        end

    end


    ------------------------------------------------
    -- SETARI
    ------------------------------------------------

    if self.currentPage == "settings" then

        -- INTERFATA / HUD
        -- Zona de click este aceeasi cu butonul desenat.
        local settingsButtonX = x + 0.018
        local settingsButtonW = self.phoneW - 0.036
        local settingsButtonH = 0.038
        local settingsHudY = y + self.phoneH - 0.145
        local settingsAboutY = y + self.phoneH - 0.235

        if self:isMouseInside(
            posX,
            posY,
            settingsButtonX,
            settingsHudY,
            settingsButtonW,
            settingsButtonH
        ) then

            self.currentPage = "hud"
            return

        end


        -- DESPRE

        if self:isMouseInside(
            posX,
            posY,
            settingsButtonX,
            settingsAboutY,
            settingsButtonW,
            settingsButtonH
        ) then

            self.currentPage = "about"
            return

        end


        -- INAPOI

        if self:isMouseInside(
            posX,
            posY,
            x + self.phoneW - 0.048 - 0.018,
            y + self.phoneH - 0.103,
            0.048,
            0.025
        ) then

            self.currentPage = "home"
            return

        end

    end


    ------------------------------------------------
    -- DESPRE
    ------------------------------------------------

    if self.currentPage == "about" then

        if self:isMouseInside(
            posX,
            posY,
            x + self.phoneW - 0.048 - 0.018,
            y + self.phoneH - 0.103,
            0.048,
            0.025
        ) then

            self.currentPage = "settings"
            return

        end

    end


    ------------------------------------------------
    -- HUD SETTINGS
    ------------------------------------------------

    if self.currentPage == "hud" then

        -- MINIMAP

        if self:isMouseInside(
            posX,
            posY,
            x + 0.105,
            y + self.phoneH - 0.143,
            0.032,
            0.025
        ) then

            self:toggleHudSetting("minimap")
            return

        end


        -- BANI / ORA / VREME

        if self:isMouseInside(
            posX,
            posY,
            x + 0.105,
            y + self.phoneH - 0.193,
            0.032,
            0.025
        ) then

            self:toggleHudSetting("gameInfo")
            return

        end


        -- HUD VEHICUL

        if self:isMouseInside(
            posX,
            posY,
            x + 0.105,
            y + self.phoneH - 0.243,
            0.032,
            0.025
        ) then

            self:toggleHudSetting("vehicle")
            return

        end


        -- AJUTOR

        if self:isMouseInside(
            posX,
            posY,
            x + 0.105,
            y + self.phoneH - 0.293,
            0.032,
            0.025
        ) then

            self:toggleHudSetting("help")
            return

        end


        -- INAPOI

        if self:isMouseInside(
            posX,
            posY,
            x + self.phoneW - 0.048 - 0.018,
            y + self.phoneH - 0.103,
            0.048,
            0.025
        ) then

            self.currentPage = "settings"
            return

        end

    end

end


--------------------------------------------------
-- DRAW APP
--------------------------------------------------

function SmartPhone:drawApp(
    x,
    y,
    name,
    r,
    g,
    b
)

    drawFilledRect(
        x,
        y,
        0.035,
        0.045,
        r,
        g,
        b,
        1
    )

    setTextColor(0.07, 0.20, 0.11, 1)

    renderText(
        x,
        y - 0.014,
        0.009,
        name
    )

end


--------------------------------------------------
-- DRAW TOGGLE
--------------------------------------------------

function SmartPhone:drawToggle(
    x,
    y,
    value
)

    setTextColor(1, 1, 1, 1)

    if value then

        drawFilledRect(
            x,
            y,
            0.032,
            0.025,
            0.10,
            0.42,
            0.20,
            1
        )

        renderText(
            x + 0.0092,
            y + 0.008,
            0.010,
            "ON"
        )

    else

        drawFilledRect(
            x,
            y,
            0.032,
            0.025,
            0.48,
            0.39,
            0.25,
            1
        )

        renderText(
            x + 0.0075,
            y + 0.008,
            0.010,
            "OFF"
        )

    end

end


--------------------------------------------------
-- DREPTUNGHI CU COLTURI ROTUNJITE DIN LUA
-- Folosim mai multe benzi pentru a simula colturi
-- rotunjite fara textura PNG.
--------------------------------------------------

function SmartPhone:drawRoundedRect(x, y, w, h, radius, r, g, b, a)

    local step = radius / 3

    drawFilledRect(
        x + radius, y,
        w - radius * 2, h,
        r, g, b, a
    )

    drawFilledRect(
        x, y + radius,
        w, h - radius * 2,
        r, g, b, a
    )

    drawFilledRect(
        x + step, y + step,
        w - step * 2, h - step * 2,
        r, g, b, a
    )

end


--------------------------------------------------
-- DRAW PHONE
--------------------------------------------------

function SmartPhone:drawPhone()

    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    -- ECRAN NEGRU, continutul ramane desenat din Lua.
    drawFilledRect(
        x + 0.008,
        y + 0.011,
        w - 0.016,
        h - 0.022,
        0.008, 0.018, 0.010, 1
    )

    -- RAMA PNG TRANSPARENTA CU COLTURI PERFECT ROTUNDE.
    if self.frameOverlay == nil
    and self.modDirectory ~= nil then

        self.frameOverlay = Overlay.new(
            self.modDirectory .. "textures/farmlink_frame.png",
            x, y, w, h
        )

        print("FS25 FarmLink - RAMA ROTUNDA INCARCATA")
    end

    if self.frameOverlay ~= nil then
        self.frameOverlay:setPosition(x, y)
        self.frameOverlay:setDimension(w, h)
        self.frameOverlay:render()
    end

    -- ORA REALA
    local realTime = "--:--"

    if getDate ~= nil then
        realTime = getDate("%H:%M")
    elseif os ~= nil and os.date ~= nil then
        realTime = os.date("%H:%M")
    end

    setTextColor(0.92, 0.96, 0.92, 1)
    setTextBold(false)

    renderText(
        x + 0.014,
        y + h - 0.031,
        0.008,
        realTime
    )

    local signalText = "4G"
    local battery = math.max(1, math.min(100, tonumber(self.batteryLevel) or 82))

    -- STATUS DREAPTA: grup compact, pozitii fixe
    local statusY = y + h - 0.031
    local groupX = x + w - 0.057

    -- 4G
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(true)
    renderText(groupX + 0.0045, statusY + 0.0025, 0.0072, signalText)
    setTextBold(false)

    -- Semnal mobil, imediat dupa 4G
    local sigX = groupX + 0.0140
    local sigY = y + h - 0.0275
    drawFilledRect(sigX,        sigY, 0.0014, 0.0017, 1,1,1,1)
    drawFilledRect(sigX+0.0021, sigY, 0.0014, 0.0026, 1,1,1,1)
    drawFilledRect(sigX+0.0042, sigY, 0.0014, 0.0035, 1,1,1,1)
    drawFilledRect(sigX+0.0063, sigY, 0.0014, 0.0045, 1,1,1,1)

    -- WiFi, imediat dupa semnal
    local wifiX = groupX + 0.0250
    local wifiY = y + h - 0.0270
    drawFilledRect(wifiX+0.0027, wifiY,        0.0013, 0.0013, 1,1,1,1)
    drawFilledRect(wifiX+0.0015, wifiY+0.0019, 0.0038, 0.0009, 1,1,1,1)
    drawFilledRect(wifiX+0.0003, wifiY+0.0038, 0.0062, 0.0009, 1,1,1,1)

    -- Baterie, imediat dupa WiFi si departe de marginea telefonului
    local batX = groupX + 0.0365
    local batY = y + h - 0.0273
    local batW = 0.0070
    local batH = 0.0043
    drawFilledRect(batX, batY, batW, batH, 0.96,0.98,0.96,1)
    drawFilledRect(batX+0.0006, batY+0.0006, batW-0.0012, batH-0.0012, 0.008,0.018,0.010,1)
    drawFilledRect(batX+batW, batY+0.0012, 0.0007, batH-0.0024, 0.96,0.98,0.96,1)
    local fillW = (batW-0.0016) * math.max(0,math.min(100,battery))/100
    drawFilledRect(batX+0.0008, batY+0.0008, fillW, batH-0.0016, 0.30,0.90,0.42,1)

    -- BARA HOME - subtire si neagra
    drawFilledRect(
        x + w * 0.35,
        y + 0.016,
        w * 0.30,
        0.0022,
        0.00, 0.00, 0.00, 1
    )

end


--------------------------------------------------
-- HOME
--------------------------------------------------

function SmartPhone:drawSettings()

    -- BG drawSettings
    self:drawFarmLinkPageBackground()
    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    -- Setari: continut compact, mutat sus.
    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.078, 0.0155, "Setari")
    setTextBold(false)

    local buttonX = x + 0.018
    local buttonW = w - 0.036
    local buttonH = 0.038

    local hudY = y + h - 0.145
    local aboutY = y + h - 0.235

    drawFilledRect(buttonX,hudY,buttonW,buttonH,0.10,0.34,0.17,1)

    setTextColor(0.96,0.98,0.92,1)
    renderText(
        buttonX + 0.010,
        hudY + 0.013,
        0.0095,
        "Interfata / HUD"
    )

    setTextColor(0.72, 0.80, 0.73, 1)
    renderText(
        buttonX + 0.0054,
        y + h - 0.190,
        0.0085,
        "Configurare telefon"
    )

    drawFilledRect(buttonX,aboutY,buttonW,buttonH,0.10,0.34,0.17,1)

    setTextColor(0.96,0.98,0.92,1)
    renderText(
        buttonX + 0.010,
        aboutY + 0.013,
        0.0095,
        "Despre"
    )

    -- Inapoi compact, sus-dreapta.
    local backW = 0.048
    local backH = 0.025
    local backX = x + w - backW - 0.018
    local backY = y + h - 0.103

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)

    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(
        backX + backW / 2,
        backY + 0.0086,
        0.0077,
        "< Inapoi"
    )
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

end


--------------------------------------------------
-- DESPRE
--------------------------------------------------
function SmartPhone:drawAbout()

    -- Acelasi fundal FarmLink ca in restul aplicatiilor.
    self:drawFarmLinkPageBackground()

    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.078, 0.0155, "Despre")
    setTextBold(false)

    -- Card principal.
    local cardX = x + 0.018
    local cardY = y + h - 0.330
    local cardW = w - 0.036
    local cardH = 0.205
    drawFilledRect(cardX, cardY, cardW, cardH, 0.025,0.105,0.040,0.96)

    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(cardX + 0.012, cardY + cardH - 0.037, 0.0130, "FarmLink")
    setTextBold(false)

    setTextColor(0.72,0.92,0.74,1)
    renderText(cardX + 0.012, cardY + cardH - 0.071, 0.0087, "Telefon inteligent pentru ferma ta")

    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(cardX + 0.012, cardY + cardH - 0.108, 0.0088, "Versiune")
    renderText(cardX + 0.012, cardY + cardH - 0.142, 0.0088, "Creator")
    renderText(cardX + 0.012, cardY + cardH - 0.176, 0.0088, "Joc")

    setTextAlignment(RenderText.ALIGN_RIGHT)
    renderText(cardX + cardW - 0.012, cardY + cardH - 0.108, 0.0088, "1.0.134.0")
    renderText(cardX + cardW - 0.012, cardY + cardH - 0.142, 0.0088, "xReDDy")
    renderText(cardX + cardW - 0.012, cardY + cardH - 0.176, 0.0082, "Farming Simulator 25")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- Status BETA in chenar, in acelasi stil FarmLink.
    local statusX = x + 0.018
    local statusY = y + 0.080
    local statusW = w - 0.036
    local statusH = 0.052
    drawFilledRect(statusX,statusY,statusW,statusH,0.025,0.105,0.040,0.96)

    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(statusX + statusW/2, statusY + 0.019, 0.0092, "STATUS: BETA")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- Inapoi putin mai jos, aliniat cu celelalte pagini.
    local backW = 0.048
    local backH = 0.025
    local backX = x + w - backW - 0.018
    local backY = y + h - 0.103

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(backX + backW / 2, backY + 0.0086, 0.0077, "< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

end

--------------------------------------------------
-- HUD SETTINGS
--------------------------------------------------

function SmartPhone:drawHudSettings()

    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    -- Tot continutul este mutat sus si apropiat.
    local titleY = y + h - 0.078

    setTextColor(1, 1, 1, 1)
    setTextBold(true)
    renderText(x + 0.018, titleY, 0.0155, "Interfata / HUD")
    setTextBold(false)

    local labelX = x + 0.018
    local toggleX = x + w - 0.058
    local firstY = y + h - 0.135
    local gap = 0.050

    setTextColor(1, 1, 1, 1)

    renderText(labelX, firstY, 0.0105, "Minimap")
    self:drawToggle(toggleX, firstY - 0.0092, self.hudSettings.minimap)

    renderText(labelX, firstY - gap, 0.0100, "Bani/Ora/Vreme")
    self:drawToggle(toggleX, firstY - gap - 0.0092, self.hudSettings.gameInfo)

    renderText(labelX, firstY - gap * 2, 0.0105, "HUD Vehicul")
    self:drawToggle(toggleX, firstY - gap * 2 - 0.0092, self.hudSettings.vehicle)

    renderText(labelX, firstY - gap * 3, 0.0105, "Ajutor")
    self:drawToggle(toggleX, firstY - gap * 3 - 0.0092, self.hudSettings.help)

    -- Inapoi sus, dreapta, compact.
    local backW = 0.048
    local backH = 0.025
    local backX = x + w - backW - 0.018
    local backY = y + h - 0.103

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)

    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(backX + backW / 2, backY + 0.0086, 0.009, "< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

end


--------------------------------------------------
-- DRAW
--------------------------------------------------

function SmartPhone:draw()

    if not self.isOpen then
        return
    end


    self:drawPhone()

    if self.isLocked == true then
        self:drawLockScreen()
        setTextColor(1,1,1,1)
        return
    end

    if self.currentPage == "home" then

        self:drawHome()

    elseif self.currentPage == "showroom" then

        self:drawShowroom()

    elseif self.currentPage == "showroomTractors" then

        self:drawShowroomTractors()

    elseif self.currentPage == "tractorDetails" then

        self:drawTractorDetails()

    elseif self.currentPage == "tractorConfigure" then

        self:drawTractorConfigure()

    elseif self.currentPage == "genericCatalog" then

        self:drawGenericCatalog()

    elseif self.currentPage == "genericDetails" then

        self:drawGenericDetails()

    elseif self.currentPage == "shop" then

        self:drawFarmLinkShop()

    elseif self.currentPage == "shopDetails" then

        self:drawFarmLinkShopDetails()

    elseif self.currentPage == "map" then

        self:drawFarmLinkMap()

    elseif self.currentPage == "farm" then

        self:drawFarm()

    elseif self.currentPage == "weather" then

        self:drawWeather()

    elseif self.currentPage == "prices" then

        self:drawPrices()

    elseif self.currentPage == "service" then

        self:drawService()

    elseif self.currentPage == "serviceVehicle" then

        self:drawServiceVehicleDetails()

    elseif self.currentPage == "bank" then

        self:drawBank()

    elseif self.currentPage == "notifications" then

        self:drawNotifications()

    elseif self.currentPage == "messages" then
        self:drawFarmLinkMessages()
    elseif self.currentPage == "contacts" then
        self:drawFarmLinkContacts()
    elseif self.currentPage == "settings" then

        self:drawSettings()

    elseif self.currentPage == "hud" then

        self:drawHudSettings()

    elseif self.currentPage == "about" then

        self:drawAbout()

    end


    setTextColor(1, 1, 1, 1)

    self:drawFarmLinkMessageNotification()

end


--------------------------------------------------
-- RESTORE HUD
--------------------------------------------------

function SmartPhone:restoreHud()

    self:setMinimapVisible(true)
    self:setHelpVisible(true)
    self:setGameInfoVisible(true)
    self:setVehicleHudVisible(true)

end


--------------------------------------------------
-- DELETE
--------------------------------------------------

function SmartPhone:deleteMap()

    if self.actionEventId ~= nil
    and g_inputBinding ~= nil then

        g_inputBinding:removeActionEvent(
            self.actionEventId
        )

        self.actionEventId = nil

    end

    self.inputsRegistered = false
    self.vehicleContextActive = false
    self.isOpen = false

    if g_inputBinding ~= nil then
        g_inputBinding:setShowMouseCursor(false)
    end

    if g_localPlayer ~= nil
    and g_localPlayer.inputComponent ~= nil then

        g_localPlayer.inputComponent.locked = false

    end
self:restoreHud()

end


--------------------------------------------------
-- ADAUGA SPECIALIZAREA TELEFONULUI PE VEHICULE
--------------------------------------------------

function SmartPhone.installVehicleSpecialization(typeManager)

    if typeManager == nil
    or typeManager.typeName ~= "vehicle"
    or SmartPhone.specializationInstalled then
        return
    end

    local specName = SmartPhone.modName .. ".smartPhoneVehicle"

    if g_specializationManager:getSpecializationByName(specName) == nil then
        if g_specializationManager:getSpecializationByName("smartPhoneVehicle") ~= nil then
            specName = "smartPhoneVehicle"
        else
            print("FS25 SmartPhone - EROARE: specializarea smartPhoneVehicle nu exista")
            return
        end
    end

    local added = 0

    for typeName, typeEntry in pairs(typeManager.types) do

        if SpecializationUtil.hasSpecialization(
            Enterable,
            typeEntry.specializations
        ) then

            if typeEntry.specializationsByName[specName] == nil then

                if typeManager:addSpecialization(typeName, specName) then
                    added = added + 1
                end

            end
        end
    end

    SmartPhone.specializationInstalled = true

    print(
        "FS25 SmartPhone - SmartPhoneVehicle adaugat pe "
        .. tostring(added)
        .. " tipuri de vehicule"
    )
end


TypeManager.validateTypes = Utils.prependedFunction(
    TypeManager.validateTypes,
    SmartPhone.installVehicleSpecialization
)



--------------------------------------------------
-- BLOCARE DESENARE HUD
-- Ascundem direct elementele in momentul in care
-- FS25 incearca sa le deseneze.
--------------------------------------------------

SmartPhone.hudDrawHooksInstalled = false
SmartPhone.gameInfoHookFunction = nil

function SmartPhone:installGameInfoDrawHook()

    if GameInfoDisplay == nil or GameInfoDisplay.draw == nil then
        return false
    end

    -- Daca hook-ul nostru este deja ultimul, nu facem nimic.
    if self.gameInfoHookFunction ~= nil
    and GameInfoDisplay.draw == self.gameInfoHookFunction then
        return true
    end

    -- Un alt mod poate inlocui GameInfoDisplay.draw dupa FarmLink.
    -- Pastram cea mai noua functie si o impachetam din nou.
    local previousDraw = GameInfoDisplay.draw

    local wrapper = function(display, ...)
        if SmartPhone ~= nil
        and SmartPhone.hudSettings ~= nil
        and SmartPhone.hudSettings.gameInfo == false then
            return
        end

        return previousDraw(display, ...)
    end

    self.originalGameInfoDraw = previousDraw
    self.gameInfoHookFunction = wrapper
    GameInfoDisplay.draw = wrapper

    print("FS25 FarmLink - HOOK GAME INFO ACTIV/REFACUT")
    return true
end


function SmartPhone:installHudDrawHooks()

    if self.hudDrawHooksInstalled then
        return
    end

    local installed = 0

    ------------------------------------------------
    -- BANI / ORA / VREME
    ------------------------------------------------

    if self:installGameInfoDrawHook() then
        installed = installed + 1
    end

    ------------------------------------------------
    -- HUD VEHICUL / VITEZOMETRU
    ------------------------------------------------

    if SpeedMeterDisplay ~= nil
    and SpeedMeterDisplay.draw ~= nil then

        self.originalSpeedMeterDraw = SpeedMeterDisplay.draw

        SpeedMeterDisplay.draw = function(display, ...)

            if SmartPhone ~= nil
            and SmartPhone.hudSettings ~= nil
            and SmartPhone.hudSettings.vehicle == false then
                return
            end

            return SmartPhone.originalSpeedMeterDraw(
                display,
                ...
            )
        end

        installed = installed + 1
        print("FS25 SmartPhone - HOOK SPEEDMETER INSTALAT")
    end

    self.hudDrawHooksInstalled = true

    print(
        "FS25 SmartPhone - HUD DRAW HOOKS = "
        .. tostring(installed)
    )
end


--------------------------------------------------
-- UPDATE HUD HOOKS
--------------------------------------------------

SmartPhone.originalUpdate = SmartPhone.update

function SmartPhone:update(dt)

    if not self.hudDrawHooksInstalled then
        self:installHudDrawHooks()
    end

    -- Cu multe moduri active, unele pot rescrie GameInfoDisplay.draw
    -- dupa ce FarmLink si-a instalat hook-ul. Il refacem automat.
    if GameInfoDisplay ~= nil
    and GameInfoDisplay.draw ~= nil
    and self.gameInfoHookFunction ~= nil
    and GameInfoDisplay.draw ~= self.gameInfoHookFunction then
        self:installGameInfoDrawHook()
    end

    return self:originalUpdate(dt)
end


--------------------------------------------------
-- START MOD
--------------------------------------------------

addModEventListener(SmartPhone)

function SmartPhone:isFarmLinkTextInputActive()
    return self.currentPage == "messages"
       and self.messageInputActive == true
end

function SmartPhone:keyEvent(unicode,key,modifier,isDown)
    if self.currentPage == "messages" and self.messageInputActive == true then
        self.blockPhoneToggleWhileTyping = true
        if self:handleFarmLinkMessageKey(unicode,key,modifier,isDown) then
            return
        end
    else
        self.blockPhoneToggleWhileTyping = false
    end
    if self.handleFarmLinkMessageKey ~= nil then
        self:handleFarmLinkMessageKey(unicode,key,modifier,isDown)
    end
end


function SmartPhone:drawFarmLinkMessageNotification()
    if self.isOpen ~= true then return end
    local n = self.farmLinkMessageNotification
    if n == nil then return end

    local now = g_time or 0
    if now - (n.createdAt or now) > 5000 then
        self.farmLinkMessageNotification = nil
        return
    end

    local x = self.phoneX or 0.825
    local y = self.phoneY or 0.030
    local w = self.phoneW or 0.157
    local h = self.phoneH or 0.485

    -- NOTIFICAREA INLOCUIESTE TEMPORAR BARA DE HEADER.
    local bx = x + 0.010
    local by = y + h - 0.094
    local bw = w - 0.020
    local bh = 0.050

    drawFilledRect(bx, by, bw, bh, 0.08, 0.28, 0.15, 1)

    setTextColor(0.80, 1.00, 0.82, 1)
    setTextBold(true)
    renderText(bx + 0.007, by + 0.030, 0.0070, "Mesaj nou")
    setTextBold(false)

    setTextColor(1,1,1,1)
    local txt = tostring(n.text or "")
    if #txt > 34 then txt = string.sub(txt,1,34).."..." end
    renderText(bx + 0.007, by + 0.012, 0.0058, txt)
end
