FarmLinkData = FarmLinkData or {}

function FarmLinkData.getFarmId()
    if g_currentMission ~= nil and g_currentMission.getFarmId ~= nil then
        return g_currentMission:getFarmId()
    end
    return nil
end

function FarmLinkData.getMoney()
    if g_currentMission ~= nil and g_currentMission.getMoney ~= nil then
        local farmId = FarmLinkData.getFarmId()
        if farmId ~= nil then
            return g_currentMission:getMoney(farmId)
        end
    end
    return 0
end
