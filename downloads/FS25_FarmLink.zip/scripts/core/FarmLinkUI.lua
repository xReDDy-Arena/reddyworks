FarmLinkUI = FarmLinkUI or {}

function FarmLinkUI.getVersion()
    return "1.0.87.0"
end

function FarmLinkUI.getTheme()
    return {
        name = "FarmLink",
        primary = {0.08, 0.42, 0.14, 1},
        text = {1, 1, 1, 1}
    }
end
