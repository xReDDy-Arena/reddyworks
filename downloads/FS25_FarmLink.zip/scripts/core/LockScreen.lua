SmartPhone = SmartPhone or {}
FarmLinkLockScreen = FarmLinkLockScreen or {}

function FarmLinkLockScreen.lock(phone)
    if phone ~= nil then
        phone.isLocked = true
    end
end

function FarmLinkLockScreen.unlock(phone)
    if phone ~= nil then
        phone.isLocked = false
        phone.currentPage = "home"
    end
end

--------------------------------------------------
-- DRAW LOCK SCREEN
--------------------------------------------------


function SmartPhone:getFarmLinkLockScreenBackground()
    if self.lockScreenBackgroundOverlay == nil
    and self.modDirectory ~= nil then
        self.lockScreenBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end

    return self.lockScreenBackgroundOverlay
end


function SmartPhone:getFarmLinkUnlockButtonOverlay()
    if self.unlockButtonOverlay == nil and self.modDirectory ~= nil then
        self.unlockButtonOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/unlock_button.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.unlockButtonOverlay
end


function SmartPhone:getFarmLinkUnlockLockOverlay()
    if self.unlockLockOverlay == nil and self.modDirectory ~= nil then
        self.unlockLockOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/unlock_lock.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.unlockLockOverlay
end

function SmartPhone:drawLockScreen()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH

    -- Lock Screen FarmLink: tema proprie crem + verde.
    -- Rama si status bar-ul sunt desenate separat si nu sunt modificate aici.
    local contentX = x + 0.010
    local contentY = y + 0.028
    local contentW = w - 0.020
    local contentH = h - 0.070

    -- Fundal PNG FarmLink.
    local bg = self:getFarmLinkLockScreenBackground()
    if bg ~= nil then
        bg:setPosition(contentX,contentY)
        bg:setDimension(contentW,contentH)
        bg:render()
    else
        -- Fallback sigur daca textura lipseste.
        drawFilledRect(contentX,contentY,contentW,contentH,0.945,0.925,0.825,1)
    end

    local realTime="--:--"
    local realDate="--.--.----"
    if getDate~=nil then
        local okT,vT=pcall(getDate,"%H:%M")
        if okT and vT~=nil then realTime=tostring(vT) end
        local okD,vD=pcall(getDate,"%d.%m.%Y")
        if okD and vD~=nil then realDate=tostring(vD) end
    end

    -- Ora si data.
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextBold(true)
    setTextColor(0.035,0.24,0.09,1)
    renderText(x+w/2,y+h-0.137,0.026,realTime)
    setTextBold(true)
    setTextColor(0.015,0.18,0.045,1)
    renderText(x+w/2,y+h-0.169,0.0095,realDate)
    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)

    -- Card notificare.
    local cardX=x+0.018
    local cardY=y+h-0.288
    local cardW=w-0.036
    local cardH=0.073
    drawFilledRect(cardX,cardY,cardW,cardH,0.88,0.92,0.72,1)
    drawFilledRect(cardX,cardY+cardH-0.0045,cardW,0.0045,0.08,0.48,0.16,1)

    -- Iconita FarmLink: simbol de ferma/teren in loc de litera F.
    local iconX=cardX+0.009
    local iconY=cardY+0.033
    local iconW=0.020
    local iconH=0.025
    drawFilledRect(iconX,iconY,iconW,iconH,0.18,0.50,0.20,1)
    -- acoperis + corp simplificat, lizibil la dimensiune mica
    drawFilledRect(iconX+0.004,iconY+0.006,0.012,0.008,0.94,0.96,0.82,1)
    drawFilledRect(iconX+0.007,iconY+0.014,0.006,0.004,0.94,0.96,0.82,1)
    drawFilledRect(iconX+0.009,iconY+0.006,0.003,0.005,0.18,0.50,0.20,1)

    local nTitle="FarmLink"
    local nMessage="Telefon conectat la ferma."
    local nTime=realTime
    if self.notifications~=nil and #self.notifications>0 then
        local n=self.notifications[#self.notifications]
        if n~=nil then
            nTitle=tostring(n.title or nTitle)
            nMessage=tostring(n.message or n.text or nMessage)
            nTime=tostring(n.time or realTime)
        end
    end

    setTextBold(true)
    setTextColor(0.005,0.11,0.02,1)
    renderText(cardX+0.035,cardY+0.052,0.0102,nTitle)
    setTextBold(false)
    setTextColor(0.01,0.13,0.025,1)
    setTextBold(true)
    renderText(cardX+0.035,cardY+0.031,0.0092,nMessage)
    setTextBold(false)
    setTextBold(true)
    setTextColor(0.02,0.16,0.04,1)
    renderText(cardX+0.035,cardY+0.011,0.0082,nTime)
    setTextBold(false)

    -- Buton mare DEBLOCHEAZA.
    local btnW=w-0.072
    local btnH=0.050
    local btnX=x+(w-btnW)/2
    local btnY=y+0.060

    -- Buton PNG cu transparenta: colturi rotunde reale.
    local unlockBg = self:getFarmLinkUnlockButtonOverlay()
    if unlockBg ~= nil then
        unlockBg:setPosition(btnX,btnY)
        unlockBg:setDimension(btnW,btnH)
        unlockBg:render()
    else
        drawFilledRect(btnX,btnY,btnW,btnH,0.05,0.50,0.16,1)
    end

    -- Lacat real, centrat impreuna cu textul.
    local lockW = 0.0115
    local lockH = 0.0165
    local groupCenterX = btnX + btnW * 0.5
    local lockX = groupCenterX - 0.036
    local lockY = btnY + (btnH - lockH) * 0.5
    local lockIcon = self:getFarmLinkUnlockLockOverlay()
    if lockIcon ~= nil then
        lockIcon:setPosition(lockX,lockY)
        lockIcon:setDimension(lockW,lockH)
        lockIcon:render()
    end

    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextBold(true)
    setTextColor(0.98,0.98,0.91,1)
    renderText(groupCenterX+0.009,btnY+0.0185,0.0090,"DEBLOCHEAZA")
    setTextBold(false)

    -- Branding de jos.
    setTextBold(true)
    setTextColor(0.015,0.18,0.045,1)
    renderText(x+w/2,btnY-0.018,0.0080,"FarmLink Secure")
    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)
end
