FarmLinkNotifications = FarmLinkNotifications or {}

function FarmLinkNotifications.add(phone, title, message)
    if phone ~= nil and phone.addNotification ~= nil then
        phone:addNotification(title, message)
    end
end
