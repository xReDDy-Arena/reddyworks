SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkService = FarmLinkService or {}
FarmLinkService.id="service"
FarmLinkService.title="Service"

function FarmLinkService.open(phone)
    if phone~=nil then
        phone.currentPage="service"
        phone.serviceVehiclePage=1
    end
end

function SmartPhone:getOwnedServiceVehicles()
    local result={}

    if g_currentMission==nil then
        return result
    end

    local farmId=nil
    if g_currentMission.getFarmId~=nil then
        farmId=g_currentMission:getFarmId()
    end

    -- FS25 tine lista vehiculelor in VehicleSystem.
    -- g_currentMission.vehicles nu este lista corecta in toate versiunile/situatiile.
    local vehicles=nil

    if g_currentMission.vehicleSystem~=nil
    and g_currentMission.vehicleSystem.vehicles~=nil then
        vehicles=g_currentMission.vehicleSystem.vehicles
    elseif g_currentMission.vehicles~=nil then
        vehicles=g_currentMission.vehicles
    end

    if vehicles==nil then
        print("FS25 FarmLink Service - NU EXISTA LISTA VEHICULE")
        return result
    end

    local seen={}

    for _,vehicle in pairs(vehicles) do
        if vehicle~=nil then
            local owner=nil

            if vehicle.getOwnerFarmId~=nil then
                local ok,v=pcall(function()
                    return vehicle:getOwnerFarmId()
                end)
                if ok then owner=v end
            end

            if owner==nil and vehicle.ownerFarmId~=nil then
                owner=vehicle.ownerFarmId
            end

            -- Service arata vehiculele fermei curente.
            if farmId==nil or owner==nil or owner==farmId then
                local show=true

                -- Evitam piese/obiecte care nu apar in lista normala de vehicule,
                -- atunci cand FS25 ofera aceasta functie.
                if vehicle.getShowInVehiclesOverview~=nil then
                    local ok,v=pcall(function()
                        return vehicle:getShowInVehiclesOverview()
                    end)
                    if ok then show=v end
                end

                if show then
                    local key=vehicle.rootNode or vehicle
                    if seen[key]~=true then
                        seen[key]=true

                        local name="Utilaj"

                        if vehicle.getName~=nil then
                            local ok,v=pcall(function()
                                return vehicle:getName()
                            end)
                            if ok and v~=nil and v~="" then
                                name=tostring(v)
                            end
                        end

                        if (name=="Utilaj" or name=="") and vehicle.getFullName~=nil then
                            local ok,v=pcall(function()
                                return vehicle:getFullName()
                            end)
                            if ok and v~=nil and v~="" then
                                name=tostring(v)
                            end
                        end

                        table.insert(result,{
                            vehicle=vehicle,
                            name=name
                        })
                    end
                end
            end
        end
    end

    print(
        "FS25 FarmLink Service - VEHICLE SYSTEM="
        .. tostring(#result)
        .. " FARM="
        .. tostring(farmId)
    )

    table.sort(result,function(a,b)
        return string.lower(a.name)<string.lower(b.name)
    end)

    return result
end

function SmartPhone:getServiceVehicleData(entry)
    local d={name="Utilaj",fuel=nil,damage=nil,hours=nil}
    if entry==nil or entry.vehicle==nil then return d end
    local v=entry.vehicle
    d.name=entry.name or "Utilaj"

    if FillType~=nil and FillType.DIESEL~=nil and v.getConsumerFillUnitIndex~=nil
    and v.getFillUnitFillLevel~=nil and v.getFillUnitCapacity~=nil then
        local ok,i=pcall(function() return v:getConsumerFillUnitIndex(FillType.DIESEL) end)
        if ok and i~=nil then
            local ok1,l=pcall(function() return v:getFillUnitFillLevel(i) end)
            local ok2,c=pcall(function() return v:getFillUnitCapacity(i) end)
            if ok1 and ok2 and c~=nil and c>0 then d.fuel=math.floor(l/c*100+0.5) end
        end
    end

    if v.getDamageAmount~=nil then
        local ok,a=pcall(function() return v:getDamageAmount() end)
        if ok and a~=nil then d.damage=math.floor((tonumber(a) or 0)*100+0.5) end
    end

    local ms=v.operatingTime
    if ms==nil and v.getOperatingTime~=nil then
        local ok,a=pcall(function() return v:getOperatingTime() end)
        if ok then ms=a end
    end
    if ms~=nil then d.hours=math.floor((tonumber(ms) or 0)/3600000*10+0.5)/10 end
    return d
end

function SmartPhone:drawService()
    -- BG drawService
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local list=self:getOwnedServiceVehicles()
    self.serviceVehiclePage=self.serviceVehiclePage or 1
    local perPage=5
    local pages=math.max(1,math.ceil(#list/perPage))
    self.serviceVehiclePage=math.max(1,math.min(pages,self.serviceVehiclePage))

    setTextColor(0.025,0.18,0.05,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Service"); setTextBold(false)
    local bw,bh=0.048,0.025
    local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER); setTextBold(true)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)
    setTextColor(0.02,0.18,0.05,1)
    setTextBold(true)
    renderText(x+0.018,y+h-0.112,0.0100,"UTILAJELE TALE: "..#list)
    setTextBold(false)

    local first=(self.serviceVehiclePage-1)*perPage+1
    for row=0,perPage-1 do
        local e=list[first+row]
        if e~=nil then
            local cy=y+h-0.175-row*0.061
            drawFilledRect(x+0.014,cy,w-0.028,0.050,0.025,0.105,0.040,1)
            local d=self:getServiceVehicleData(e)
            local fuel=d.fuel~=nil and d.fuel.."%" or "--"
            local dmg=d.damage~=nil and d.damage.."%" or "--"
            setTextColor(0.96,0.98,0.92,1); setTextBold(true)
            local n=e.name; if string.len(n)>24 then n=string.sub(n,1,22)..".." end
            renderText(x+0.023,cy+0.027,0.0078,n); setTextBold(false)
            setTextColor(0.58,0.76,0.61,1)
            renderText(x+0.023,cy+0.010,0.0074,"Comb. "..fuel.."   Damage "..dmg)
        end
    end

    local ny=y+0.030
    drawFilledRect(x+0.018,ny,0.040,0.026,0.08,0.42,0.14,1)
    drawFilledRect(x+w-0.058,ny,0.040,0.026,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER); setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.038,ny+0.0081,0.010,"<")
    renderText(x+w/2,ny+0.0092,0.0083,"Pagina "..self.serviceVehiclePage.."/"..pages)
    renderText(x+w-0.038,ny+0.0081,0.010,">")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)
end

function SmartPhone:drawServiceVehicleDetails()
    -- BG drawServiceVehicleDetails
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local d=self:getServiceVehicleData(self.selectedServiceVehicle)
    setTextColor(0.025,0.18,0.05,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.012,"Service"); setTextBold(false)
    local bw,bh=0.048,0.025; local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER); setTextBold(true)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)

    setTextColor(0.55,0.92,0.60,1); setTextBold(true)
    renderText(x+0.018,y+h-0.120,0.0092,d.name); setTextBold(false)

    local vals={
      {"Combustibil",d.fuel~=nil and d.fuel.."%" or "Indisponibil"},
      {"Damage",d.damage~=nil and d.damage.."%" or "Indisponibil"},
      {"Ore functionare",d.hours~=nil and d.hours.." h" or "Indisponibil"}
    }
    for i,r in ipairs(vals) do
        local cy=y+h-0.185-(i-1)*0.070
        drawFilledRect(x+0.014,cy,w-0.028,0.055,0.025,0.105,0.040,1)
        setTextColor(0.58,0.76,0.61,1); renderText(x+0.023,cy+0.033,0.0072,r[1])
        setTextColor(0.96,0.98,0.92,1); setTextBold(true); renderText(x+0.023,cy+0.013,0.0082,r[2]); setTextBold(false)
    end
end
