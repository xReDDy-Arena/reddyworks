-- FarmLink v1.0.89.0
-- Aplicatia FERMA - modul separat

SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkFarm = FarmLinkFarm or {}

FarmLinkFarm.id = "farm"
FarmLinkFarm.title = "Ferma"

function FarmLinkFarm.open(phone)
    if phone ~= nil then
        phone.currentPage = "farm"
    end
end

function SmartPhone:getFarmDashboardData()

    local data = {
        money = 0,
        vehicles = 0,
        fields = 0,
        productions = 0,
        animals = 0
    }

    if g_currentMission == nil then
        return data
    end

    local farmId = nil
    if g_currentMission.getFarmId ~= nil then
        farmId = g_currentMission:getFarmId()
    end

    if farmId ~= nil and g_currentMission.getMoney ~= nil then
        local ok, value = pcall(function()
            return g_currentMission:getMoney(farmId)
        end)
        if ok and value ~= nil then
            data.money = tonumber(value) or 0
        end
    end

    -- Utilaje: folosim aceeasi lista verificata ca in aplicatia Service.
    if self.getOwnedServiceVehicles ~= nil then
        local ok, ownedVehicles = pcall(function()
            return self:getOwnedServiceVehicles()
        end)
        if ok and ownedVehicles ~= nil then
            data.vehicles = #ownedVehicles
        end
    else
        local vehicles = nil
        if g_currentMission.vehicleSystem ~= nil
        and g_currentMission.vehicleSystem.vehicles ~= nil then
            vehicles = g_currentMission.vehicleSystem.vehicles
        else
            vehicles = g_currentMission.vehicles
        end

        if vehicles ~= nil then
            for _, vehicle in pairs(vehicles) do
                if vehicle ~= nil then
                    local owner = vehicle.ownerFarmId
                    if vehicle.getOwnerFarmId ~= nil then
                        local ok, value = pcall(function()
                            return vehicle:getOwnerFarmId()
                        end)
                        if ok then owner = value end
                    end
                    if farmId == nil or owner == nil or owner == farmId then
                        data.vehicles = data.vehicles + 1
                    end
                end
            end
        end
    end

    if g_farmlandManager ~= nil and g_farmlandManager.farmlands ~= nil and farmId ~= nil then
        for _, farmland in pairs(g_farmlandManager.farmlands) do
            if farmland ~= nil and farmland.farmId == farmId then
                data.fields = data.fields + 1
            end
        end
    end

    if g_currentMission.productionChainManager ~= nil
    and g_currentMission.productionChainManager.productionPoints ~= nil then
        for _, point in pairs(g_currentMission.productionChainManager.productionPoints) do
            if point ~= nil then
                local owner = point.ownerFarmId
                if owner == nil and point.getOwnerFarmId ~= nil then
                    local ok, value = pcall(function()
                        return point:getOwnerFarmId()
                    end)
                    if ok then owner = value end
                end
                if farmId == nil or owner == farmId then
                    data.productions = data.productions + 1
                end
            end
        end
    end

    -- Animale: numaram animalele din adaposturile detinute de ferma curenta.
    local placeables = nil
    if g_currentMission.placeableSystem ~= nil
    and g_currentMission.placeableSystem.placeables ~= nil then
        placeables = g_currentMission.placeableSystem.placeables
    elseif g_currentMission.placeables ~= nil then
        placeables = g_currentMission.placeables
    end

    if placeables ~= nil then
        for _, placeable in pairs(placeables) do
            if placeable ~= nil then
                local owner = placeable.ownerFarmId
                if placeable.getOwnerFarmId ~= nil then
                    local okOwner, value = pcall(function()
                        return placeable:getOwnerFarmId()
                    end)
                    if okOwner then owner = value end
                end

                if farmId == nil or owner == farmId then
                    local counted = false

                    -- API-ul normal al adaposturilor de animale.
                    if placeable.getNumOfAnimals ~= nil then
                        local okAnimals, value = pcall(function()
                            return placeable:getNumOfAnimals()
                        end)
                        if okAnimals and value ~= nil then
                            data.animals = data.animals + (tonumber(value) or 0)
                            counted = true
                        end
                    end

                    -- Fallback FS25: clusterSystem din spec_husbandryAnimals.
                    if not counted
                    and placeable.spec_husbandryAnimals ~= nil
                    and placeable.spec_husbandryAnimals.clusterSystem ~= nil
                    and placeable.spec_husbandryAnimals.clusterSystem.getClusters ~= nil then
                        local okClusters, clusters = pcall(function()
                            return placeable.spec_husbandryAnimals.clusterSystem:getClusters()
                        end)
                        if okClusters and clusters ~= nil then
                            for _, cluster in pairs(clusters) do
                                if cluster ~= nil then
                                    local num = cluster.numAnimals
                                    if cluster.getNumAnimals ~= nil then
                                        local okNum, value = pcall(function()
                                            return cluster:getNumAnimals()
                                        end)
                                        if okNum then num = value end
                                    end
                                    data.animals = data.animals + (tonumber(num) or 0)
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return data
end

function SmartPhone:drawFarmStatCard(x, y, w, h, title, value)

    drawFilledRect(x,y,w,h,0.025,0.105,0.040,1)

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    renderText(x + 0.009, y + h - 0.019, 0.0080, title)

    setTextBold(true)
    setTextColor(0.96, 0.98, 0.92, 1)
    renderText(x + 0.009, y + 0.013, 0.009, tostring(value))
    setTextBold(false)
end

function SmartPhone:drawFarm()

    -- BG drawFarm
    self:drawFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local data = self:getFarmDashboardData()

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.070, 0.014, "Ferma")
    setTextBold(false)

    local backW, backH = 0.048, 0.025
    local backX, backY = x + w - backW - 0.016, y + h - 0.080

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(backX + backW/2, backY + 0.0086, 0.0078, "< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    setTextColor(0.02,0.18,0.05,1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.112, 0.0092, "PANOU FERMA")
    setTextBold(false)

    local cardW = (w - 0.044) / 2
    local cardH = 0.066
    local leftX = x + 0.014
    local rightX = leftX + cardW + 0.016
    local row1 = y + h - 0.205
    local row2 = row1 - 0.082

    self:drawFarmStatCard(leftX, row1, cardW, cardH, "Utilaje", data.vehicles)
    self:drawFarmStatCard(rightX, row1, cardW, cardH, "Terenuri", data.fields)
    self:drawFarmStatCard(leftX, row2, cardW, cardH, "Productii", data.productions)
    self:drawFarmStatCard(rightX, row2, cardW, cardH, "Animale", data.animals)

    local moneyY = row2 - 0.088
    drawFilledRect(x + 0.014,moneyY,w - 0.028,0.068,0.06,0.28,0.10,1)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(x + 0.024, moneyY + 0.043, 0.0085, "SOLD FERMA")
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(
        x + 0.024,
        moneyY + 0.017,
        0.0100,
        tostring(math.floor(data.money + 0.5)) .. " $"
    )
    setTextBold(false)

    setTextColor(0.02,0.18,0.05,1)
    renderText(
        x + 0.018,
        y + 0.055,
        0.0072,
        "Date actualizate direct din ferma"
    )
end
