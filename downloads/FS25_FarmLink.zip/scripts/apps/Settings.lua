FarmLinkSettings = FarmLinkSettings or {}
FarmLinkSettings.id = "settings"
FarmLinkSettings.title = "Setari"
function FarmLinkSettings.open(phone)
    if phone ~= nil then phone.currentPage = "settings" end
end
