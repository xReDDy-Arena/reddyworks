-- FarmLink v1.0.106.0 - Magazin Unelte (TEST)
SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end


SmartPhone.shopCatalog = SmartPhone.shopCatalog or {}
SmartPhone.shopCatalogLoaded = SmartPhone.shopCatalogLoaded or false
SmartPhone.shopFilter = SmartPhone.shopFilter or "all"
SmartPhone.shopPage = SmartPhone.shopPage or 1
SmartPhone.selectedShopItem = SmartPhone.selectedShopItem or nil

function SmartPhone:isFarmLinkHandTool(item)
    if item == nil or item.showInStore == false then return false end

    if StoreItemUtil ~= nil and StoreItemUtil.getIsHandTool ~= nil then
        local ok, value = pcall(StoreItemUtil.getIsHandTool, item)
        if ok and value == true then return true end
    end

    if StoreSpecies ~= nil and StoreSpecies.HANDTOOL ~= nil and item.species == StoreSpecies.HANDTOOL then
        return true
    end

    return false
end

function SmartPhone:getFarmLinkShopSource(item)
    if self.getStoreItemSource ~= nil then
        return self:getStoreItemSource(item)
    end
    if item ~= nil and item.isMod == true then return "mod" end
    if item ~= nil and (item.dlcTitle ~= nil or item.dlcName ~= nil or item.dlcId ~= nil or item.packageName ~= nil) then
        return "dlc"
    end
    return "game"
end

function SmartPhone:loadFarmLinkShopCatalog()
    self.shopCatalog = {}
    if g_storeManager == nil or g_storeManager.getItems == nil then
        self.shopCatalogLoaded = true
        print("FS25 FarmLink Magazin - StoreManager indisponibil")
        return
    end

    local items = g_storeManager:getItems() or {}
    local gameCount, dlcCount, modCount = 0,0,0

    for _,item in pairs(items) do
        if self:isFarmLinkHandTool(item) then
            local source = self:getFarmLinkShopSource(item)
            if source == "mod" then modCount=modCount+1
            elseif source == "dlc" then dlcCount=dlcCount+1
            else gameCount=gameCount+1 end

            table.insert(self.shopCatalog,{
                storeItem=item,
                name=item.name or "Unealta",
                price=item.price or 0,
                source=source
            })
        end
    end

    table.sort(self.shopCatalog,function(a,b)
        return string.lower(tostring(a.name)) < string.lower(tostring(b.name))
    end)
    self.shopCatalogLoaded=true
    print("FS25 FarmLink Magazin - UNELTE="..tostring(#self.shopCatalog)..
          " | JOC="..tostring(gameCount).." | DLC="..tostring(dlcCount).." | MODURI="..tostring(modCount))
end

function SmartPhone:getFarmLinkShopItems()
    if self.shopCatalogLoaded ~= true then self:loadFarmLinkShopCatalog() end
    local result={}
    local filter=self.shopFilter or "all"
    for _,data in ipairs(self.shopCatalog or {}) do
        if filter=="all" or data.source==filter then table.insert(result,data) end
    end
    return result
end

function SmartPhone:drawFarmLinkShop()
    -- BG drawFarmLinkShop
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    drawFilledRect(x+0.010,y+h-0.094,w-0.020,0.050,0.018,0.13,0.045,1)
    drawFilledRect(x+0.010,y+h-0.094,w-0.020,0.0041,0.16,0.70,0.24,1)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Magazin")
    setTextBold(false)
    drawFilledRect(x+w-0.060,y+h-0.084,0.044,0.025,0.04,0.20,0.07,1)
    setTextColor(0.75,1,0.78,1); renderText(x+w-0.052,y+h-0.076,0.008,"INAPOI")

    local filters={{"all","TOATE",0.014,0.029},{"game","JOC",0.045,0.025},{"dlc","DLC",0.072,0.025},{"mod","MODURI",0.099,0.043}}
    for _,f in ipairs(filters) do
        local active=(self.shopFilter or "all")==f[1]
        drawFilledRect(x+f[3],y+h-0.126,f[4],0.022,active and 0.10 or 0.025,active and 0.38 or 0.10,active and 0.15 or 0.04,1)
        setTextColor(active and 1 or 0.65,active and 1 or 0.88,active and 1 or 0.68,1)
        renderText(x+f[3]+0.004,y+h-0.119,0.007,f[2])
    end

    local list=self:getFarmLinkShopItems()

    -- Numarul de unelte: sub filtre, deasupra primului produs.
    setTextColor(0.03,0.24,0.07,1)
    renderText(x+0.018,y+h-0.145,0.007,"Gasite: "..tostring(#list))

    local perPage=5
    local pages=math.max(1,math.ceil(#list/perPage))
    self.shopPage=math.max(1,math.min(pages,self.shopPage or 1))
    local first=(self.shopPage-1)*perPage+1

    if #list==0 then
        setTextColor(0.04,0.22,0.06,1)
        renderText(x+0.020,y+h-0.185,0.009,"Nu au fost gasite hand tools.")
    end

    for row=0,perPage-1 do
        local data=list[first+row]
        if data~=nil then
            local cy=y+h-0.169-(row*0.056)
            drawFilledRect(x+0.014,cy-0.034,w-0.028,0.048,0.018,0.055,0.025,0.98)
            drawFilledRect(x+0.014,cy+0.010,w-0.028,0.003,0.16,0.70,0.24,1)
            setTextColor(0.96,0.98,0.92,1); setTextBold(true)
            renderText(x+0.020,cy-0.005,0.0085,tostring(data.name))
            setTextBold(false)
            local src=data.source=="mod" and "MOD" or (data.source=="dlc" and "DLC" or "JOC")
            setTextColor(0.60,0.90,0.63,1)
            renderText(x+0.020,cy-0.021,0.0073,src.." | "..tostring(math.floor(data.price or 0)).." EUR")
        end
    end

    setTextColor(0.03,0.24,0.07,1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(x+w*0.5,y+0.041,0.0074,"Pagina "..tostring(self.shopPage).."/"..tostring(pages))
    setTextAlignment(RenderText.ALIGN_LEFT)
    drawFilledRect(x+0.022,y+0.034,0.034,0.022,0.025,0.10,0.04,1)
    drawFilledRect(x+w-0.056,y+0.034,0.034,0.022,0.025,0.10,0.04,1)
    setTextColor(0.75,1,0.78,1)
    renderText(x+0.035,y+0.041,0.0085,"<")
    renderText(x+w-0.044,y+0.041,0.0085,">")
end

function SmartPhone:drawFarmLinkShopDetails()
    -- BG drawFarmLinkShopDetails
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local data=self.selectedShopItem
    drawFilledRect(x+0.010,y+h-0.094,w-0.020,0.050,0.018,0.13,0.045,1)
    drawFilledRect(x+0.010,y+h-0.094,w-0.020,0.0041,0.16,0.70,0.24,1)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.013,"Unealta")
    setTextBold(false)
    drawFilledRect(x+w-0.060,y+h-0.084,0.044,0.025,0.04,0.20,0.07,1)
    setTextColor(0.75,1,0.78,1); renderText(x+w-0.052,y+h-0.076,0.008,"INAPOI")
    if data==nil then return end
    drawFilledRect(x+0.016,y+h-0.245,w-0.032,0.125,0.018,0.055,0.025,0.98)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.022,y+h-0.155,0.010,tostring(data.name))
    setTextBold(false)
    local src=data.source=="mod" and "MOD" or (data.source=="dlc" and "DLC" or "JOC")
    setTextColor(0.60,0.90,0.63,1)
    renderText(x+0.022,y+h-0.181,0.009,"Sursa: "..src)
    renderText(x+0.022,y+h-0.205,0.009,"Pret: "..tostring(math.floor(data.price or 0)).." EUR")
    drawFilledRect(x+0.030,y+0.082,w-0.060,0.042,0.10,0.38,0.15,1)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.055,y+0.096,0.010,"CUMPARA")
    setTextBold(false)
end

function SmartPhone:onFarmLinkHandToolBought(handTool, loadingState, callbackArguments)
    local player = g_localPlayer

    if handTool == nil then
        print("FS25 FarmLink Magazin - cumpararea s-a terminat, dar handTool=nil | loadingState=" .. tostring(loadingState))
        return
    end

    if player == nil then
        print("FS25 FarmLink Magazin - unealta a fost cumparata, dar g_localPlayer=nil")
        return
    end

    -- BuyHandToolData incarca unealta cu holder-ul transmis.
    -- Dupa ce incarcarea este terminata, o selectam ca unealta curenta.
    local canCarry = true
    if player.getCanPickupHandTool ~= nil then
        canCarry = player:getCanPickupHandTool(handTool)
    end

    if handTool.getCarryingPlayer ~= nil then
        local carryingPlayer = handTool:getCarryingPlayer()
        if carryingPlayer ~= player and canCarry and handTool.setHolder ~= nil then
            handTool:setHolder(player)
        end
    elseif canCarry and handTool.setHolder ~= nil then
        handTool:setHolder(player)
    end

    if player.setCurrentHandTool ~= nil then
        player:setCurrentHandTool(handTool)
    end

    if handTool.attachTool ~= nil then
        handTool:attachTool()
    end

    local held = false
    if handTool.getIsHeld ~= nil then
        held = handTool:getIsHeld()
    end

    print(
        "FS25 FarmLink Magazin - UNEALTA ECHIPATA: "
        .. tostring(self.selectedShopItem ~= nil and self.selectedShopItem.name or "handTool")
        .. " | held=" .. tostring(held)
        .. " | loadingState=" .. tostring(loadingState)
    )

    if self.addNotification ~= nil then
        self:addNotification(
            "Magazin FarmLink",
            tostring(self.selectedShopItem ~= nil and self.selectedShopItem.name or "Unealta") .. " este acum in mana."
        )
    end
end

function SmartPhone:buyFarmLinkHandTool()
    local data = self.selectedShopItem

    if data == nil or data.storeItem == nil then
        print("FS25 FarmLink Magazin - unealta selectata este invalida")
        return false
    end

    if BuyHandToolData == nil then
        print("FS25 FarmLink Magazin - BuyHandToolData indisponibil")
        return false
    end

    if g_currentMission == nil then
        print("FS25 FarmLink Magazin - misiune indisponibila")
        return false
    end

    local player = g_localPlayer
    if player == nil then
        print("FS25 FarmLink Magazin - g_localPlayer indisponibil")
        return false
    end

    local farmId = g_currentMission:getFarmId()
    if FarmManager ~= nil
    and farmId == FarmManager.SPECTATOR_FARM_ID then
        print("FS25 FarmLink Magazin - spectatorul nu poate cumpara")
        return false
    end

    local buyData = BuyHandToolData.new()
    buyData:setStoreItem(data.storeItem)
    buyData:setOwnerFarmId(farmId)

    -- BuyHandToolData foloseste acest holder in HandToolLoadingData.
    buyData.holder = player
    buyData:updatePrice()

    if buyData:isValid() ~= true then
        print("FS25 FarmLink Magazin - date cumparare invalide")
        return false
    end

    print(
        "FS25 FarmLink Magazin - CUMPARARE PORNITA: "
        .. tostring(data.name)
        .. " | pret=" .. tostring(buyData.price)
        .. " | farmId=" .. tostring(farmId)
        .. " | holder=PLAYER"
    )

    local ok, err = pcall(function()
        buyData:buy(self.onFarmLinkHandToolBought, self, nil)
    end)

    if not ok then
        print("FS25 FarmLink Magazin - EROARE CUMPARARE: " .. tostring(err))
        return false
    end

    if self.addNotification ~= nil then
        self:addNotification(
            "Magazin FarmLink",
            tostring(data.name) .. " a fost cumparata."
        )
    end

    return true
end
