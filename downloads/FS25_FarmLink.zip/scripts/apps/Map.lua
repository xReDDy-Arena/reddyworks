SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkMap = FarmLinkMap or {}
FarmLinkMap.id="map"
FarmLinkMap.title="Harta"

function SmartPhone:getFarmLinkMapData()
    local d={mapName="Harta curenta",owned=0,total=0,vehicles=0}
    if g_currentMission==nil then return d end

    if g_currentMission.missionInfo~=nil then
        d.mapName=tostring(g_currentMission.missionInfo.mapTitle or g_currentMission.missionInfo.mapId or d.mapName)
    end

    local farmId=nil
    if g_currentMission.getFarmId~=nil then
        local ok,v=pcall(function() return g_currentMission:getFarmId() end)
        if ok then farmId=v end
    end

    if g_farmlandManager~=nil and g_farmlandManager.farmlands~=nil then
        for _,f in pairs(g_farmlandManager.farmlands) do
            if f~=nil then
                d.total=d.total+1
                if farmId~=nil and f.farmId==farmId then d.owned=d.owned+1 end
            end
        end
    end

    local vehicles=nil
    if g_currentMission.vehicleSystem~=nil then vehicles=g_currentMission.vehicleSystem.vehicles end
    if vehicles==nil then vehicles=g_currentMission.vehicles end
    if vehicles~=nil then
        for _,v in pairs(vehicles) do
            if v~=nil then
                local owner=v.ownerFarmId
                if v.getOwnerFarmId~=nil then
                    local ok,val=pcall(function() return v:getOwnerFarmId() end)
                    if ok then owner=val end
                end
                if farmId==nil or owner==nil or owner==farmId then d.vehicles=d.vehicles+1 end
            end
        end
    end
    return d
end

function SmartPhone:drawFarmLinkMap()
    -- BG drawFarmLinkMap
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local d=self:getFarmLinkMapData()
    setTextColor(0.025,0.18,0.05,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Harta"); setTextBold(false)

    local bw,bh=0.048,0.025
    local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER); setTextBold(true)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)

    drawFilledRect(x+0.014,y+h-0.225,w-0.028,0.105,0.025,0.105,0.040,1)
    setTextColor(0.55,0.92,0.60,1); renderText(x+0.024,y+h-0.150,0.0077,"HARTA ACTIVA")
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    local n=d.mapName; if string.len(n)>22 then n=string.sub(n,1,20)..".." end
    renderText(x+0.024,y+h-0.182,0.009,n); setTextBold(false)

    local cy=y+h-0.330
    drawFilledRect(x+0.014,cy,w-0.028,0.078,0.025,0.105,0.040,1)
    setTextColor(0.58,0.78,0.61,1); renderText(x+0.024,cy+0.052,0.0072,"Terenuri detinute")
    renderText(x+0.085,cy+0.052,0.0072,"Utilaje")
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.024,cy+0.019,0.010,tostring(d.owned).."/"..tostring(d.total))
    renderText(x+0.085,cy+0.019,0.010,tostring(d.vehicles)); setTextBold(false)

    setTextColor(0.50,0.66,0.53,1)
    renderText(x+0.018,y+0.055,0.007,"Date reale din salvarea curenta")
end
