SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end


SmartPhone.contactsPage = SmartPhone.contactsPage or 1


--------------------------------------------------
-- NUMAR FARMLINK
--------------------------------------------------

-- Genereaza un numar FarmLink stabil din ID-ul contactului.
-- Acelasi userId produce acelasi numar.
function SmartPhone:getFarmLinkPhoneNumber(contact)

    if contact == nil then
        return "FL-000000"
    end

    local key = tostring(
        contact.userId
        or contact.name
        or "farmlink"
    )

    local hash = 5381

    for i = 1, string.len(key) do
        hash = (
            hash * 33
            + string.byte(key, i)
        ) % 900000
    end

    return string.format(
        "FL-%06d",
        hash + 100000
    )
end


--------------------------------------------------
-- CONTACTE
--------------------------------------------------

function SmartPhone:getFarmLinkContacts()

    local result = {}

    if g_currentMission == nil then
        return result
    end


    --------------------------------------------------
    -- ID JUCATOR LOCAL
    --------------------------------------------------

    local localUserId = nil

    if g_currentMission.playerUserId ~= nil then
        localUserId = g_currentMission.playerUserId
    end


    --------------------------------------------------
    -- MULTIPLAYER
    --------------------------------------------------

    if g_currentMission.userManager ~= nil
    and g_currentMission.userManager.getUsers ~= nil then

        local users =
            g_currentMission.userManager:getUsers()
            or {}

        for _, user in pairs(users) do

            local name = nil

            if user.getNickname ~= nil then
                name = user:getNickname()

            elseif user.nickname ~= nil then
                name = user.nickname
            end


            local userId = nil

            if user.getUniqueUserId ~= nil then
                userId = user:getUniqueUserId()
            else
                userId = user.uniqueUserId
            end


            if name ~= nil
            and tostring(name) ~= "" then

                table.insert(
                    result,
                    {
                        name = tostring(name),
                        userId = userId,

                        isMe =
                            userId ~= nil
                            and localUserId ~= nil
                            and userId == localUserId
                    }
                )
            end
        end
    end


    --------------------------------------------------
    -- SINGLEPLAYER / FALLBACK
    --------------------------------------------------

    if #result == 0 then

        local name = "Jucator"

        if g_currentMission.missionInfo ~= nil
        and g_currentMission.missionInfo.playerName ~= nil
        and g_currentMission.missionInfo.playerName ~= "" then

            name =
                g_currentMission.missionInfo.playerName

        elseif g_gameSettings ~= nil
        and g_gameSettings.getValue ~= nil then

            local ok, value = pcall(
                function()
                    return g_gameSettings:getValue(
                        "playerName"
                    )
                end
            )

            if ok
            and value ~= nil
            and tostring(value) ~= "" then

                name = tostring(value)
            end
        end


        table.insert(
            result,
            {
                name = tostring(name),
                userId = localUserId,
                isMe = true
            }
        )
    end


    --------------------------------------------------
    -- CONTACTE TEST
    --------------------------------------------------

    local testContacts = {




    }


    for _, testContact in ipairs(testContacts) do

        table.insert(
            result,
            testContact
        )
    end


    --------------------------------------------------
    -- NUMERE FARMLINK
    --------------------------------------------------

    for _, contact in ipairs(result) do

        contact.phoneNumber =
            self:getFarmLinkPhoneNumber(
                contact
            )
    end


    --------------------------------------------------
    -- SORTARE
    --------------------------------------------------

    table.sort(
        result,
        function(a, b)

            if a.isMe ~= b.isMe then
                return a.isMe == true
            end

            return
                string.lower(a.name)
                <
                string.lower(b.name)
        end
    )


    return result
end


--------------------------------------------------
-- DESENARE CONTACTE
--------------------------------------------------

function SmartPhone:drawFarmLinkContacts()

    -- BG drawFarmLinkContacts
    self:drawFarmLinkPageBackground()
    --------------------------------------------------
    -- RASPUNS TEST
    --------------------------------------------------

    if self.updateFarmLinkTestReply ~= nil then
        self:updateFarmLinkTestReply()
    end


    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH


    --------------------------------------------------
    -- HEADER
    --------------------------------------------------

    drawFilledRect(
        x + 0.010,
        y + h - 0.094,
        w - 0.020,
        0.050,
        0.018,
        0.13,
        0.045,
        1
    )

    drawFilledRect(
        x + 0.010,
        y + h - 0.094,
        w - 0.020,
        0.0041,
        0.16,
        0.70,
        0.24,
        1
    )


    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)

    renderText(
        x + 0.018,
        y + h - 0.070,
        0.014,
        "Contacte"
    )

    setTextBold(false)


    --------------------------------------------------
    -- INAPOI
    --------------------------------------------------

    drawFilledRect(
        x + w - 0.060,
        y + h - 0.084,
        0.044,
        0.025,
        0.04,
        0.20,
        0.07,
        1
    )

    setTextColor(
        0.75,
        1,
        0.78,
        1
    )

    renderText(
        x + w - 0.052,
        y + h - 0.076,
        0.008,
        "INAPOI"
    )


    --------------------------------------------------
    -- LISTA CONTACTE
    --------------------------------------------------

    local contacts =
        self:getFarmLinkContacts()

    local perPage = 6

    local pages =
        math.max(
            1,
            math.ceil(
                #contacts / perPage
            )
        )

    self.contactsPage =
        math.max(
            1,
            math.min(
                pages,
                self.contactsPage or 1
            )
        )


    local first =
        (self.contactsPage - 1)
        * perPage
        + 1


    --------------------------------------------------
    -- ONLINE
    --------------------------------------------------

    setTextColor(
        0.70,
        0.92,
        0.72,
        1
    )

    renderText(
        x + 0.018,
        y + h - 0.119,
        0.007,
        "Online: "
        .. tostring(#contacts)
    )


    --------------------------------------------------
    -- CONTACTE
    --------------------------------------------------

    for row = 0, perPage - 1 do

        local data =
            contacts[first + row]


        if data ~= nil then

            local cy =
                y + h
                - 0.155
                - (row * 0.050)


            --------------------------------------------------
            -- FUNDAL CONTACT
            --------------------------------------------------

            drawFilledRect(
                x + 0.014,
                cy - 0.030,
                w - 0.028,
                0.042,
                0.018,
                0.055,
                0.025,
                0.98
            )


            --------------------------------------------------
            -- BULINA ONLINE
            --------------------------------------------------

            drawFilledRect(
                x + 0.020,
                cy - 0.014,
                0.009,
                0.009,
                0.16,
                0.70,
                0.24,
                1
            )


            --------------------------------------------------
            -- NUME CONTACT
            --------------------------------------------------

            setTextColor(
                1,
                1,
                1,
                1
            )

            setTextBold(true)

            renderText(
                x + 0.035,
                cy - 0.009,
                0.0085,
                data.name
            )

            setTextBold(false)


            --------------------------------------------------
            -- NUMAR FARMLINK
            -- MAI MARE + MAI VIZIBIL
            --------------------------------------------------

            setTextColor(
                0.82,
                1.00,
                0.84,
                1
            )

            setTextBold(true)


            local numberText =
                tostring(
                    data.phoneNumber
                    or self:getFarmLinkPhoneNumber(
                        data
                    )
                )


            if data.isMe then

                renderText(
                    x + 0.035,
                    cy - 0.024,
                    0.0080,
                    "TU | "
                    .. numberText
                )

            else

                renderText(
                    x + 0.035,
                    cy - 0.024,
                    0.0080,
                    numberText
                )
            end


            setTextBold(false)


            --------------------------------------------------
            -- MESAJE NECITITE
            --------------------------------------------------

            local unreadKey =
                tostring(
                    data.userId
                    or data.name
                    or "unknown"
                )


            local unreadCount = 0


            if self.farmLinkUnreadByContact ~= nil then

                unreadCount =
                    self.farmLinkUnreadByContact[
                        unreadKey
                    ]
                    or 0
            end


            --------------------------------------------------
            -- BADGE NECITITE
            --------------------------------------------------

            if unreadCount > 0 then

                local badgeX =
                    x + w - 0.040

                local badgeY =
                    cy - 0.014


                drawFilledRect(
                    badgeX,
                    badgeY,
                    0.018,
                    0.016,
                    0.16,
                    0.70,
                    0.24,
                    1
                )


                setTextAlignment(
                    RenderText.ALIGN_CENTER
                )

                setTextColor(
                    1,
                    1,
                    1,
                    1
                )

                setTextBold(true)


                renderText(
                    badgeX + 0.009,
                    badgeY + 0.0045,
                    0.0068,
                    tostring(
                        unreadCount
                    )
                )


                setTextBold(false)

                setTextAlignment(
                    RenderText.ALIGN_LEFT
                )
            end
        end
    end


    --------------------------------------------------
    -- FARA CONTACTE
    --------------------------------------------------

    if #contacts == 0 then

        setTextColor(
            0.8,
            0.9,
            0.8,
            1
        )

        renderText(
            x + 0.020,
            y + h - 0.170,
            0.008,
            "Nu sunt contacte online."
        )
    end


    --------------------------------------------------
    -- PAGINA
    --------------------------------------------------

    setTextAlignment(
        RenderText.ALIGN_CENTER
    )

    setTextColor(
        0.70,
        0.92,
        0.72,
        1
    )


    renderText(
        x + w * 0.5,
        y + 0.041,
        0.0074,
        "Pagina "
        .. tostring(self.contactsPage)
        .. "/"
        .. tostring(pages)
    )


    setTextAlignment(
        RenderText.ALIGN_LEFT
    )


    --------------------------------------------------
    -- SAGETI PAGINI
    --------------------------------------------------

    drawFilledRect(
        x + 0.022,
        y + 0.034,
        0.034,
        0.022,
        0.025,
        0.10,
        0.04,
        1
    )


    drawFilledRect(
        x + w - 0.056,
        y + 0.034,
        0.034,
        0.022,
        0.025,
        0.10,
        0.04,
        1
    )


    setTextAlignment(
        RenderText.ALIGN_CENTER
    )

    setTextColor(
        0.75,
        1,
        0.78,
        1
    )


    renderText(
        x + 0.039,
        y + 0.041,
        0.0085,
        "<"
    )


    renderText(
        x + w - 0.039,
        y + 0.041,
        0.0085,
        ">"
    )


    setTextAlignment(
        RenderText.ALIGN_LEFT
    )
end


--------------------------------------------------
-- CLICK CONTACTE
--------------------------------------------------

function SmartPhone:handleFarmLinkContactsMouse(
    posX,
    posY
)

    local x =
        self.phoneX

    local y =
        self.phoneY


    local contacts =
        self:getFarmLinkContacts()


    local pages =
        math.max(
            1,
            math.ceil(
                #contacts / 6
            )
        )


    --------------------------------------------------
    -- INAPOI
    --------------------------------------------------

    if self:isMouseInside(
        posX,
        posY,
        x + self.phoneW - 0.060,
        y + self.phoneH - 0.084,
        0.044,
        0.025
    ) then

        self.currentPage = "home"

        return true
    end


    --------------------------------------------------
    -- PAGINA STANGA
    --------------------------------------------------

    if self:isMouseInside(
        posX,
        posY,
        x + 0.022,
        y + 0.034,
        0.034,
        0.022
    ) then

        self.contactsPage =
            math.max(
                1,
                (self.contactsPage or 1)
                - 1
            )

        return true
    end


    --------------------------------------------------
    -- PAGINA DREAPTA
    --------------------------------------------------

    if self:isMouseInside(
        posX,
        posY,
        x + self.phoneW - 0.056,
        y + 0.034,
        0.034,
        0.022
    ) then

        self.contactsPage =
            math.min(
                pages,
                (self.contactsPage or 1)
                + 1
            )

        return true
    end


    --------------------------------------------------
    -- CLICK PE CONTACT
    --------------------------------------------------

    local first =
        (
            (self.contactsPage or 1)
            - 1
        )
        * 6
        + 1


    for row = 0, 5 do

        local data =
            contacts[first + row]


        if data ~= nil then

            local cy =
                y
                + self.phoneH
                - 0.155
                - (row * 0.050)


            if self:isMouseInside(
                posX,
                posY,
                x + 0.014,
                cy - 0.030,
                self.phoneW - 0.028,
                0.042
            ) then


                self.messageContact =
                    data


                --------------------------------------------------
                -- MARCHEAZA CITIT
                --------------------------------------------------

                local readKey =
                    tostring(
                        data.userId
                        or data.name
                        or "unknown"
                    )


                self.farmLinkUnreadByContact =
                    self.farmLinkUnreadByContact
                    or {}


                local wasUnread =
                    self.farmLinkUnreadByContact[
                        readKey
                    ]
                    or 0


                if wasUnread > 0 then

                    self.farmLinkUnreadByContact[
                        readKey
                    ] = 0


                    self.farmLinkUnreadMessages =
                        math.max(
                            0,
                            (
                                self.farmLinkUnreadMessages
                                or 0
                            )
                            - wasUnread
                        )
                end


                --------------------------------------------------
                -- DESCHIDE CONVERSATIA
                --------------------------------------------------

                self.currentPage =
                    "messages"

                self.messageDraft =
                    ""


                print(
                    "FS25 FarmLink Mesaje - conversatie: "
                    .. tostring(
                        data.name
                    )
                )


                return true
            end
        end
    end


    return false
end