-- FarmLink v1.0.97.0
-- Aplicatia VREME - modul separat
-- Citeste doar date disponibile din mediul FS25 si foloseste fallback-uri sigure.

SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkWeather = FarmLinkWeather or {}

FarmLinkWeather.id = "weather"
FarmLinkWeather.title = "Vreme"

function FarmLinkWeather.open(phone)
    if phone ~= nil then
        phone.currentPage = "weather"
    end
end

local function farmLinkTry(call)
    local ok, value = pcall(call)
    if ok then return value end
    return nil
end

function SmartPhone:getFarmLinkWeatherData()
    local data = {
        time = "--:--",
        day = "--",
        temperature = nil,
        condition = "Date meteo active",
        rain = false,
        snow = false
    }

    if g_currentMission == nil or g_currentMission.environment == nil then
        data.condition = "Mediul jocului indisponibil"
        return data
    end

    local env = g_currentMission.environment

    if env.dayTime ~= nil then
        local minutes = math.floor((tonumber(env.dayTime) or 0) / 60000)
        data.time = string.format("%02d:%02d", math.floor(minutes / 60) % 24, minutes % 60)
    end

    data.day = env.currentDay or env.currentMonotonicDay or "--"

    local weather = env.weather
    if weather ~= nil then
        -- Incercam valorile expuse direct de versiunea curenta a jocului.
        data.temperature =
            tonumber(weather.temperature)
            or tonumber(weather.currentTemperature)
            or tonumber(weather.airTemperature)

        if weather.getCurrentTemperature ~= nil then
            local v = farmLinkTry(function() return weather:getCurrentTemperature() end)
            if tonumber(v) ~= nil then data.temperature = tonumber(v) end
        end

        local raining = nil
        if weather.getIsRaining ~= nil then
            raining = farmLinkTry(function() return weather:getIsRaining() end)
        end
        if raining == nil then
            raining = weather.isRaining
        end

        local snowing = nil
        if weather.getIsSnowing ~= nil then
            snowing = farmLinkTry(function() return weather:getIsSnowing() end)
        end
        if snowing == nil then
            snowing = weather.isSnowing
        end

        data.rain = raining == true
        data.snow = snowing == true

        if data.snow then
            data.condition = "Ninsoare"
        elseif data.rain then
            data.condition = "Ploaie"
        else
            local current =
                weather.currentWeather
                or weather.currentWeatherType
                or weather.weatherType

            local s = string.lower(tostring(current or ""))
            if string.find(s, "cloud", 1, true) ~= nil then
                data.condition = "Innorat"
            elseif string.find(s, "rain", 1, true) ~= nil then
                data.condition = "Ploaie"
            elseif string.find(s, "snow", 1, true) ~= nil then
                data.condition = "Ninsoare"
            elseif string.find(s, "sun", 1, true) ~= nil
                or string.find(s, "clear", 1, true) ~= nil then
                data.condition = "Senin"
            else
                data.condition = "Fara precipitatii"
            end
        end
    end

    return data
end

function SmartPhone:drawWeather()
    -- BG drawWeather
    self:drawFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local data = self:getFarmLinkWeatherData()

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Vreme")
    setTextBold(false)

    -- Buton identic cu celelalte aplicatii modulare.
    local bw,bh=0.048,0.025
    local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    drawFilledRect(x+0.014,y+h-0.235,w-0.028,0.120,0.025,0.105,0.040,1)

    setTextColor(0.55,0.92,0.60,1)
    setTextBold(true)
    renderText(x+0.024,y+h-0.145,0.008,"VREMEA ACUM")
    setTextBold(false)

    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(x+0.024,y+h-0.180,0.0120,data.condition)
    setTextBold(false)

    if data.temperature ~= nil then
        renderText(x+0.024,y+h-0.215,0.009,string.format("Temperatura: %.1f C",data.temperature))
    else
        setTextColor(0.62,0.76,0.64,1)
        renderText(x+0.024,y+h-0.215,0.0077,"Temperatura: indisponibila")
    end

    local cardY=y+h-0.345
    drawFilledRect(x+0.014,cardY,w-0.028,0.080,0.025,0.105,0.040,1)

    setTextColor(0.58,0.78,0.61,1)
    renderText(x+0.024,cardY+0.052,0.0075,"ORA DIN JOC")
    renderText(x+0.085,cardY+0.052,0.0075,"ZIUA")

    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(x+0.024,cardY+0.020,0.0100,tostring(data.time))
    renderText(x+0.085,cardY+0.020,0.0100,tostring(data.day))
    setTextBold(false)

    setTextColor(0.50,0.66,0.53,1)
    renderText(x+0.018,y+0.055,0.0072,"Date citite direct din FS25")
    setTextColor(0.96,0.98,0.92,1)
end
