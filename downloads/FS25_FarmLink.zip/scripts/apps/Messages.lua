SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end


SmartPhone.farmLinkTestReply = SmartPhone.farmLinkTestReply or nil


SmartPhone.messageHistory = SmartPhone.messageHistory or {}
SmartPhone.messageContact = SmartPhone.messageContact or nil
SmartPhone.messageDraft = SmartPhone.messageDraft or ""
SmartPhone.messageInputActive = SmartPhone.messageInputActive or false
SmartPhone.farmLinkUnreadByContact = SmartPhone.farmLinkUnreadByContact or {}


function SmartPhone:getFarmLinkMessageTime()
    -- FS25/GIANTS Lua nu expune os.date().
    -- Folosim timpul local al jocului/PC-ului deja disponibil in engine.
    if getDate ~= nil then
        local ok,hour,minute = pcall(getDate, "%H", "%M")
        if ok and hour ~= nil and minute ~= nil then
            return tostring(hour)..":"..tostring(minute)
        end
    end

    -- Fallback sigur: ora afisata nu trebuie sa blocheze trimiterea mesajului.
    return ""
end

function SmartPhone:getFarmLinkConversationKey(contact)
    if contact == nil then return "unknown" end
    return tostring(contact.userId or contact.name or "unknown")
end

function SmartPhone:getFarmLinkConversation(contact)
    local key=self:getFarmLinkConversationKey(contact)
    self.messageHistory[key]=self.messageHistory[key] or {}
    return self.messageHistory[key]
end

function SmartPhone:addFarmLinkMessage(text,outgoing)
    if self.messageContact==nil or text==nil or text=="" then return end
    local conversation=self:getFarmLinkConversation(self.messageContact)
    table.insert(conversation,{
        text=tostring(text),
        outgoing=outgoing==true,
        time=self:getFarmLinkMessageTime()
    })
end


function SmartPhone:scheduleFarmLinkTestReply(sentText, contact)
    local replies = {
        "Salut! Mesajul tau a ajuns.",
        "Da, FarmLink functioneaza!",
        "Am primit mesajul.",
        "Perfect! Acesta este un raspuns de test.",
        "Mesaj primit cu succes."
    }

    local index = ((#tostring(sentText or "")) % #replies) + 1
    self.farmLinkTestReply = {
        dueAt = (g_time or 0) + 1800,
        text = replies[index],
        contact = contact
    }
end

function SmartPhone:updateFarmLinkTestReply()
    local pending = self.farmLinkTestReply
    if pending == nil then return end
    if (g_time or 0) < (pending.dueAt or 0) then return end

    local testContact = pending.contact or {
        userId = "farmlink_test_player",
        name = "Jucator Test",
        isTest = true
    }
    local conversation = self:getFarmLinkConversation(testContact)
    table.insert(conversation, {
        text = tostring(pending.text or "Mesaj primit."),
        outgoing = false,
        time = self:getFarmLinkMessageTime()
    })

    -- Notificare FarmLink pentru mesajul nou.
    self.farmLinkMessageNotification = {
        title = "Mesaj nou",
        text = tostring(testContact.name or "Contact")..": "..tostring(pending.text or "Mesaj primit."),
        sender = tostring(testContact.name or "Contact"),
        createdAt = g_time or 0
    }
    self.farmLinkUnreadMessages = (self.farmLinkUnreadMessages or 0) + 1
    local unreadKey = self:getFarmLinkConversationKey(testContact)
    self.farmLinkUnreadByContact = self.farmLinkUnreadByContact or {}
    self.farmLinkUnreadByContact[unreadKey] = (self.farmLinkUnreadByContact[unreadKey] or 0) + 1

    self.farmLinkTestReply = nil
    print("FS25 FarmLink Mesaje TEST - raspuns automat primit")
end

function SmartPhone:getFarmLinkLocalNetworkIdentity()
    local resultId = nil
    local resultName = "Jucator"

    if g_currentMission ~= nil then
        if g_currentMission.missionInfo ~= nil
        and g_currentMission.missionInfo.playerName ~= nil
        and tostring(g_currentMission.missionInfo.playerName) ~= "" then
            resultName = tostring(g_currentMission.missionInfo.playerName)
        end

        local localUserId = g_currentMission.playerUserId
        local manager = g_currentMission.userManager
        if manager ~= nil then
            local user = nil
            if localUserId ~= nil and manager.getUserByUserId ~= nil then
                local ok, value = pcall(function() return manager:getUserByUserId(localUserId) end)
                if ok then user = value end
            end

            if user == nil and manager.getUsers ~= nil then
                local users = manager:getUsers() or {}
                for _, candidate in pairs(users) do
                    local candidateId = candidate.userId
                    if candidate.getId ~= nil then
                        local ok, value = pcall(function() return candidate:getId() end)
                        if ok and value ~= nil then candidateId = value end
                    end
                    if localUserId ~= nil and candidateId == localUserId then
                        user = candidate
                        break
                    end
                end
            end

            if user ~= nil then
                if user.getUniqueUserId ~= nil then
                    local ok, value = pcall(function() return user:getUniqueUserId() end)
                    if ok and value ~= nil then resultId = tostring(value) end
                elseif user.uniqueUserId ~= nil then
                    resultId = tostring(user.uniqueUserId)
                end

                if user.getNickname ~= nil then
                    local ok, value = pcall(function() return user:getNickname() end)
                    if ok and value ~= nil and tostring(value) ~= "" then resultName = tostring(value) end
                elseif user.nickname ~= nil and tostring(user.nickname) ~= "" then
                    resultName = tostring(user.nickname)
                end
            end
        end
    end

    return resultId, resultName
end

function SmartPhone:receiveFarmLinkNetworkMessage(targetUserId, senderUserId, senderName, text)
    local myUserId = self:getFarmLinkLocalNetworkIdentity()
    if myUserId == nil or tostring(targetUserId or "") ~= tostring(myUserId) then return end
    if text == nil or tostring(text) == "" then return end

    local contact = {
        userId = tostring(senderUserId or senderName or "unknown"),
        name = tostring(senderName or "Jucator"),
        isMe = false,
        isTest = false
    }
    local conversation = self:getFarmLinkConversation(contact)
    table.insert(conversation, {
        text = tostring(text),
        outgoing = false,
        time = self:getFarmLinkMessageTime()
    })

    self.farmLinkMessageNotification = {
        title = "Mesaj nou",
        text = contact.name..": "..tostring(text),
        sender = contact.name,
        createdAt = g_time or 0
    }
    self.farmLinkUnreadMessages = (self.farmLinkUnreadMessages or 0) + 1
    self.farmLinkUnreadByContact = self.farmLinkUnreadByContact or {}
    local key = self:getFarmLinkConversationKey(contact)
    self.farmLinkUnreadByContact[key] = (self.farmLinkUnreadByContact[key] or 0) + 1

    print("FS25 FarmLink MP - PRIMIT de la "..contact.name..": "..tostring(text))
end

function SmartPhone:sendFarmLinkMessage()
    local text=tostring(self.messageDraft or "")
    text=text:gsub("^%s+",""):gsub("%s+$","")
    if text=="" or self.messageContact==nil then return end

    self:addFarmLinkMessage(text,true)

    if self.messageContact.isTest == true then
        self:scheduleFarmLinkTestReply(text, self.messageContact)
    else
        local targetUserId = self.messageContact.userId
        local senderUserId, senderName = self:getFarmLinkLocalNetworkIdentity()

        if targetUserId ~= nil and senderUserId ~= nil
        and FarmLinkMessageEvent ~= nil
        and g_client ~= nil
        and g_client.getServerConnection ~= nil
        and g_client:getServerConnection() ~= nil then
            g_client:getServerConnection():sendEvent(
                FarmLinkMessageEvent.new(targetUserId, senderUserId, senderName, text)
            )
            print("FS25 FarmLink MP - TRIMIS: "..text.." -> "..tostring(self.messageContact.name))
        else
            print("FS25 FarmLink MP - mesajul nu a putut fi trimis: conexiune/ID indisponibil")
        end
    end

    print("FS25 FarmLink Mesaje - TRIMIS: "..text.." -> "..tostring(self.messageContact.name))
    self.messageDraft=""
    self.messageInputActive=true
end

function SmartPhone:drawFarmLinkMessages()
    -- BG drawFarmLinkMessages
    self:drawFarmLinkPageBackground()
    self:updateFarmLinkTestReply()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local contact=self.messageContact

    -- Conversatia deschisa este considerata citita.
    if contact ~= nil then
        local readKey = self:getFarmLinkConversationKey(contact)
        self.farmLinkUnreadByContact = self.farmLinkUnreadByContact or {}
        local wasUnread = self.farmLinkUnreadByContact[readKey] or 0
        if wasUnread > 0 then
            self.farmLinkUnreadByContact[readKey] = 0
            self.farmLinkUnreadMessages = math.max(0, (self.farmLinkUnreadMessages or 0) - wasUnread)
        end
    end

    drawFilledRect(x+0.010,y+h-0.094,w-0.020,0.050,0.018,0.13,0.045,1)
    drawFilledRect(x+0.010,y+h-0.094,w-0.020,0.0041,0.16,0.70,0.24,1)

    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.012,contact~=nil and tostring(contact.name) or "Mesaje")
    setTextBold(false)

    if contact ~= nil and self.getFarmLinkPhoneNumber ~= nil then
        setTextColor(0.60,0.90,0.63,1)
        renderText(x+0.018,y+h-0.084,0.0062,self:getFarmLinkPhoneNumber(contact))
    end

    drawFilledRect(x+w-0.060,y+h-0.084,0.044,0.025,0.04,0.20,0.07,1)
    setTextColor(0.75,1,0.78,1)
    renderText(x+w-0.052,y+h-0.076,0.008,"INAPOI")

    if contact==nil then
        setTextColor(0.75,0.90,0.78,1)
        renderText(x+0.020,y+h-0.155,0.008,"Alege un contact.")
        return
    end

    local conversation=self:getFarmLinkConversation(contact)
    local maxVisible=7
    local first=math.max(1,#conversation-maxVisible+1)
    local row=0

    for i=first,#conversation do
        local m=conversation[i]
        local cy=y+h-0.170-(row*0.041)
        local bw=w*0.68
        local bx=m.outgoing and (x+w-0.016-bw) or (x+0.016)

        if m.outgoing then
            drawFilledRect(bx,cy-0.027,bw,0.034,0.035,0.28,0.09,1)
        else
            drawFilledRect(bx,cy-0.027,bw,0.034,0.055,0.075,0.060,1)
        end

        setTextColor(0.96,0.98,0.92,1)
        renderText(bx+0.006,cy-0.009,0.0092,tostring(m.text))
        setTextColor(0.62,0.84,0.65,1)
        renderText(bx+0.006,cy-0.023,0.0065,
            (m.outgoing and "TU  " or tostring(contact.name).."  ")..tostring(m.time or ""))
        row=row+1
    end

    -- Bara de scriere.
    local inputX=x+0.014
    local inputY=y+0.049
    local sendW=0.038
    local gap=0.005
    local inputW=w-0.028-sendW-gap

    drawFilledRect(inputX,inputY,inputW,0.035,
        self.messageInputActive and 0.035 or 0.018,
        self.messageInputActive and 0.18 or 0.08,
        self.messageInputActive and 0.065 or 0.035,1)

    setTextColor(0.90,1,0.91,1)
    local shown=tostring(self.messageDraft or "")
    if shown=="" then
        setTextColor(0.48,0.68,0.50,1)
        shown="Scrie un mesaj..."
    elseif #shown>24 then
        shown="..."..string.sub(shown,-21)
    end
    renderText(inputX+0.006,inputY+0.011,0.0090,shown)

    local sendX=inputX+inputW+gap
    drawFilledRect(sendX,inputY,sendW,0.035,0.06,0.34,0.12,1)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(sendX+sendW*0.5,inputY+0.011,0.0076,"TRIMITE")
    setTextBold(true)

    setTextColor(0.96,0.98,0.92,1)
    setTextColor(0.02,0.16,0.04,1)
    -- Text ajutor: fortam alinierea LEFT ca sa nu mai iasa in afara telefonului.
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(true)
    setTextColor(0.02,0.16,0.04,1)
    renderText(inputX+0.006,inputY+0.043,0.0072,"Click pe bara si scrie de la tastatura")
    setTextBold(false)
end

function SmartPhone:handleFarmLinkMessagesMouse(posX,posY)
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH

    if self:isMouseInside(posX,posY,x+w-0.060,y+h-0.084,0.044,0.025) then
        self.messageInputActive=false
        self.currentPage="contacts"
        return true
    end

    if self.messageContact==nil then return false end

    local inputX=x+0.014
    local inputY=y+0.067
    local sendW=0.038
    local gap=0.005
    local inputW=w-0.028-sendW-gap
    local sendX=inputX+inputW+gap

    if self:isMouseInside(posX,posY,inputX,inputY,inputW,0.035) then
        self.messageInputActive=true
        return true
    end

    if self:isMouseInside(posX,posY,sendX,inputY,sendW,0.035) then
        self:sendFarmLinkMessage()
        return true
    end

    self.messageInputActive=false
    return false
end

function SmartPhone:handleFarmLinkMessageKey(unicode,key,modifier,isDown)
    if self.currentPage~="messages" or self.messageInputActive~=true or isDown~=true then
        return false
    end

    if key==Input.KEY_return or key==Input.KEY_enter then
        self:sendFarmLinkMessage()
        return true
    end

    if key==Input.KEY_backspace then
        local text=tostring(self.messageDraft or "")
        if #text>0 then self.messageDraft=string.sub(text,1,#text-1) end
        return true
    end

    if unicode~=nil and unicode>=32 then
        local text=tostring(self.messageDraft or "")
        if #text<80 then
            local ch=nil
            if unicode<=255 then
                ch=string.char(unicode)
            elseif utf8~=nil and utf8.char~=nil then
                local ok,value=pcall(utf8.char,unicode)
                if ok then ch=value end
            end
            if ch~=nil then self.messageDraft=text..ch end
        end
        return true
    end

    return false
end
