SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkPrices = FarmLinkPrices or {}
FarmLinkPrices.id="prices"
FarmLinkPrices.title="Preturi"

local function flPriceTry(fn)
    local ok,v=pcall(fn)
    if ok then return v end
    return nil
end

function SmartPhone:getFarmLinkPriceRows()
    local rows={}
    if g_currentMission==nil or g_fillTypeManager==nil then return rows end
    local sm=g_currentMission.sellingStationManager
    local stations=sm~=nil and sm.sellingStations or nil

    if g_fillTypeManager.fillTypes~=nil then
        for idx,ft in pairs(g_fillTypeManager.fillTypes) do
            if type(idx)=="number" and ft~=nil then
                local best=nil
                local where="Pret joc"
                if stations~=nil then
                    for _,s in pairs(stations) do
                        if s~=nil and s.getEffectiveFillTypePrice~=nil then
                            local p=tonumber(flPriceTry(function() return s:getEffectiveFillTypePrice(idx) end))
                            if p~=nil and p>0 and (best==nil or p>best) then
                                best=p
                                where=tostring(s.name or s.stationName or "Punct vanzare")
                            end
                        end
                    end
                end
                if best==nil and g_currentMission.economyManager~=nil
                and g_currentMission.economyManager.getPricePerLiter~=nil then
                    best=tonumber(flPriceTry(function()
                        return g_currentMission.economyManager:getPricePerLiter(idx)
                    end))
                end
                if best~=nil and best>0 then
                    table.insert(rows,{
                        name=tostring(ft.title or ft.name or ("Produs "..idx)),
                        price=best, station=where
                    })
                end
            end
        end
    end
    table.sort(rows,function(a,b) return string.lower(a.name)<string.lower(b.name) end)
    return rows
end

function SmartPhone:drawPrices()
    -- BG drawPrices
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local list=self:getFarmLinkPriceRows()
    setTextColor(0.025,0.18,0.05,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Preturi"); setTextBold(false)

    local bw,bh=0.048,0.025
    local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER); setTextBold(true)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(true)

    setTextColor(0.02,0.18,0.05,1)
    setTextBold(true)
    renderText(x+0.018,y+h-0.112,0.0100,"CELE MAI BUNE PRETURI")

    local perPage=5
    local pages=math.max(1,math.ceil(#list/perPage))
    self.pricesPage=math.max(1,math.min(pages,self.pricesPage or 1))
    local first=(self.pricesPage-1)*perPage+1

    if #list==0 then
        setTextColor(0.65,0.75,0.66,1)
        renderText(x+0.020,y+h-0.175,0.0077,"Nu sunt preturi disponibile.")
    else
        for row=0,perPage-1 do
            local item=list[first+row]
            if item~=nil then
                local cy=y+h-0.175-row*0.061
                drawFilledRect(x+0.014,cy,w-0.028,0.050,0.025,0.105,0.040,1)
                local n=item.name; if string.len(n)>18 then n=string.sub(n,1,16)..".." end
                local s=item.station; if string.len(s)>20 then s=string.sub(s,1,18)..".." end
                setTextColor(0.96,0.98,0.92,1); setTextBold(true)
                renderText(x+0.023,cy+0.029,0.008,n); setTextBold(false)
                setTextColor(0.58,0.76,0.61,1)
                renderText(x+0.023,cy+0.009,0.0075,s)
                setTextAlignment(RenderText.ALIGN_RIGHT); setTextColor(0.65,0.95,0.68,1); setTextBold(true)
                renderText(x+w-0.022,cy+0.027,0.0072,string.format("%.0f $",item.price*1000))
                setTextBold(false); setTextAlignment(RenderText.ALIGN_LEFT)
            end
        end
    end

    local ny=y+0.030
    drawFilledRect(x+0.018,ny,0.040,0.026,0.08,0.42,0.14,1)
    drawFilledRect(x+w-0.058,ny,0.040,0.026,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER); setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.038,ny+0.0081,0.010,"<")
    renderText(x+w/2,ny+0.0092,0.0081,"Pagina "..self.pricesPage.."/"..pages)
    renderText(x+w-0.038,ny+0.0081,0.010,">")
    setTextBold(false); setTextAlignment(RenderText.ALIGN_LEFT)
end
