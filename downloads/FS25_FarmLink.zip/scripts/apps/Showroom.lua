-- FarmLink v1.0.88.0
-- Aplicatia Showroom este separata de motorul principal al telefonului.

SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkShowroom = FarmLinkShowroom or {}

FarmLinkShowroom.id = "showroom"
FarmLinkShowroom.title = "Showroom"

function FarmLinkShowroom.open(phone)
    if phone ~= nil then
        phone.currentPage = "showroom"
    end
end

function SmartPhone:getDefaultVehicleConfigurations(item)

    local configurations = {}

    if item == nil then
        return configurations
    end

    if item.defaultConfigurationIds ~= nil then
        for name, index in pairs(item.defaultConfigurationIds) do
            configurations[name] = index
        end
    end

    if item.configurationSets ~= nil and #item.configurationSets > 0 then
        local defaultSetIndex = 1

        for i = 1, #item.configurationSets do
            if item.configurationSets[i].isDefault == true then
                defaultSetIndex = i
                break
            end
        end

        local configSet = item.configurationSets[defaultSetIndex]

        if configSet ~= nil and configSet.configurations ~= nil then
            for name, index in pairs(configSet.configurations) do
                configurations[name] = index
            end
        end
    end

    if item.configurations ~= nil then
        for name, configItems in pairs(item.configurations) do
            if configurations[name] == nil
            and configItems ~= nil
            and #configItems > 0 then

                local defaultIndex = nil

                for _, configItem in ipairs(configItems) do
                    if configItem.isDefault == true then
                        defaultIndex = configItem.index
                        break
                    end
                end

                if defaultIndex == nil then
                    defaultIndex = configItems[1].index or 1
                end

                configurations[name] = defaultIndex
            end
        end
    end

    return configurations

end

function SmartPhone:rentSelectedTractor()

    local data = self.selectedTractor

    if data == nil or data.storeItem == nil then
        print("FS25 FarmLink RENT - tractor invalid")
        return false
    end

    if BuyVehicleData == nil or BuyVehicleEvent == nil then
        print("FS25 FarmLink RENT - API inchiriere indisponibil")
        return false
    end

    if g_currentMission == nil then
        print("FS25 FarmLink RENT - misiune indisponibila")
        return false
    end

    if g_client == nil
    or g_client.getServerConnection == nil
    or g_client:getServerConnection() == nil then
        print("FS25 FarmLink RENT - conexiune server indisponibila")
        return false
    end

    local farmId = g_currentMission:getFarmId()

    if FarmManager ~= nil
    and farmId == FarmManager.SPECTATOR_FARM_ID then
        print("FS25 FarmLink RENT - spectatorul nu poate inchiria")
        return false
    end

    local item = data.storeItem
    local configurations = self:getConfiguredVehicleConfigurations(item)

    local buyData = BuyVehicleData.new()
    buyData:setStoreItem(item)
    buyData:setConfigurations(configurations, {})
    buyData:setOwnerFarmId(farmId)

    -- Sistemul nativ FS25 trateaza vehiculul ca leasing/inchiriere.
    buyData:setLeaseVehicle(true)
    buyData:updatePrice()

    if buyData:isValid() ~= true then
        print("FS25 FarmLink RENT - date inchiriere invalide")
        return false
    end

    print(
        "FS25 FarmLink RENT - trimit inchirierea: "
        .. tostring(data.name)
        .. " | pret="
        .. tostring(buyData.price)
        .. " | farmId="
        .. tostring(farmId)
    )

    g_client:getServerConnection():sendEvent(
        BuyVehicleEvent.new(buyData)
    )

    self:addNotification(
        "Inchiriere confirmata",
        tostring(data.name) .. " se pregateste pentru livrare."
    )

    return true

end

function SmartPhone:buySelectedTractor()

    local data = self.selectedTractor

    if data == nil or data.storeItem == nil then
        print("FS25 FarmLink BUY - tractor invalid")
        return false
    end

    if BuyVehicleData == nil or BuyVehicleEvent == nil then
        print("FS25 FarmLink BUY - API cumparare indisponibil")
        return false
    end

    if g_currentMission == nil then
        print("FS25 FarmLink BUY - misiune indisponibila")
        return false
    end

    if g_client == nil
    or g_client.getServerConnection == nil
    or g_client:getServerConnection() == nil then
        print("FS25 FarmLink BUY - conexiune server indisponibila")
        return false
    end

    local farmId = g_currentMission:getFarmId()

    if FarmManager ~= nil
    and farmId == FarmManager.SPECTATOR_FARM_ID then
        print("FS25 FarmLink BUY - spectatorul nu poate cumpara")
        return false
    end

    local item = data.storeItem
    local configurations = self:getConfiguredVehicleConfigurations(item)

    local buyData = BuyVehicleData.new()
    buyData:setStoreItem(item)
    buyData:setConfigurations(configurations, {})
    buyData:setOwnerFarmId(farmId)
    buyData:setLeaseVehicle(false)
    buyData:updatePrice()

    if buyData:isValid() ~= true then
        print("FS25 FarmLink BUY - date cumparare invalide")
        return false
    end

    print(
        "FS25 FarmLink BUY - trimit cumpararea: "
        .. tostring(data.name)
        .. " | pret="
        .. tostring(buyData.price)
        .. " | farmId="
        .. tostring(farmId)
    )

    g_client:getServerConnection():sendEvent(
        BuyVehicleEvent.new(buyData)
    )

    self:addNotification(
        "Comanda confirmata",
        tostring(data.name) .. " a fost comandat. Livrare la magazin."
    )

    return true

end


--------------------------------------------------
-- FARMLINK CONFIGURATOR - MOTOR REAL DIN STORE ITEM
--------------------------------------------------

function SmartPhone:loadSelectedTractorMotorOptions()

    self.tractorMotorOptions = {}
    self.tractorMotorOptionIndex = 1

    local data = self.selectedTractor
    if data == nil or data.storeItem == nil then
        return
    end

    local item = data.storeItem

    if StoreItemUtil ~= nil and StoreItemUtil.loadSpecsFromXML ~= nil then
        pcall(StoreItemUtil.loadSpecsFromXML, item)
    end

    local configurations = item.configurations
    if configurations == nil then
        print("FS25 FarmLink CONFIG - item.configurations indisponibil")
        return
    end

    local motorItems = configurations.motor
        or configurations.motorConfiguration
        or configurations.engine
        or configurations.engineConfiguration

    if motorItems == nil then
        for configName, configItems in pairs(configurations) do
            local key = string.lower(tostring(configName))
            if string.find(key, "motor", 1, true) ~= nil
            or string.find(key, "engine", 1, true) ~= nil then
                motorItems = configItems
                break
            end
        end
    end

    if motorItems == nil then
        print("FS25 FarmLink CONFIG - fara configuratii motor expuse")
        return
    end

    for _, configItem in pairs(motorItems) do
        if configItem ~= nil then
            local optionIndex = configItem.index or configItem.id or (#self.tractorMotorOptions + 1)
            local optionName = configItem.name
                or configItem.title
                or configItem.displayName
                or configItem.configName
                or ("Motor " .. tostring(optionIndex))

            local optionPrice = configItem.price or 0

            table.insert(self.tractorMotorOptions, {
                index = optionIndex,
                name = tostring(optionName),
                price = optionPrice
            })
        end
    end

    table.sort(self.tractorMotorOptions, function(a, b)
        return (tonumber(a.index) or 0) < (tonumber(b.index) or 0)
    end)

    local defaults = self:getDefaultVehicleConfigurations(item)
    local defaultMotor = defaults.motor
        or defaults.motorConfiguration
        or defaults.engine
        or defaults.engineConfiguration

    if defaultMotor ~= nil then
        for i, option in ipairs(self.tractorMotorOptions) do
            if option.index == defaultMotor then
                self.tractorMotorOptionIndex = i
                break
            end
        end
    end

    print("FS25 FarmLink CONFIG - optiuni motor gasite = " .. tostring(#self.tractorMotorOptions))
end

function SmartPhone:getSelectedMotorOption()

    if self.tractorMotorOptions == nil or #self.tractorMotorOptions == 0 then
        return nil
    end

    self.tractorMotorOptionIndex = math.max(
        1,
        math.min(self.tractorMotorOptionIndex or 1, #self.tractorMotorOptions)
    )

    return self.tractorMotorOptions[self.tractorMotorOptionIndex]
end

function SmartPhone:cycleSelectedMotorOption(direction)

    if self.tractorMotorOptions == nil or #self.tractorMotorOptions == 0 then
        return
    end

    local count = #self.tractorMotorOptions
    local index = (self.tractorMotorOptionIndex or 1) + direction

    if index < 1 then
        index = count
    elseif index > count then
        index = 1
    end

    self.tractorMotorOptionIndex = index

    local option = self:getSelectedMotorOption()
    if option ~= nil then
        print(
            "FS25 FarmLink CONFIG - motor selectat: "
            .. tostring(option.name)
            .. " | index="
            .. tostring(option.index)
        )
    end
end


--------------------------------------------------
-- FARMLINK CONFIGURATOR - ROTI REALE DIN STORE ITEM
--------------------------------------------------

function SmartPhone:loadSelectedTractorWheelOptions()

    self.tractorWheelOptions = {}
    self.tractorWheelOptionIndex = 1

    local data = self.selectedTractor
    if data == nil or data.storeItem == nil then
        return
    end

    local item = data.storeItem

    if StoreItemUtil ~= nil and StoreItemUtil.loadSpecsFromXML ~= nil then
        pcall(StoreItemUtil.loadSpecsFromXML, item)
    end

    local configurations = item.configurations
    if configurations == nil then
        print("FS25 FarmLink CONFIG - item.configurations indisponibil pentru roti")
        return
    end

    local wheelItems = configurations.wheel
        or configurations.wheels
        or configurations.wheelConfiguration
        or configurations.tire
        or configurations.tires

    if wheelItems == nil then
        for configName, configItems in pairs(configurations) do
            local key = string.lower(tostring(configName))
            if string.find(key, "wheel", 1, true) ~= nil
            or string.find(key, "tire", 1, true) ~= nil
            or string.find(key, "tyre", 1, true) ~= nil
            or string.find(key, "roti", 1, true) ~= nil then
                wheelItems = configItems
                break
            end
        end
    end

    if wheelItems == nil then
        print("FS25 FarmLink CONFIG - fara configuratii roti expuse")
        return
    end

    for _, configItem in pairs(wheelItems) do
        if configItem ~= nil then
            local optionIndex = configItem.index or configItem.id or (#self.tractorWheelOptions + 1)
            local optionName = configItem.name
                or configItem.title
                or configItem.displayName
                or configItem.configName
                or ("Roti " .. tostring(optionIndex))

            table.insert(self.tractorWheelOptions, {
                index = optionIndex,
                name = tostring(optionName),
                price = configItem.price or 0
            })
        end
    end

    table.sort(self.tractorWheelOptions, function(a, b)
        return (tonumber(a.index) or 0) < (tonumber(b.index) or 0)
    end)

    local defaults = self:getDefaultVehicleConfigurations(item)
    local defaultWheel = defaults.wheel
        or defaults.wheels
        or defaults.wheelConfiguration
        or defaults.tire
        or defaults.tires

    if defaultWheel ~= nil then
        for i, option in ipairs(self.tractorWheelOptions) do
            if option.index == defaultWheel then
                self.tractorWheelOptionIndex = i
                break
            end
        end
    end

    print("FS25 FarmLink CONFIG - optiuni roti gasite = " .. tostring(#self.tractorWheelOptions))
end

function SmartPhone:getSelectedWheelOption()

    if self.tractorWheelOptions == nil or #self.tractorWheelOptions == 0 then
        return nil
    end

    self.tractorWheelOptionIndex = math.max(
        1,
        math.min(self.tractorWheelOptionIndex or 1, #self.tractorWheelOptions)
    )

    return self.tractorWheelOptions[self.tractorWheelOptionIndex]
end

function SmartPhone:cycleSelectedWheelOption(direction)

    if self.tractorWheelOptions == nil or #self.tractorWheelOptions == 0 then
        return
    end

    local count = #self.tractorWheelOptions
    local index = (self.tractorWheelOptionIndex or 1) + direction

    if index < 1 then
        index = count
    elseif index > count then
        index = 1
    end

    self.tractorWheelOptionIndex = index

    local option = self:getSelectedWheelOption()
    if option ~= nil then
        print(
            "FS25 FarmLink CONFIG - roti selectate: "
            .. tostring(option.name)
            .. " | index="
            .. tostring(option.index)
        )
    end
end


--------------------------------------------------
-- FARMLINK CONFIGURATOR - CULOARE REALA DIN STORE ITEM
--------------------------------------------------

function SmartPhone:loadSelectedTractorColorOptions()

    self.tractorColorOptions = {}
    self.tractorColorOptionIndex = 1

    local data = self.selectedTractor
    if data == nil or data.storeItem == nil then
        return
    end

    local item = data.storeItem

    if StoreItemUtil ~= nil and StoreItemUtil.loadSpecsFromXML ~= nil then
        pcall(StoreItemUtil.loadSpecsFromXML, item)
    end

    local configurations = item.configurations
    if configurations == nil then
        return
    end

    local colorItems = configurations.designColor
        or configurations.baseColor
        or configurations.color
        or configurations.designColorConfiguration
        or configurations.baseColorConfiguration

    if colorItems == nil then
        for configName, configItems in pairs(configurations) do
            local key = string.lower(tostring(configName))
            if string.find(key, "color", 1, true) ~= nil
            or string.find(key, "colour", 1, true) ~= nil then
                colorItems = configItems
                break
            end
        end
    end

    if colorItems == nil then
        print("FS25 FarmLink CONFIG - fara configuratii culoare expuse")
        return
    end

    for _, configItem in pairs(colorItems) do
        if configItem ~= nil then
            local optionIndex = configItem.index or configItem.id or (#self.tractorColorOptions + 1)
            local optionName = configItem.name
                or configItem.title
                or configItem.displayName
                or configItem.configName
                or ("Culoare " .. tostring(optionIndex))

            table.insert(self.tractorColorOptions, {
                index = optionIndex,
                name = tostring(optionName),
                price = configItem.price or 0
            })
        end
    end

    table.sort(self.tractorColorOptions, function(a, b)
        return (tonumber(a.index) or 0) < (tonumber(b.index) or 0)
    end)

    local defaults = self:getDefaultVehicleConfigurations(item)
    local defaultColor = defaults.designColor
        or defaults.baseColor
        or defaults.color
        or defaults.designColorConfiguration
        or defaults.baseColorConfiguration

    if defaultColor ~= nil then
        for i, option in ipairs(self.tractorColorOptions) do
            if option.index == defaultColor then
                self.tractorColorOptionIndex = i
                break
            end
        end
    end

    print("FS25 FarmLink CONFIG - optiuni culoare gasite = " .. tostring(#self.tractorColorOptions))
end

function SmartPhone:getSelectedColorOption()
    if self.tractorColorOptions == nil or #self.tractorColorOptions == 0 then
        return nil
    end

    self.tractorColorOptionIndex = math.max(
        1,
        math.min(self.tractorColorOptionIndex or 1, #self.tractorColorOptions)
    )

    return self.tractorColorOptions[self.tractorColorOptionIndex]
end

function SmartPhone:cycleSelectedColorOption(direction)
    if self.tractorColorOptions == nil or #self.tractorColorOptions == 0 then
        return
    end

    local count = #self.tractorColorOptions
    local index = (self.tractorColorOptionIndex or 1) + direction

    if index < 1 then
        index = count
    elseif index > count then
        index = 1
    end

    self.tractorColorOptionIndex = index
end

function SmartPhone:getConfiguredVehicleConfigurations(item)

    local configurations = self:getDefaultVehicleConfigurations(item)

    local motor = self:getSelectedMotorOption()
    if motor ~= nil then
        if configurations.motor ~= nil then
            configurations.motor = motor.index
        elseif configurations.motorConfiguration ~= nil then
            configurations.motorConfiguration = motor.index
        elseif configurations.engine ~= nil then
            configurations.engine = motor.index
        elseif configurations.engineConfiguration ~= nil then
            configurations.engineConfiguration = motor.index
        end
    end

    local wheels = self:getSelectedWheelOption()
    if wheels ~= nil then
        if configurations.wheel ~= nil then
            configurations.wheel = wheels.index
        elseif configurations.wheels ~= nil then
            configurations.wheels = wheels.index
        elseif configurations.wheelConfiguration ~= nil then
            configurations.wheelConfiguration = wheels.index
        elseif configurations.tire ~= nil then
            configurations.tire = wheels.index
        elseif configurations.tires ~= nil then
            configurations.tires = wheels.index
        end
    end

    local color = self:getSelectedColorOption()
    if color ~= nil then
        if configurations.designColor ~= nil then
            configurations.designColor = color.index
        elseif configurations.baseColor ~= nil then
            configurations.baseColor = color.index
        elseif configurations.color ~= nil then
            configurations.color = color.index
        elseif configurations.designColorConfiguration ~= nil then
            configurations.designColorConfiguration = color.index
        elseif configurations.baseColorConfiguration ~= nil then
            configurations.baseColorConfiguration = color.index
        end
    end

    return configurations
end


--------------------------------------------------
-- FARMLINK SHOWROOM - COMBINE / CAMIOANE / MASINI / UTILAJE
--------------------------------------------------

function SmartPhone:getGenericCategoryInfo(categoryType)
    local all = {
        combines={title="Combine", keys={"combine","harvester","forageharvester","cottonharvester","potatoharvester","beetharvester"}},
        trucks={title="Camioane", keys={"truck","trucks"}},
        cars={title="Masini", keys={"car","cars"}},
        tools={title="Utilaje", keys={"cultivator","plow","seeder","planter","sprayer","spreader","mower","tedder","windrower","baler","foragewagon","trailer","lowloader","frontloadertools","teleloadertools","wheelloadertools","subsoiler","discharrows","powerharrows","rollers","mulcher","stonepicker"}}
    }
    return all[categoryType]
end

function SmartPhone:getStoreCategoryNames(item)

    local result = {}

    if item == nil then
        return result
    end

    -- FS25 StoreManager keeps the real shop categories here.
    if item.categoryNames ~= nil then
        for _, categoryName in pairs(item.categoryNames) do
            if categoryName ~= nil then
                table.insert(result, string.upper(tostring(categoryName)))
            end
        end
    end

    -- Backwards-compatible fallback.
    if #result == 0 and item.categoryName ~= nil then
        table.insert(result, string.upper(tostring(item.categoryName)))
    end

    return result
end

function SmartPhone:hasExactStoreCategory(item, allowedCategories)

    local categories = self:getStoreCategoryNames(item)

    for _, actual in ipairs(categories) do
        local normalizedActual = string.gsub(actual, "[^A-Z0-9]", "")

        for _, allowed in ipairs(allowedCategories) do
            local normalizedAllowed = string.gsub(
                string.upper(tostring(allowed)),
                "[^A-Z0-9]",
                ""
            )

            if normalizedActual == normalizedAllowed then
                return true
            end
        end
    end

    return false
end

function SmartPhone:itemMatchesGenericCategory(item, categoryType)

    if item == nil then
        return false
    end

    -- Do not show hidden/non-store items.
    if item.showInStore == false then
        return false
    end

    -- IMPORTANT:
    -- No name/XML substring matching here.
    -- We use only FS25's real StoreManager categoryNames.

    if categoryType == "combines" then
        -- Grain combines ONLY.
        -- Headers, seeders and forestry machines cannot pass this whitelist.
        return self:hasExactStoreCategory(item, {
            "HARVESTERS"
        })

    elseif categoryType == "trucks" then
        return self:hasExactStoreCategory(item, {
            "TRUCKS"
        })

    elseif categoryType == "cars" then
        return self:hasExactStoreCategory(item, {
            "CARS"
        })

    elseif categoryType == "tools" then
        return self:hasExactStoreCategory(item, {
            "PLOWS",
            "CULTIVATORS",
            "DISC_HARROWS",
            "POWER_HARROWS",
            "SUBSOILERS",
            "SEEDERS",
            "PLANTERS",
            "SPRAYERS",
            "FERTILIZER_SPREADERS",
            "MANURE_SPREADERS",
            "MOWERS",
            "TEDDERS",
            "WINDROWERS",
            "BALERS",
            "FORAGE_WAGONS",
            "TRAILERS",
            "AUGER_WAGONS",
            "ROLLERS",
            "MULCHERS",
            "STONE_PICKERS",
            "WEEDERS",
            "LEVELERS"
        })
    end

    return false
end

function SmartPhone:loadGenericCatalog(categoryType)
    self.genericCatalog={}
    self.genericCatalogType=categoryType
    self.genericCatalogPage=1
    self.selectedGenericItem=nil
    if g_storeManager==nil then return end
    local seen={}
    local function add(item)
        if item==nil or not self:itemMatchesGenericCategory(item,categoryType) then return end
        local key=tostring(item.xmlFilename or item.name or item)
        if seen[key] then return end
        seen[key]=true
        local xml=string.lower(tostring(item.xmlFilename or ""))
        local source="JOC"
        if string.find(xml,"pdlc",1,true) or string.find(xml,"dlc",1,true) then source="DLC"
        elseif string.find(xml,"$moddir$",1,true) or string.find(xml,"mods/",1,true) or string.find(xml,"mods\\",1,true) then source="MOD" end
        table.insert(self.genericCatalog,{name=tostring(item.name or "Produs"),price=tonumber(item.price) or 0,storeItem=item,source=source})

        local categoryList = self:getStoreCategoryNames(item)
        print(
            "FS25 FarmLink ACCEPT "
            .. tostring(categoryType)
            .. " | "
            .. tostring(item.name)
            .. " | CAT="
            .. table.concat(categoryList, ",")
        )
    end
    if g_storeManager.items then for _,item in pairs(g_storeManager.items) do add(item) end end
    if g_storeManager.xmlFilenameToItem then for _,item in pairs(g_storeManager.xmlFilenameToItem) do add(item) end end
    table.sort(self.genericCatalog,function(a,b) return string.lower(a.name)<string.lower(b.name) end)
    print("FS25 FarmLink SHOWROOM "..tostring(categoryType).." = "..tostring(#self.genericCatalog))
end

function SmartPhone:buyOrRentGenericItem(isLease)
    local data=self.selectedGenericItem
    if data==nil or data.storeItem==nil or BuyVehicleData==nil or BuyVehicleEvent==nil or g_currentMission==nil or g_client==nil then return false end
    local connection=g_client:getServerConnection()
    if connection==nil then return false end
    local farmId=g_currentMission:getFarmId()
    if FarmManager~=nil and farmId==FarmManager.SPECTATOR_FARM_ID then return false end
    local item=data.storeItem
    local buyData=BuyVehicleData.new()
    buyData:setStoreItem(item)
    buyData:setConfigurations(self:getDefaultVehicleConfigurations(item),{})
    buyData:setOwnerFarmId(farmId)
    buyData:setLeaseVehicle(isLease==true)
    buyData:updatePrice()
    if buyData:isValid()~=true then return false end
    connection:sendEvent(BuyVehicleEvent.new(buyData))
    return true
end

function SmartPhone:drawGenericCatalog()
    -- BG drawGenericCatalog
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local info=self:getGenericCategoryInfo(self.genericCatalogType)
    local title=info and info.title or "Showroom"
    local items=self.genericCatalog or {}
    setTextColor(0.96,0.98,0.92,1); setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.0145,title); setTextBold(false)
    local bw,bh=0.048,0.025
    local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextBold(true); setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)
    setTextColor(0.55,0.90,0.60,1)
    renderText(x+0.018,y+h-0.120,0.0092,"Gasite: "..tostring(#items))
    -- 4 carduri/pagina: al cincilea intra in zona de navigatie a telefonului.
    local perPage=4
    local pages=math.max(1,math.ceil(#items/perPage))
    self.genericCatalogPage=math.max(1,math.min(self.genericCatalogPage or 1,pages))
    local first=(self.genericCatalogPage-1)*perPage+1
    local cx,cw,ch=x+0.014,w-0.028,0.052
    local sy,gap=y+h-0.190,0.0092
    for row=1,perPage do
        local d=items[first+row-1]
        if d then
            local cy=sy-(row-1)*(ch+gap)
            drawFilledRect(cx,cy,cw,ch,0.025,0.105,0.040,1)
            local n=d.name; if string.len(n)>22 then n=string.sub(n,1,20)..".." end
            setTextColor(0.96,0.98,0.92,1); setTextBold(true); renderText(cx+0.010,cy+0.029,0.0083,n); setTextBold(false)
            setTextColor(0.60,0.86,0.64,1); renderText(cx+0.010,cy+0.011,0.0081,tostring(d.price).." $")
            setTextAlignment(RenderText.ALIGN_RIGHT); renderText(cx+cw-0.010,cy+0.011,0.0077,d.source); setTextAlignment(RenderText.ALIGN_LEFT)
        end
    end
    -- Navigatie identica cu lista de Tractoare.
    -- Sta separat sub produse, fara sa intre peste ultimul card.
    local navY = y + 0.040
    local navW = 0.034
    local navH = 0.022
    local prevX = x + 0.022
    local nextX = x + w - 0.022 - navW

    drawFilledRect(prevX,navY,navW,navH,0.08,0.42,0.14,1)
    drawFilledRect(nextX,navY,navW,navH,0.08,0.42,0.14,1)

    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(prevX + navW / 2, navY + 0.0068, 0.0085, "<")
    renderText(x + w / 2, navY + 0.0072, 0.0074,
        "Pagina " .. tostring(self.genericCatalogPage) .. "/" .. tostring(pages))
    renderText(nextX + navW / 2, navY + 0.0068, 0.0085, ">")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
end

function SmartPhone:drawGenericDetails()
    -- BG drawGenericDetails
    self:drawFarmLinkPageBackground()
    local x,y,w,h=self.phoneX,self.phoneY,self.phoneW,self.phoneH
    local d=self.selectedGenericItem
    if d==nil or d.storeItem==nil then return end
    local title=d.name; if string.len(title)>21 then title=string.sub(title,1,19)..".." end
    local bw,bh=0.048,0.025; local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true); setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi"); setTextAlignment(RenderText.ALIGN_LEFT)
    drawFilledRect(x+0.014,y+h-0.112,w-0.085,0.027,0.08,0.42,0.14,1)
    renderText(x+0.021,y+h-0.104,0.0078,title); setTextBold(false)
    self:drawTractorStoreImage(d,x+0.014,y+0.215,w-0.028,0.155)
    local cx,cy,cw,ch=x+0.018,y+0.092,w-0.036,0.105
    drawFilledRect(cx,cy,cw,ch,0.025,0.105,0.040,1)
    setTextColor(0.55,0.90,0.60,1); setTextBold(true); renderText(cx+0.010,cy+ch-0.027,0.0092,"DETALII"); setTextBold(false)
    setTextColor(0.70,0.78,0.71,1); renderText(cx+0.010,cy+0.048,0.008,"Sursa"); renderText(cx+0.010,cy+0.021,0.008,"Pret")
    setTextColor(0.96,0.98,0.92,1); setTextBold(true); setTextAlignment(RenderText.ALIGN_RIGHT)
    renderText(cx+cw-0.010,cy+0.048,0.0083,d.source); renderText(cx+cw-0.010,cy+0.021,0.0083,tostring(d.price).." $")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)
    local ay,bw2,gap=y+0.045,0.052,0.0092; local buyX=x+0.020; local rentX=buyX+bw2+gap
    drawFilledRect(buyX,ay,bw2,0.030,0.08,0.42,0.14,1)
    drawFilledRect(rentX,ay,bw2,0.030,0.52,0.30,0.08,1)
    setTextColor(0.96,0.98,0.92,1); setTextBold(true); setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(buyX+bw2/2,ay+0.009,0.008,"BUY"); renderText(rentX+bw2/2,ay+0.009,0.0078,"RENT")
    setTextAlignment(RenderText.ALIGN_LEFT); setTextBold(false)
end

--------------------------------------------------
-- FARMLINK REALISM - LOCK SCREEN + NOTIFICARI
--------------------------------------------------

function SmartPhone:isTractorStoreItem(item)

    if item == nil or item.showInStore == false then
        return false
    end

    local categories = item.categoryNames

    if categories ~= nil then
        for _, categoryName in pairs(categories) do
            local upperName = string.upper(tostring(categoryName))
            if string.find(upperName, "TRACTOR", 1, true) ~= nil then
                return true
            end
        end
    end

    if item.categoryName ~= nil then
        local upperName = string.upper(tostring(item.categoryName))
        if string.find(upperName, "TRACTOR", 1, true) ~= nil then
            return true
        end
    end

    return false
end

function SmartPhone:getStoreItemSource(item)

    if item == nil then
        return "game"
    end

    -- ModHub / mod ZIP
    if item.isMod == true then
        return "mod"
    end

    -- DLC / expansion / extra content.
    -- FS25 store items can expose the owning DLC/package through
    -- different fields depending on the content.
    local dlcTitle = item.dlcTitle
        or item.dlcName
        or item.dlcId
        or item.dlcIdentifier
        or item.packageName

    if dlcTitle ~= nil and tostring(dlcTitle) ~= "" then
        return "dlc"
    end

    -- Some items expose a custom environment/package but are not mods.
    if item.customEnvironment ~= nil
    and tostring(item.customEnvironment) ~= ""
    and item.isMod ~= true then
        return "dlc"
    end

    return "game"
end

function SmartPhone:printTractorCategoryDiagnostics()

    local small = 0
    local medium = 0
    local large = 0
    local unknown = 0

    print("FS25 FarmLink - ===== DIAGNOSTIC CATEGORII TRACTOARE =====")

    for _, data in ipairs(self.tractorCatalog or {}) do
        local sizeClass = self:getTractorSizeClass(data)

        if sizeClass == "small" then
            small = small + 1
        elseif sizeClass == "medium" then
            medium = medium + 1
        elseif sizeClass == "large" then
            large = large + 1
        else
            unknown = unknown + 1

            local item = data.storeItem
            local categoryText = ""

            if item ~= nil then
                if item.categoryName ~= nil then
                    categoryText = categoryText .. tostring(item.categoryName)
                end

                if item.categoryNames ~= nil then
                    for _, categoryName in pairs(item.categoryNames) do
                        categoryText = categoryText .. " | " .. tostring(categoryName)
                    end
                end
            end

            print(
                "FS25 FarmLink - NECUNOSCUT: "
                .. tostring(data.name)
                .. " | SOURCE="
                .. tostring(data.source)
                .. " | CATEGORY="
                .. categoryText
            )
        end
    end

    print(
        "FS25 FarmLink - CATEGORII: MICI="
        .. tostring(small)
        .. " | MEDII="
        .. tostring(medium)
        .. " | MARI="
        .. tostring(large)
        .. " | NECUNOSCUTE="
        .. tostring(unknown)
        .. " | TOTAL="
        .. tostring(#(self.tractorCatalog or {}))
    )

    print("FS25 FarmLink - ===========================================")
end

function SmartPhone:diagnoseMissingTractorCandidates(items)

    if items == nil then
        return
    end

    local candidates = {}
    local categoryCounts = {}

    for _, item in pairs(items) do
        if item ~= nil and item.showInStore ~= false and not self:isTractorStoreItem(item) then
            local categoryText = ""

            if item.categoryName ~= nil then
                categoryText = categoryText .. tostring(item.categoryName)
            end

            if item.categoryNames ~= nil then
                for _, categoryName in pairs(item.categoryNames) do
                    if categoryText ~= "" then
                        categoryText = categoryText .. "|"
                    end
                    categoryText = categoryText .. tostring(categoryName)
                end
            end

            local upper = string.upper(categoryText)

            -- Broad candidate search: items that look tractor-like but failed our current filter.
            local looksLikeTractor =
                string.find(upper, "TRACT", 1, true) ~= nil
                or string.find(upper, "VEHICLE", 1, true) ~= nil
                or string.find(upper, "MACHINE", 1, true) ~= nil

            if looksLikeTractor then
                local source = self:getStoreItemSource(item)

                table.insert(candidates, {
                    name = item.name or "Fara nume",
                    source = source,
                    category = categoryText,
                    xmlFilename = item.xmlFilename or "-"
                })

                categoryCounts[categoryText] = (categoryCounts[categoryText] or 0) + 1
            end
        end
    end

    table.sort(candidates, function(a, b)
        return string.lower(tostring(a.name)) < string.lower(tostring(b.name))
    end)

    print("FS25 FarmLink - ===== POSIBILE TRACTOARE RATATE =====")
    print("FS25 FarmLink - CANDIDATI RATATI = " .. tostring(#candidates))

    for _, data in ipairs(candidates) do
        print(
            "FS25 FarmLink - RATAT: "
            .. tostring(data.name)
            .. " | SOURCE=" .. tostring(data.source)
            .. " | CATEGORY=" .. tostring(data.category)
            .. " | XML=" .. tostring(data.xmlFilename)
        )
    end

    print("FS25 FarmLink - ===== CATEGORII CANDIDATI RATATI =====")
    for categoryName, count in pairs(categoryCounts) do
        print(
            "FS25 FarmLink - CATEGORIE RATATA: "
            .. tostring(categoryName)
            .. " | COUNT=" .. tostring(count)
        )
    end

    print("FS25 FarmLink - =====================================")
end

function SmartPhone:loadTractorCatalog()

    self.tractorCatalog = {}

    if g_storeManager == nil
    or g_storeManager.getItems == nil then
        print("FS25 FarmLink - g_storeManager indisponibil")
        self.tractorCatalogLoaded = true
        return
    end

    local items = g_storeManager:getItems()

    if items == nil then
        print("FS25 FarmLink - lista magazin indisponibila")
        self.tractorCatalogLoaded = true
        return
    end

    local gameCount = 0
    local dlcCount = 0
    local modCount = 0

    for _, item in pairs(items) do

        if self:isTractorStoreItem(item) then

            local source = self:getStoreItemSource(item)
            local isMod = source == "mod"
            local isDlc = source == "dlc"

            if isMod then
                modCount = modCount + 1
            elseif isDlc then
                dlcCount = dlcCount + 1
            else
                gameCount = gameCount + 1
            end

            table.insert(
                self.tractorCatalog,
                {
                    storeItem = item,
                    name = item.name or "Tractor",
                    price = item.price or 0,
                    source = source,
                    isMod = isMod,
                    isDlc = isDlc
                }
            )
        end
    end

    table.sort(
        self.tractorCatalog,
        function(a, b)
            return string.lower(a.name) < string.lower(b.name)
        end
    )

    self.tractorCatalogLoaded = true

    print(
        "FS25 FarmLink - TRACTOARE GASITE = "
        .. tostring(#self.tractorCatalog)
        .. " | JOC="
        .. tostring(gameCount)
        .. " | DLC="
        .. tostring(dlcCount)
        .. " | MODURI="
        .. tostring(modCount)
    )

    print(
        "FS25 FarmLink - MAGAZIN TOTAL ITEMS = "
        .. tostring(#items)
        .. " | TRACTOARE AFISATE = "
        .. tostring(#self.tractorCatalog)
    )

    self:printTractorCategoryDiagnostics()
end

function SmartPhone:getTractorSizeClass(data)

    if data == nil or data.storeItem == nil then
        return "unknown"
    end

    local item = data.storeItem
    local names = {}

    if item.categoryName ~= nil then
        table.insert(names, tostring(item.categoryName))
    end

    if item.categoryNames ~= nil then
        for _, categoryName in pairs(item.categoryNames) do
            table.insert(names, tostring(categoryName))
        end
    end

    local text = string.upper(table.concat(names, " "))

    -- Categorii reale folosite de magazinul FS25.
    -- Verificam intai categoria, nu puterea motorului.
    if string.find(text, "TRACTORSS", 1, true) ~= nil
    or string.find(text, "SMALLTRACTORS", 1, true) ~= nil
    or string.find(text, "SMALL TRACTORS", 1, true) ~= nil then
        return "small"
    end

    if string.find(text, "TRACTORSM", 1, true) ~= nil
    or string.find(text, "MEDIUMTRACTORS", 1, true) ~= nil
    or string.find(text, "MEDIUM TRACTORS", 1, true) ~= nil then
        return "medium"
    end

    if string.find(text, "TRACTORSL", 1, true) ~= nil
    or string.find(text, "LARGETRACTORS", 1, true) ~= nil
    or string.find(text, "LARGE TRACTORS", 1, true) ~= nil
    or string.find(text, "SUPERLARGETRACTORS", 1, true) ~= nil then
        return "large"
    end

    -- Compatibilitate cu variante interne/localizate.
    if string.find(text, "SMALL", 1, true) ~= nil then
        return "small"
    elseif string.find(text, "MEDIUM", 1, true) ~= nil then
        return "medium"
    elseif string.find(text, "LARGE", 1, true) ~= nil then
        return "large"
    end

    return "unknown"
end

function SmartPhone:getFilteredTractors()

    local result = {}

    for _, data in ipairs(self.tractorCatalog or {}) do

        local sourceOk =
            self.tractorCatalogFilter == "all"
            or (self.tractorCatalogFilter == "game" and data.source == "game")
            or (self.tractorCatalogFilter == "dlc" and data.source == "dlc")
            or (self.tractorCatalogFilter == "mods" and data.source == "mod")

        local sizeClass = self:getTractorSizeClass(data)

        local sizeOk =
            self.tractorSizeFilter == nil
            or self.tractorSizeFilter == "all"
            or self.tractorSizeFilter == sizeClass

        if sourceOk and sizeOk then
            table.insert(result, data)
        end
    end

    return result
end


--------------------------------------------------
-- SHOWROOM - TRACTOARE
--------------------------------------------------

function SmartPhone:drawShowroomTractors()

    -- BG drawShowroomTractors
    self:drawFarmLinkPageBackground()
    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    if self.tractorCatalogLoaded ~= true then
        self:loadTractorCatalog()
    end

    local tractors = self:getFilteredTractors()
    local perPage = 5
    local totalPages = math.max(1, math.ceil(#tractors / perPage))

    self.tractorCatalogPage = self.tractorCatalogPage or 1
    self.tractorCatalogPage = math.max(1, math.min(self.tractorCatalogPage, totalPages))

    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.064, 0.0145, "Tractoare")
    setTextBold(false)

    local backW = 0.046
    local backH = 0.024
    local backX = x + w - backW - 0.016
    local backY = y + h - 0.080

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)
    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(backX + backW / 2, backY + 0.0083, 0.009, "< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- FILTRE
    local filterY = y + h - 0.115
    local gap = 0.0041
    local filterW = (w - 0.036 - gap * 3) / 4
    local filterH = 0.025
    local filters = {
        {"all", "TOATE"},
        {"game", "JOC"},
        {"dlc", "DLC"},
        {"mods", "MOD"}
    }

    for i, filterData in ipairs(filters) do
        local fx = x + 0.018 + (i - 1) * (filterW + gap)
        local active = self.tractorCatalogFilter == filterData[1]

        if active then
            drawFilledRect(fx,filterY,filterW,filterH,0.08,0.46,0.16,1)
        else
            drawFilledRect(fx,filterY,filterW,filterH,0.035,0.15,0.065,1)
        end

        setTextColor(0.96, 0.98, 0.92, 1)
        setTextBold(active)
        setTextAlignment(RenderText.ALIGN_CENTER)
        renderText(fx + filterW / 2, filterY + 0.0086, 0.0071, filterData[2])
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextBold(false)
    end

    -- FILTRE MARIME
    local sizeY = y + h - 0.148
    local sizeGap = 0.0041
    local sizeW = (w - 0.036 - sizeGap * 3) / 4
    local sizeH = 0.025
    local sizeFilters = {
        {"all", "TOATE"},
        {"small", "MICI"},
        {"medium", "MEDII"},
        {"large", "MARI"}
    }

    for i, sizeData in ipairs(sizeFilters) do
        local sx = x + 0.018 + (i - 1) * (sizeW + sizeGap)
        local active = self.tractorSizeFilter == sizeData[1]

        if active then
            drawFilledRect(sx,sizeY,sizeW,sizeH,0.08,0.46,0.16,1)
        else
            drawFilledRect(sx,sizeY,sizeW,sizeH,0.035,0.15,0.065,1)
        end

        setTextColor(0.96, 0.98, 0.92, 1)
        setTextBold(active)
        setTextAlignment(RenderText.ALIGN_CENTER)
        renderText(sx + sizeW / 2, sizeY + 0.0081, 0.008, sizeData[2])
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextBold(false)
    end

    setTextColor(0.92, 0.98, 0.93, 1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.158, 0.0095, "Gasite: " .. tostring(#tractors))

    -- Rezumat categorii pentru filtrul curent de sursa
    local sizeSmall = 0
    local sizeMedium = 0
    local sizeLarge = 0

    for _, sizeData in ipairs(self.tractorCatalog or {}) do
        local sourceOk =
            self.tractorCatalogFilter == "all"
            or (self.tractorCatalogFilter == "game" and sizeData.source == "game")
            or (self.tractorCatalogFilter == "dlc" and sizeData.source == "dlc")
            or (self.tractorCatalogFilter == "mods" and sizeData.source == "mod")

        if sourceOk then
            local cls = self:getTractorSizeClass(sizeData)
            if cls == "small" then
                sizeSmall = sizeSmall + 1
            elseif cls == "medium" then
                sizeMedium = sizeMedium + 1
            elseif cls == "large" then
                sizeLarge = sizeLarge + 1
            end
        end
    end

    setTextColor(0.62, 0.75, 0.64, 1)
    setTextBold(false)
    renderText(
        x + 0.018,
        y + h - 0.171,
        0.0066,
        "Mici " .. tostring(sizeSmall)
        .. "  Medii " .. tostring(sizeMedium)
        .. "  Mari " .. tostring(sizeLarge)
    )
    setTextBold(false)

    local firstIndex = (self.tractorCatalogPage - 1) * perPage + 1
    local lastIndex = math.min(firstIndex + perPage - 1, #tractors)
    local rowY = y + 0.265
    local rowH = 0.039

    for i = firstIndex, lastIndex do
        local data = tractors[i]

        drawFilledRect(x + 0.018,rowY,w - 0.036,rowH,0.025,0.105,0.040,1)

        setTextColor(0.96, 0.98, 0.92, 1)
        setTextBold(true)
        local displayName = tostring(data.name)
        if string.len(displayName) > 22 then
            displayName = string.sub(displayName, 1, 20) .. ".."
        end
        renderText(x + 0.024, rowY + 0.022, 0.0092, displayName)
        setTextBold(false)

        if data.source == "mod" then
            setTextColor(0.35, 0.95, 0.42, 1)
            renderText(x + 0.024, rowY + 0.009, 0.0069, "MOD")
        elseif data.source == "dlc" then
            setTextColor(0.95, 0.78, 0.28, 1)
            renderText(x + 0.024, rowY + 0.009, 0.0069, "DLC")
        else
            setTextColor(0.65, 0.72, 0.66, 1)
            renderText(x + 0.024, rowY + 0.009, 0.0069, "JOC")
        end

        setTextColor(0.90, 0.95, 0.90, 1)
        setTextBold(true)
        setTextAlignment(RenderText.ALIGN_RIGHT)
        renderText(x + w - 0.026, rowY + 0.010, 0.0082, tostring(data.price) .. " $")
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextBold(false)

        rowY = rowY - 0.046
    end

    local navY = y + 0.034
    local navW = 0.034
    local navH = 0.022
    local prevX = x + 0.022
    local nextX = x + w - 0.022 - navW

    drawFilledRect(prevX,navY,navW,navH,0.08,0.42,0.14,1)
    drawFilledRect(nextX,navY,navW,navH,0.08,0.42,0.14,1)

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(prevX + navW / 2, navY + 0.0068, 0.0085, "<")
    renderText(x + w / 2, navY + 0.0072, 0.0074, "Pagina " .. tostring(self.tractorCatalogPage) .. "/" .. tostring(totalPages))
    renderText(nextX + navW / 2, navY + 0.0068, 0.0085, ">")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

end


--------------------------------------------------
-- DETALII TRACTOR
--------------------------------------------------

function SmartPhone:getTractorBrand(item)

    if item == nil then
        return "-"
    end

    if item.brandIndex ~= nil
    and g_brandManager ~= nil
    and g_brandManager.getBrandByIndex ~= nil then

        local brand = g_brandManager:getBrandByIndex(item.brandIndex)

        if brand ~= nil then
            if brand.title ~= nil and tostring(brand.title) ~= "" then
                return tostring(brand.title)
            end

            if brand.name ~= nil and tostring(brand.name) ~= "" and brand.name ~= "NONE" then
                return tostring(brand.name)
            end
        end
    end

    if item.brandNameRaw ~= nil and tostring(item.brandNameRaw) ~= "" then
        return tostring(item.brandNameRaw)
    end

    return "-"
end

function SmartPhone:getTractorPower(item)

    if item == nil then
        return nil, nil
    end

    -- FS25 Motorized store specs.
    if Motorized ~= nil and Motorized.getSpecValuePower ~= nil then
        local ok, minPower, maxPower = pcall(
            Motorized.getSpecValuePower,
            item,
            nil,
            nil,
            nil,
            true,
            true
        )

        if ok and minPower ~= nil then
            return minPower, maxPower or minPower
        end
    end

    if item.specs ~= nil and item.specs.power ~= nil then
        return item.specs.power, item.specs.power
    end

    if item.configurations ~= nil and item.configurations["motor"] ~= nil then
        local minPower = nil
        local maxPower = nil

        for _, configItem in ipairs(item.configurations["motor"]) do
            if configItem.power ~= nil then
                minPower = math.min(minPower or math.huge, configItem.power)
                maxPower = math.max(maxPower or 0, configItem.power)
            end
        end

        if minPower ~= nil then
            return minPower, maxPower
        end
    end

    return nil, nil
end

function SmartPhone:getTractorMaxSpeed(item)

    if item == nil then
        return nil
    end

    -- IMPORTANT FS25:
    -- StoreItem-ul poate exista in catalog fara ca toate specificatiile
    -- vehiculului sa fi fost incarcate din XML. Magazinul jocului le incarca
    -- inainte sa ceara viteza, deci facem acelasi lucru aici.
    if StoreItemUtil ~= nil and StoreItemUtil.loadSpecsFromXML ~= nil then
        pcall(StoreItemUtil.loadSpecsFromXML, item)
    end

    -- FS25: incearca mai intai valoarea oficiala incarcata pentru magazin.
    if item.specs ~= nil and item.specs.maxSpeed ~= nil then
        return item.specs.maxSpeed
    end

    -- Unele vehicule tin viteza in configuratia motorului.
    if item.configurations ~= nil and item.configurations["motor"] ~= nil then
        local best = nil
        for _, configItem in ipairs(item.configurations["motor"]) do
            if configItem ~= nil and configItem.maxSpeed ~= nil then
                best = math.max(best or 0, configItem.maxSpeed)
            end
        end
        if best ~= nil and best > 0 then
            return best
        end
    end

    -- In FS25 viteza de magazin poate veni si din configuratia rotilor.
    if item.configurations ~= nil and item.configurations["wheel"] ~= nil then
        local best = nil
        for _, configItem in ipairs(item.configurations["wheel"]) do
            if configItem ~= nil then
                local value = configItem.maxForwardSpeedShop or configItem.maxSpeed
                if value ~= nil then
                    best = math.max(best or 0, value)
                end
            end
        end
        if best ~= nil and best > 0 then
            return best
        end
    end

    -- API oficial Motorized. returnValues=true cere valoarea numerica.
    if Motorized ~= nil and Motorized.getSpecValueMaxSpeed ~= nil then
        local ok, speed = pcall(
            Motorized.getSpecValueMaxSpeed,
            item,
            nil,
            nil,
            nil,
            true,
            false
        )
        if ok and type(speed) == "number" then
            return speed
        end

        -- Fallback: cere textul oficial al magazinului si extrage numarul.
        local okText, speedText = pcall(
            Motorized.getSpecValueMaxSpeed,
            item,
            nil,
            nil,
            nil,
            false,
            false
        )
        if okText and speedText ~= nil then
            local number = tostring(speedText):match("(%d+)")
            if number ~= nil then
                return tonumber(number)
            end
        end
    end

    return nil
end

function SmartPhone:getTractorSourceLabel(data)

    if data == nil then
        return "JOC"
    end

    if data.source == "mod" then
        return "MOD"
    elseif data.source == "dlc" then
        return "DLC"
    end

    return "JOC"
end

function SmartPhone:getTractorImagePath(data)

    if data == nil or data.storeItem == nil then
        return nil
    end

    local item = data.storeItem

    -- FS25 StoreItemUtil salveaza imaginea magazinului direct aici.
    -- Nu folosim fileExists(): imaginile jocului pot fi pe cai virtuale GIANTS
    -- care sunt valide pentru Overlay chiar daca testul clasic de fisier esueaza.
    if item.imageFilename ~= nil and tostring(item.imageFilename) ~= "" then
        return tostring(item.imageFilename)
    end

    -- Fallback pentru unele moduri.
    local fallbackNames = {
        "imageFilenameSmall",
        "storeImageFilename",
        "storeImage",
        "image"
    }

    for _, fieldName in ipairs(fallbackNames) do
        local filename = item[fieldName]
        if filename ~= nil and tostring(filename) ~= "" then
            return tostring(filename)
        end
    end

    return nil
end

function SmartPhone:getTractorImageOverlay(data)

    if data == nil then
        return nil
    end

    local item = data.storeItem
    if item == nil then
        return nil
    end

    local key = tostring(item.xmlFilename or item.name or data.name or "tractor")

    if self.tractorImageOverlays[key] ~= nil then
        return self.tractorImageOverlays[key]
    end

    local imagePath = self:getTractorImagePath(data)

    if imagePath == nil then
        return nil
    end

    local overlay = Overlay.new(imagePath, 0, 0, 1, 1)

    if overlay ~= nil then
        self.tractorImageOverlays[key] = overlay
        self.tractorImagePaths[key] = imagePath
        return overlay
    end

    return nil
end

function SmartPhone:drawTractorStoreImage(data, x, y, w, h)

    -- Background keeps the page clean even if a store item has no image.
    drawFilledRect(x,y,w,h,0.018,0.070,0.030,1)

    local overlay = self:getTractorImageOverlay(data)

    if overlay ~= nil then
        overlay:setPosition(x, y)
        overlay:setDimension(w, h)
        overlay:render()
        return true
    end

    setTextColor(0.55, 0.63, 0.56, 1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(
        x + w / 2,
        y + h / 2 - 0.0054,
        0.0075,
        "Imagine indisponibila"
    )
    setTextAlignment(RenderText.ALIGN_LEFT)

    return false
end

function SmartPhone:drawTractorDetails()

    -- BG drawTractorDetails
    self:drawFarmLinkPageBackground()
    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    local data = self.selectedTractor

    if data == nil or data.storeItem == nil then
        setTextColor(0.025,0.18,0.05,1)
        setTextBold(true)
        renderText(x + 0.018, y + h - 0.070, 0.014, "Detalii tractor")
        setTextBold(false)

        setTextColor(0.80, 0.86, 0.81, 1)
        renderText(x + 0.018, y + 0.250, 0.0086, "Tractor indisponibil.")
        return
    end

    local item = data.storeItem
    local brand = self:getTractorBrand(item)
    local minPower, maxPower = self:getTractorPower(item)
    local maxSpeed = self:getTractorMaxSpeed(item)
    local sourceLabel = self:getTractorSourceLabel(data)

    local powerText = "Indisponibil"
    if minPower ~= nil then
        if maxPower ~= nil and maxPower ~= minPower then
            powerText = tostring(math.floor(minPower + 0.5))
                .. " - "
                .. tostring(math.floor(maxPower + 0.5))
                .. " CP"
        else
            powerText = tostring(math.floor(minPower + 0.5)) .. " CP"
        end
    end

    local speedText = "Indisponibil"
    if maxSpeed ~= nil then
        speedText = tostring(math.floor(maxSpeed + 0.5)) .. " km/h"
    end

    local title = tostring(data.name or "Tractor")
    if string.len(title) > 20 then
        title = string.sub(title, 1, 18) .. ".."
    end

    -- Inapoi compact dreapta
    local backW = 0.046
    local backH = 0.024
    local backX = x + w - backW - 0.016
    local backY = y + h - 0.080

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(backX + backW / 2, backY + 0.0083, 0.009, "< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- Header curat: FarmLink sus, numele tractorului dedesubt.
    -- Pretul de sus si badge-ul JOC/DLC/MOD au fost eliminate.
    local infoX = x + 0.014
    local infoW = w - 0.085
    local infoH = 0.027
    local nameY = y + h - 0.078
    local priceY = y + h - 0.112

    -- FarmLink in chenarul de sus
    drawFilledRect(infoX,nameY,infoW,infoH,0.08,0.42,0.14,1)

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(infoX + infoW / 2, nameY + 0.0092, 0.0092, "FarmLink")

    -- Numele tractorului in locul vechiului PRET
    drawFilledRect(infoX,priceY,infoW,infoH,0.08,0.42,0.14,1)

    setTextAlignment(RenderText.ALIGN_LEFT)
    renderText(infoX + 0.008, priceY + 0.0092, 0.0078, title)
    setTextBold(false)

    -- Buton CONFIGUREAZA
    local configX = x + 0.014
    local configY = y + h - 0.147
    local configW = 0.072
    local configH = 0.025

    drawFilledRect(configX,configY,configW,configH,0.055,0.24,0.10,1)
    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(configX + configW / 2, configY + 0.0086, 0.0077, "CONFIGUREAZA")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- Imagine reala din magazinul FS25
    local imageX = x + 0.014
    local imageY = y + 0.220
    local imageW = w - 0.028
    local imageH = 0.145

    self:drawTractorStoreImage(
        data,
        imageX,
        imageY,
        imageW,
        imageH
    )

    -- Card specificatii
    local cardX = x + 0.018
    local cardY = y + 0.072
    local cardW = w - 0.036
    local cardH = 0.142

    drawFilledRect(cardX,cardY,cardW,cardH,0.025,0.105,0.040,1)

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    renderText(cardX + 0.010, cardY + cardH - 0.027, 0.0092, "SPECIFICATII")
    setTextBold(false)

    local labelX = cardX + 0.010
    local valueX = cardX + cardW - 0.010
    local lineY = cardY + cardH - 0.049
    local lineStep = 0.026

    local function drawSpec(label, value)
        setTextColor(0.68, 0.76, 0.69, 1)
        renderText(labelX, lineY, 0.0083, label)

        setTextColor(0.96, 0.98, 0.92, 1)
        setTextBold(true)
        setTextAlignment(RenderText.ALIGN_RIGHT)
        renderText(valueX, lineY, 0.0086, tostring(value))
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextBold(false)

        lineY = lineY - lineStep
    end

    drawSpec("Marca", brand)
    drawSpec("Putere", powerText)
    drawSpec("Viteza max.", speedText)
    drawSpec("Sursa", sourceLabel)

    -- Bara de actiuni de jos - doar vizuala in v1.0.76.0
    -- Este plasata in spatiul liber dintre cardul SPECIFICATII si bara alba de jos.
    local actionY = y + 0.034
    local actionH = 0.027
    local actionX = x + 0.014
    local priceW = 0.045
    local buttonW = 0.025
    local actionGap = 0.0027

    drawFilledRect(actionX,actionY,priceW,actionH,0.025,0.105,0.040,1)

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(
        actionX + priceW / 2,
        actionY + 0.0082,
        0.0079,
        tostring(data.price or 0) .. " $"
    )

    -- FarmLink realist: cumparare + inchiriere din telefon.
    -- Vanzarea se face fizic prin sistemele jocului, nu din telefon.
    local actionButtonW = 0.038
    local buyX = actionX + priceW + actionGap
    local rentX = buyX + actionButtonW + actionGap

    drawFilledRect(buyX,actionY,actionButtonW,actionH,0.08,0.42,0.14,1)
    drawFilledRect(rentX,actionY,actionButtonW,actionH,0.52,0.30,0.08,1)

    renderText(buyX + actionButtonW / 2, actionY + 0.0082, 0.0075, "BUY")
    renderText(rentX + actionButtonW / 2, actionY + 0.0082, 0.0071, "RENT")

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
    setTextColor(0.96, 0.98, 0.92, 1)

end


--------------------------------------------------
-- CONFIGURATOR TRACTOR - PASUL 1
--------------------------------------------------

function SmartPhone:drawTractorConfigure()

    -- BG drawTractorConfigure
    self:drawFarmLinkPageBackground()
    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH
    local data = self.selectedTractor

    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x + 0.018, y + h - 0.064, 0.0150, "Configurare")
    setTextBold(false)

    local backW = 0.046
    local backH = 0.024
    local backX = x + w - backW - 0.016
    local backY = y + h - 0.080

    drawFilledRect(backX,backY,backW,backH,0.08,0.42,0.14,1)
    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(backX + backW / 2, backY + 0.0083, 0.009, "< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    local title = "Tractor"
    if data ~= nil and data.name ~= nil then
        title = tostring(data.name)
    end
    if string.len(title) > 22 then
        title = string.sub(title, 1, 20) .. ".."
    end

    drawFilledRect(x + 0.018,y + h - 0.120,w - 0.036,0.036,0.025,0.105,0.040,1)
    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    renderText(x + 0.028, y + h - 0.107, 0.009, title)
    setTextBold(false)

    setTextColor(0.72, 0.80, 0.73, 1)
    renderText(x + 0.020, y + h - 0.165, 0.0082, "CONFIGURATOR FARMLINK")

    local boxX = x + 0.018
    local boxW = w - 0.036
    local boxH = 0.048
    local motorY = y + 0.265
    local wheelsY = y + 0.205
    local colorY = y + 0.145

    drawFilledRect(boxX,motorY,boxW,boxH,0.035,0.15,0.065,1)
    drawFilledRect(boxX,wheelsY,boxW,boxH,0.035,0.15,0.065,1)
    drawFilledRect(boxX,colorY,boxW,boxH,0.035,0.15,0.065,1)

    local motorOption = self:getSelectedMotorOption()
    local motorText = "Indisponibil"
    if motorOption ~= nil then
        motorText = tostring(motorOption.name)
        if string.len(motorText) > 18 then
            motorText = string.sub(motorText, 1, 16) .. ".."
        end
    end

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(boxX + 0.013, motorY + 0.018, 0.009, "<")
    renderText(boxX + boxW - 0.013, motorY + 0.018, 0.009, ">")
    renderText(boxX + boxW / 2, motorY + 0.023, 0.0082, "Motor")
    setTextBold(false)
    setTextColor(0.65, 0.92, 0.69, 1)
    renderText(boxX + boxW / 2, motorY + 0.0092, 0.008, motorText)
    setTextAlignment(RenderText.ALIGN_LEFT)

    local wheelOption = self:getSelectedWheelOption()
    local wheelText = "Indisponibil"
    if wheelOption ~= nil then
        wheelText = tostring(wheelOption.name)
        if string.len(wheelText) > 18 then
            wheelText = string.sub(wheelText, 1, 16) .. ".."
        end
    end

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(boxX + 0.013, wheelsY + 0.018, 0.009, "<")
    renderText(boxX + boxW - 0.013, wheelsY + 0.018, 0.009, ">")
    renderText(boxX + boxW / 2, wheelsY + 0.023, 0.0082, "Roti")
    setTextBold(false)
    setTextColor(0.65, 0.92, 0.69, 1)
    renderText(boxX + boxW / 2, wheelsY + 0.0092, 0.008, wheelText)
    setTextAlignment(RenderText.ALIGN_LEFT)

    local colorOption = self:getSelectedColorOption()
    local colorText = "Indisponibil"
    if colorOption ~= nil then
        colorText = tostring(colorOption.name)
        if string.len(colorText) > 18 then
            colorText = string.sub(colorText, 1, 16) .. ".."
        end
    end

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(boxX + 0.013, colorY + 0.018, 0.009, "<")
    renderText(boxX + boxW - 0.013, colorY + 0.018, 0.009, ">")
    renderText(boxX + boxW / 2, colorY + 0.023, 0.0082, "Culoare")
    setTextBold(false)
    setTextColor(0.65, 0.92, 0.69, 1)
    renderText(boxX + boxW / 2, colorY + 0.0092, 0.008, colorText)
    setTextAlignment(RenderText.ALIGN_LEFT)

    setTextColor(0.60, 0.72, 0.62, 1)
    if self.tractorMotorOptions ~= nil and #self.tractorMotorOptions > 0 then
        renderText(x + 0.020, y + 0.090, 0.0081, "Motor:" .. tostring(#self.tractorMotorOptions) .. "  Roti:" .. tostring(#(self.tractorWheelOptions or {})) .. "  Cul:" .. tostring(#(self.tractorColorOptions or {})))
        renderText(x + 0.020, y + 0.071, 0.0086, "Foloseste < si > pentru selectie.")
    else
        renderText(x + 0.020, y + 0.090, 0.0086, "Motor: configuratii neexpuse")
        renderText(x + 0.020, y + 0.071, 0.0086, "de acest tractor/store item.")
    end

end


--------------------------------------------------
-- SHOWROOM
--------------------------------------------------

function SmartPhone:drawShowroom()

    -- BG drawShowroom
    self:drawFarmLinkPageBackground()
    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    setTextColor(0.02, 0.18, 0.05, 1)
    setTextBold(true)

    renderText(
        x + 0.018,
        y + h - 0.070,
        0.017,
        "Showroom"
    )

    setTextBold(true)
    setTextColor(0.06, 0.30, 0.10, 1)

    renderText(
        x + 0.018,
        y + h - 0.088,
        0.008,
        "ALEGE CATEGORIA"
    )

    local buttonX = x + 0.018
    local buttonW = w - 0.036
    local buttonH = 0.040

    self:drawShowroomButton(buttonX, y + 0.290, buttonW, buttonH, "Tractoare")
    self:drawShowroomButton(buttonX, y + 0.238, buttonW, buttonH, "Combine")
    self:drawShowroomButton(buttonX, y + 0.186, buttonW, buttonH, "Camioane")
    self:drawShowroomButton(buttonX, y + 0.134, buttonW, buttonH, "Masini")
    self:drawShowroomButton(buttonX, y + 0.082, buttonW, buttonH, "Utilaje")

    -- BUTON INAPOI - SUS DREAPTA, mereu vizibil
    local backX = x + w - 0.070
    local backY = y + h - 0.080

    drawFilledRect(backX,backY,0.052,0.026,0.08,0.42,0.14,1)

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)

    renderText(
        backX + 0.0092,
        backY + 0.0092,
        0.009,
        "< Inapoi"
    )

    setTextBold(false)

end

function SmartPhone:drawShowroomButton(x, y, w, h, label)

    drawFilledRect(x,y,w,h,0.035,0.18,0.065,1)

    drawFilledRect(
        x,
        y + h - 0.0034,
        w,
        0.0034,
        0.16, 0.70, 0.24, 1
    )

    setTextColor(0.96, 0.98, 0.92, 1)
    setTextBold(true)

    renderText(
        x + 0.012,
        y + 0.014,
        0.009,
        label
    )

    setTextBold(false)

end


--------------------------------------------------
-- SETTINGS
--------------------------------------------------

