-- FarmLink - Home separat
-- Interfata Home si iconitele aplicatiilor sunt izolate de motorul principal.

SmartPhone = SmartPhone or {}
FarmLinkHome = FarmLinkHome or {}

FarmLinkHome.id = "home"
FarmLinkHome.title = "FarmLink"


function SmartPhone:getFarmLinkHomeBackground()
    if self.homeBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.homeBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.homeBackgroundOverlay
end

function SmartPhone:drawHome()

    local x = self.phoneX
    local y = self.phoneY
    local w = self.phoneW
    local h = self.phoneH

    -- FUNDAL FARMLINK - separat doar pentru Home.
    local bgX = x + 0.010
    local bgY = y + 0.028
    local bgW = w - 0.020
    local bgH = h - 0.070
    local homeBg = self:getFarmLinkHomeBackground()
    if homeBg ~= nil then
        homeBg:setPosition(bgX,bgY)
        homeBg:setDimension(bgW,bgH)
        homeBg:render()
    else
        drawFilledRect(bgX,bgY,bgW,bgH,0.94,0.92,0.82,1)
    end

    -- HEADER FARMLINK
    drawFilledRect(x + 0.010,y + h - 0.094,w - 0.020,0.050,0.48,0.78,0.50,1)

    -- ACCENT HEADER
    drawFilledRect(
        x + 0.010,
        y + h - 0.094,
        w - 0.020,
        0.0041,
        0.12, 0.46, 0.18, 1
    )

    setTextColor(0.04,0.18,0.08,1)
    setTextBold(true)
    renderText(
        x + 0.018,
        y + h - 0.070,
        0.017,
        "FarmLink"
    )

    setTextBold(false)
    setTextColor(0.12,0.38,0.17,1)
    renderText(
        x + 0.019,
        y + h - 0.085,
        0.0075,
        "AGRICULTURE SYSTEM"
    )

    -- NOTIFICARI
    local notifCount = self.notifications ~= nil and #self.notifications or 0
    local notifX = x + w - 0.038
    local notifY = y + h - 0.086
    local notifW = 0.024
    local notifH = 0.028

    drawFilledRect(notifX,notifY,notifW,notifH,0.16,0.52,0.22,1)

    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(1,1,1,1)
    setTextBold(true)
    renderText(
        notifX + notifW * 0.5,
        notifY + notifH * 0.34,
        0.008,
        tostring(notifCount)
    )
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- APLICATII - aceleasi coordonate
    local col1 = x + 0.015
    local col2 = x + 0.061
    local col3 = x + 0.107

    local row1 = y + 0.235
    local row2 = y + 0.155
    local row3 = y + 0.075

    local appW = 0.038
    local appH = 0.062

    self:drawFarmLinkApp(col1,row1,appW,appH,"Showroom","showroom.png")
    self:drawFarmLinkApp(col2,row1,appW,appH,"Harta","map.png")
    self:drawFarmLinkApp(col3,row1,appW,appH,"Banca","bank.png")

    self:drawFarmLinkApp(col1,row2,appW,appH,"Magazin","shop.png")
    self:drawFarmLinkApp(col2,row2,appW,appH,"Ferma","farm.png")
    self:drawFarmLinkApp(col3,row2,appW,appH,"Vreme","weather.png")

    self:drawFarmLinkApp(col1,row3,appW,appH,"Service","service.png")
    self:drawFarmLinkApp(col2,row3,appW,appH,"Preturi","prices.png")
    self:drawFarmLinkApp(col3,row3,appW,appH,"Setari","settings.png")

    -- CONTACTE
    drawFilledRect(x + 0.014,y + h - 0.155,w - 0.028,0.030,0.94,0.96,0.86,0.72)

    drawFilledRect(
        x + 0.014,
        y + h - 0.128,
        w - 0.028,
        0.003,
        0.35,0.72,0.40,1
    )

    setTextColor(0.08,0.32,0.13,1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(
        x + w * 0.5,
        y + h - 0.145,
        0.0085,
        "CONTACTE"
    )
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)

    -- ECRAN BLOCARE
    drawFilledRect(x + 0.014,y + 0.035,w - 0.028,0.029,0.94,0.96,0.86,0.72)

    drawFilledRect(
        x + 0.014,
        y + 0.061,
        w - 0.028,
        0.003,
        0.35,0.72,0.40,1
    )

    setTextColor(0.08,0.32,0.13,1)
    setTextBold(true)
    setTextAlignment(RenderText.ALIGN_CENTER)
    renderText(
        x + w * 0.5,
        y + 0.044,
        0.0078,
        "ECRAN BLOCARE"
    )
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
end

function SmartPhone:getFarmLinkAppIcon(fileName)
    self.appIconOverlays = self.appIconOverlays or {}

    if fileName == nil or self.modDirectory == nil then
        return nil
    end

    if self.appIconOverlays[fileName] == nil then
        self.appIconOverlays[fileName] = Overlay.new(
            self.modDirectory .. "textures/icons/" .. fileName,
            0, 0, 0.01, 0.01
        )
        print("FS25 FarmLink - ICONITA INCARCATA: " .. tostring(fileName))
    end

    return self.appIconOverlays[fileName]
end

function SmartPhone:drawFarmLinkApp(x, y, w, h, label, iconFile)

    -- CARD PATRAT, ca in marcajul rosu al utilizatorului.
    -- Fundal aproape opac pentru ca iconita si textul sa fie clare peste fotografie.
    drawFilledRect(
        x, y, w, h,
        0.95,0.96,0.87,0.94
    )

    -- Chenar verde subtire, drept.
    local border = 0.0012
    drawFilledRect(x, y+h-border, w, border, 0.20,0.52,0.24,1)
    drawFilledRect(x, y, w, border, 0.20,0.52,0.24,1)
    drawFilledRect(x, y, border, h, 0.20,0.52,0.24,1)
    drawFilledRect(x+w-border, y, border, h, 0.20,0.52,0.24,1)

    -- ICONITA PNG ramane aceeasi, doar este asezata in cardul patrat.
    local icon = self:getFarmLinkAppIcon(iconFile)
    if icon ~= nil then
        local iconW = w * 0.70
        local iconH = iconW
        local iconX = x + (w - iconW) * 0.5
        local iconY = y + h * 0.34

        icon:setPosition(iconX, iconY)
        icon:setDimension(iconW, iconH)
        icon:render()
    end

    -- NUMELE APLICATIEI: mai mare, bold si verde foarte inchis.
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextBold(true)
    setTextColor(0.005,0.10,0.02,1)

    local textSize = 0.0090
    if label == "Showroom" then
        textSize = 0.0080
    elseif label == "Magazin" or label == "Service" or label == "Preturi" then
        textSize = 0.0084
    end

    renderText(
        x + w * 0.5,
        y + 0.0075,
        textSize,
        label
    )

    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)
end
