-- FarmLink v1.0.93.0
-- Aplicatia BANCA - modul separat

SmartPhone = SmartPhone or {}

-- Fundal FarmLink folosit separat de fiecare pagina.
function SmartPhone:getFarmLinkPageBackground()
    if self.farmLinkPageBackgroundOverlay == nil and self.modDirectory ~= nil then
        self.farmLinkPageBackgroundOverlay = Overlay.new(
            self.modDirectory .. "textures/lockscreen/farmlink_lockscreen.png",
            0, 0, 0.01, 0.01
        )
    end
    return self.farmLinkPageBackgroundOverlay
end

function SmartPhone:drawFarmLinkPageBackground()
    local bg = self:getFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    if bg ~= nil then
        bg:setPosition(x+0.010,y+0.018)
        bg:setDimension(w-0.020,h-0.060)
        bg:render()
    else
        drawFilledRect(x+0.010,y+0.018,w-0.020,h-0.060,0.94,0.92,0.82,1)
    end
end

FarmLinkBank = FarmLinkBank or {}

FarmLinkBank.id = "bank"
FarmLinkBank.title = "Banca"

SmartPhone.bankHistory = SmartPhone.bankHistory or {}
SmartPhone.bankLastBalance = SmartPhone.bankLastBalance or nil
SmartPhone.bankHistoryPage = SmartPhone.bankHistoryPage or 1

function FarmLinkBank.open(phone)
    if phone ~= nil then
        phone.currentPage = "bank"
        phone.bankHistoryPage = 1
    end
end

function SmartPhone:getFarmLinkFarmId()
    if g_currentMission ~= nil and g_currentMission.getFarmId ~= nil then
        local ok, farmId = pcall(function()
            return g_currentMission:getFarmId()
        end)
        if ok then return farmId end
    end
    return nil
end

function SmartPhone:getFarmLinkBalance()
    if g_currentMission == nil then return 0 end

    local farmId = self:getFarmLinkFarmId()

    if farmId ~= nil and g_currentMission.getMoney ~= nil then
        local ok, value = pcall(function()
            return g_currentMission:getMoney(farmId)
        end)
        if ok and value ~= nil then
            return tonumber(value) or 0
        end
    end

    if farmId ~= nil and g_farmManager ~= nil and g_farmManager.getFarmById ~= nil then
        local ok, farm = pcall(function()
            return g_farmManager:getFarmById(farmId)
        end)
        if ok and farm ~= nil and farm.money ~= nil then
            return tonumber(farm.money) or 0
        end
    end

    return 0
end

function SmartPhone:formatFarmLinkMoney(value)
    value = math.floor((tonumber(value) or 0) + 0.5)
    local sign = value < 0 and "-" or ""
    local s = tostring(math.abs(value))
    while true do
        local changed
        s, changed = string.gsub(s, "^(-?%d+)(%d%d%d)", "%1.%2")
        if changed == 0 then break end
    end
    return sign .. s .. " $"
end

function SmartPhone:updateFarmLinkBankHistory()
    local balance = self:getFarmLinkBalance()

    if self.bankLastBalance == nil then
        self.bankLastBalance = balance
        return
    end

    local delta = balance - self.bankLastBalance

    if math.abs(delta) >= 1 then
        local timeText = "--:--"
        if getDate ~= nil then
            local ok, value = pcall(function() return getDate("%H:%M") end)
            if ok and value ~= nil then timeText = tostring(value) end
        elseif os ~= nil and os.date ~= nil then
            timeText = os.date("%H:%M")
        end

        table.insert(self.bankHistory, 1, {
            amount = delta,
            balance = balance,
            time = timeText
        })

        while #self.bankHistory > 30 do
            table.remove(self.bankHistory)
        end

        self.bankLastBalance = balance
    end
end

function SmartPhone:drawBank()
    -- BG drawBank
    self:drawFarmLinkPageBackground()
    local x,y,w,h = self.phoneX,self.phoneY,self.phoneW,self.phoneH
    self:updateFarmLinkBankHistory()

    local balance = self:getFarmLinkBalance()

    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextColor(0.025,0.18,0.05,1)
    setTextBold(true)
    renderText(x+0.018,y+h-0.070,0.014,"Banca")
    setTextBold(false)

    local bw,bh=0.048,0.025
    local bx,by=x+w-bw-0.016,y+h-0.080
    drawFilledRect(bx,by,bw,bh,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(bx+bw/2,by+0.0086,0.0078,"< Inapoi")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(true)

    drawFilledRect(x+0.014,y+h-0.175,w-0.028,0.075,0.06,0.28,0.10,1)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(x+0.024,y+h-0.132,0.0085,"SOLD FERMA")
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(x+0.024,y+h-0.160,0.0110,self:formatFarmLinkMoney(balance))
    setTextBold(false)

    setTextColor(0.02,0.18,0.05,1)
    setTextBold(true)
    renderText(x+0.018,y+h-0.205,0.0085,"ISTORIC SESIUNE")
    setTextBold(false)

    local perPage=4
    local pages=math.max(1,math.ceil(#self.bankHistory/perPage))
    self.bankHistoryPage=math.max(1,math.min(pages,self.bankHistoryPage or 1))
    local first=(self.bankHistoryPage-1)*perPage+1

    if #self.bankHistory==0 then
        setTextColor(0.02,0.18,0.05,1)
        renderText(x+0.020,y+h-0.245,0.0082,"Nicio tranzactie inca.")
    else
        for row=0,perPage-1 do
            local item=self.bankHistory[first+row]
            if item~=nil then
                local cy=y+h-0.265-row*0.055
                drawFilledRect(x+0.014,cy,w-0.028,0.044,0.025,0.105,0.040,1)

                setTextColor(0.58,0.76,0.61,1)
                renderText(x+0.023,cy+0.026,0.007,item.time)

                local prefix=item.amount>=0 and "+" or ""
                setTextColor(0.96,0.98,0.92,1)
                setTextBold(true)
                renderText(x+0.023,cy+0.009,0.0083,prefix..self:formatFarmLinkMoney(item.amount))
                setTextBold(false)
            end
        end
    end

    local ny=y+0.030
    drawFilledRect(x+0.018,ny,0.040,0.026,0.08,0.42,0.14,1)
    drawFilledRect(x+w-0.058,ny,0.040,0.026,0.08,0.42,0.14,1)
    setTextAlignment(RenderText.ALIGN_CENTER)
    setTextColor(0.96,0.98,0.92,1)
    setTextBold(true)
    renderText(x+0.038,ny+0.0081,0.010,"<")
    renderText(x+w/2,ny+0.0092,0.008,"Pagina "..self.bankHistoryPage.."/"..pages)
    renderText(x+w-0.038,ny+0.0081,0.010,">")
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(false)
end
